var It = Object.defineProperty;
var Je = (e) => {
  throw TypeError(e);
};
var Ht = (e, t, n) => t in e ? It(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n;
var R = (e, t, n) => Ht(e, typeof t != "symbol" ? t + "" : t, n), we = (e, t, n) => t.has(e) || Je("Cannot " + n);
var b = (e, t, n) => (we(e, t, "read from private field"), n ? n.call(e) : t.get(e)), V = (e, t, n) => t.has(e) ? Je("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, n), I = (e, t, n, r) => (we(e, t, "write to private field"), r ? r.call(e, n) : t.set(e, n), n), se = (e, t, n) => (we(e, t, "access private method"), n);
const m = "monster-anatomy", at = m, rt = "parts", W = {
  /** Disparado quando o painel de anatomia termina de renderizar. */
  PANEL_RENDER: "monsterAnatomy.panelRender",
  /** Disparado após criar/atualizar/remover uma parte. */
  PARTS_CHANGED: "monsterAnatomy.partsChanged",
  /** Disparado após aplicar dano a uma parte (sempre, mesmo sem quebra). */
  PART_DAMAGE: "monsterAnatomy.partDamage",
  /** Disparado na transição para quebrado (uma vez por transição). */
  PART_BREAK: "monsterAnatomy.partBreak",
  /** Disparado na transição para cortado (uma vez por transição). */
  PART_SEVER: "monsterAnatomy.partSever",
  /** Disparado ao entrar em fase (nome da fase). */
  PART_PHASE: "monsterAnatomy.phaseChange"
}, Ee = { mode: "inherit", value: 0 };
function xe(e) {
  const t = e.bonus;
  if (!t || typeof t != "object") return { ...Ee };
  const n = t.mode === "off" || t.mode === "percent" || t.mode === "flat" ? t.mode : "inherit", r = Number.isFinite(Number(t.value)) ? Math.max(0, Number(t.value)) : 0;
  return { mode: n, value: r };
}
function ye(e) {
  if (!Array.isArray(e.rewards)) return [];
  const t = [];
  for (const n of e.rewards) {
    if (!n || typeof n != "object") continue;
    const r = n, a = typeof r.uuid == "string" && r.uuid.trim() !== "" ? r.uuid.trim() : typeof r.tableUuid == "string" ? r.tableUuid.trim() : "";
    a !== "" && t.push({
      id: typeof r.id == "string" && r.id !== "" ? r.id : foundry.utils.randomID(),
      kind: r.kind === "item" ? "item" : "table",
      uuid: a,
      draws: Math.max(1, Math.min(20, Math.floor(Number(r.draws) || 1))),
      onEvent: r.onEvent === "sever" ? "sever" : "break"
    });
  }
  return t;
}
const Bt = ["slashing", "piercing", "bludgeoning"], $t = [
  "slashing",
  "piercing",
  "bludgeoning",
  "fire",
  "cold",
  "lightning",
  "thunder",
  "acid",
  "poison",
  "psychic",
  "necrotic",
  "radiant",
  "force"
];
function Ft(e, t) {
  var r;
  if (!t) return 1;
  const n = (r = e.hitzone) == null ? void 0 : r[t];
  return typeof n == "number" && Number.isFinite(n) && n >= 0 ? n : 1;
}
function Ct(e) {
  return e.severable && (e.severTypes ?? []).length > 0;
}
function G(e) {
  return e === "broken" || e === "severed";
}
const S = {
  disableItemId: "",
  disableItemName: "",
  effectName: "",
  effectIcon: "",
  effectDuration: null,
  condition: "",
  setAttrPath: "",
  setAttrValue: "",
  macroUuid: ""
};
function K(e) {
  return { ...S, ...e.onBreak ?? {} };
}
function Dt(e, t, n, r) {
  return {
    id: foundry.utils.randomID(),
    name: e,
    parts: t.map((a) => {
      var o;
      return {
        name: a.name,
        img: a.img ?? "",
        ac: a.ac,
        hpMax: a.hp.max,
        breakable: a.breakable,
        severable: a.severable,
        regen: Math.max(0, Math.floor(a.regen ?? 0)),
        phaseName: typeof a.phaseName == "string" ? a.phaseName : "",
        hitzone: { ...a.hitzone ?? {} },
        severMax: ((o = a.sever) == null ? void 0 : o.max) ?? a.hp.max,
        severTypes: [...a.severTypes ?? ["slashing"]],
        onBreak: K(a),
        rewards: ye(a).map((i) => ({ ...i })),
        bonus: xe(a)
      };
    })
  };
}
function Lt(e, t) {
  return e.parts.map((n) => {
    const r = Math.max(1, Math.floor(n.hpMax)), a = ue(n.name || "Nova parte", {
      ac: Math.max(0, Math.floor(n.ac)),
      hp: r
    });
    a.img = typeof n.img == "string" ? n.img : "", a.regen = Math.max(0, Math.floor(n.regen || 0)), a.phaseName = typeof n.phaseName == "string" ? n.phaseName : "", a.breakable = n.breakable !== !1, a.severable = n.severable === !0, a.hitzone = { ...n.hitzone ?? {} };
    const o = Math.max(1, Math.floor(n.severMax || r));
    a.sever = { value: o, max: o }, a.severTypes = [...n.severTypes ?? ["slashing"]], a.onBreak = { ...S, ...n.onBreak ?? {} }, a.rewards = (n.rewards ?? []).map((l) => ({ ...l })), a.bonus = { ...Ee, ...n.bonus ?? {} };
    const i = a.onBreak.disableItemName.trim(), c = i ? [...t.items].find((l) => l.name === i) : void 0, s = !c && a.onBreak.disableItemId.trim() ? t.items.get(a.onBreak.disableItemId.trim()) : void 0, u = c ?? s;
    return a.onBreak.disableItemId = typeof (u == null ? void 0 : u.id) == "string" ? u.id : "", a.onBreak.disableItemName = typeof (u == null ? void 0 : u.name) == "string" ? u.name : i, a;
  });
}
const Ut = [
  {
    id: "builtin-dragonoid",
    name: "MONSTER_ANATOMY.Template.Dragonoid",
    builtin: !0,
    map: "dragonoid",
    parts: [
      { name: "Cabeça", ac: 21, hpMax: 80, breakable: !0, severable: !1, hitzone: { bludgeoning: 1.5, piercing: 0.8 }, severMax: 80, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Corpo", ac: 19, hpMax: 100, breakable: !0, severable: !1, hitzone: {}, severMax: 100, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Asa Esquerda", ac: 20, hpMax: 60, breakable: !0, severable: !1, hitzone: {}, severMax: 60, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Asa Direita", ac: 20, hpMax: 60, breakable: !0, severable: !1, hitzone: {}, severMax: 60, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Cauda", ac: 22, hpMax: 70, breakable: !0, severable: !0, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...S, disableItemName: "Tail Swipe" }, rewards: [] }
    ]
  },
  {
    id: "builtin-humanoid",
    name: "MONSTER_ANATOMY.Template.Humanoid",
    builtin: !0,
    map: "humanoid",
    parts: [
      { name: "Cabeça", ac: 20, hpMax: 50, breakable: !0, severable: !1, hitzone: { bludgeoning: 1.5 }, severMax: 50, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Corpo", ac: 18, hpMax: 80, breakable: !0, severable: !1, hitzone: {}, severMax: 80, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Braço Esquerdo", ac: 18, hpMax: 40, breakable: !0, severable: !1, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Braço Direito", ac: 18, hpMax: 40, breakable: !0, severable: !1, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Perna Esquerda", ac: 18, hpMax: 50, breakable: !0, severable: !1, hitzone: {}, severMax: 50, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Perna Direita", ac: 18, hpMax: 50, breakable: !0, severable: !1, hitzone: {}, severMax: 50, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] }
    ]
  }
], oe = {
  intact: "MONSTER_ANATOMY.State.Intact",
  damaged: "MONSTER_ANATOMY.State.Damaged",
  broken: "MONSTER_ANATOMY.State.Broken",
  severed: "MONSTER_ANATOMY.State.Severed",
  destroyed: "MONSTER_ANATOMY.State.Destroyed"
};
let We = 0;
function ot() {
  We += 1;
  const e = Math.random().toString(36).slice(2, 8);
  return `part-${Date.now().toString(36)}-${e}-${We}`;
}
function ue(e, t) {
  const n = Math.max(1, Math.floor(t.hp));
  return {
    id: ot(),
    name: e.trim(),
    ac: Math.max(0, Math.floor(t.ac)),
    hp: { value: n, max: n },
    breakable: !0,
    severable: !1,
    state: "intact",
    notes: "",
    img: "",
    zone: null,
    regen: 0,
    phaseName: "",
    onBreak: { ...S },
    hitzone: {},
    sever: { value: n, max: n },
    severTypes: ["slashing"],
    rewards: [],
    bonus: { ...Ee }
  };
}
function qt(e) {
  return e.hp.value <= 0 && e.breakable ? "broken" : e.hp.value < e.hp.max ? "damaged" : "intact";
}
function zt(e) {
  var n;
  const t = [];
  return (n = e.name) != null && n.trim() || t.push("name"), (e.ac === void 0 || !Number.isFinite(e.ac) || e.ac < 0) && t.push("ac"), (e.hp === void 0 || !Number.isFinite(e.hp.max) || e.hp.max < 1) && t.push("hp.max"), e.hp !== void 0 && (!Number.isFinite(e.hp.value) || e.hp.value < 0) && t.push("hp.value"), t;
}
function Me(e) {
  return {
    ...e,
    hp: { ...e.hp },
    onBreak: K(e),
    hitzone: { ...e.hitzone ?? {} },
    sever: e.sever ? { ...e.sever } : { value: e.hp.max, max: e.hp.max },
    severTypes: [...e.severTypes ?? ["slashing"]],
    rewards: ye(e).map((t) => ({ ...t })),
    bonus: xe(e)
  };
}
function p(e) {
  var t;
  return ((t = game.i18n) == null ? void 0 : t.localize(e)) ?? e;
}
function w(e, t) {
  var n;
  return ((n = game.i18n) == null ? void 0 : n.format(e, t)) ?? e;
}
function g(e) {
  return game.settings.get(m, e);
}
function re(e) {
  if (!e || typeof e != "object") return;
  const t = e;
  if (typeof t.uuid == "string" && t.uuid) return t.uuid;
  if (t.document && typeof t.document == "object") {
    const n = t.document.uuid;
    if (typeof n == "string" && n) return n;
  }
}
function it() {
  var e, t;
  return (t = (e = game.modules) == null ? void 0 : e.get(m)) == null ? void 0 : t.api;
}
function Q(e, ...t) {
  Hooks.callAll.call(Hooks, e, ...t);
}
function ce(e, t) {
  return Hooks.on.call(Hooks, e, t);
}
function Vt(e, t) {
  Hooks.off.call(Hooks, e, t);
}
const Re = "attrBackup";
function Gt(e) {
  const t = /* @__PURE__ */ new Set();
  for (const n of st(e)) {
    if (!G(n.state)) continue;
    const r = K(n).disableItemId.trim();
    r && t.add(r);
  }
  return t;
}
function Kt(e, t) {
  return st(e).find(
    (n) => G(n.state) && K(n).disableItemId.trim() === t
  );
}
function st(e) {
  const t = e.getFlag(m, "parts");
  return Array.isArray(t) ? t : [];
}
async function jt(e, t) {
  const n = K(t);
  n.effectName.trim() && await Jt(e, t, n.effectName.trim(), n), n.condition.trim() && await Wt(e, t, n.condition.trim()), n.setAttrPath.trim() && await Qt(e, t, n), n.macroUuid.trim() && await Zt(n.macroUuid.trim());
}
async function Qe(e, t) {
  for (const n of [...e.effects])
    try {
      if (n.getFlag(m, "partId") !== t.id) continue;
      const r = n.getFlag(m, "kind");
      (r === "break-effect" || r === "break-condition" || r === "part-broken" || r === "part-severed") && await n.delete();
    } catch (r) {
      console.warn("monster-anatomy | falha ao remover efeito da parte", r);
    }
  await Xt(e, t.id);
}
async function Jt(e, t, n, r) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(m, "partId") === t.id && i.getFlag(m, "kind") === "break-effect";
    } catch {
      return !1;
    }
  })) return;
  const o = {};
  o[m] = { partId: t.id, kind: "break-effect" }, await ActiveEffect.create(
    {
      name: n,
      img: r.effectIcon.trim() || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      duration: typeof r.effectDuration == "number" ? { rounds: r.effectDuration } : void 0,
      flags: o
    },
    { parent: e }
  );
}
async function Wt(e, t, n) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(m, "partId") === t.id && i.getFlag(m, "kind") === "break-condition";
    } catch {
      return !1;
    }
  })) return;
  const a = CONFIG.statusEffects.find(
    (i) => (i == null ? void 0 : i.id) === n
  ), o = {};
  o[m] = { partId: t.id, kind: "break-condition" }, await ActiveEffect.create(
    {
      name: w("MONSTER_ANATOMY.Effect.ConditionName", {
        status: (a == null ? void 0 : a.name) ?? n,
        part: t.name
      }),
      img: (a == null ? void 0 : a.img) || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      statuses: [n],
      flags: o
    },
    { parent: e }
  );
}
async function Qt(e, t, n) {
  const r = n.setAttrPath.trim(), a = ct(e);
  t.id in a || (a[t.id] = { [r]: foundry.utils.getProperty(e, r) }, await e.setFlag(m, Re, a)), await e.update({
    [r]: en(n.setAttrValue)
  });
}
async function Xt(e, t) {
  const n = ct(e), r = n[t];
  if (!r) return;
  const a = {};
  for (const [o, i] of Object.entries(r)) a[o] = i;
  delete n[t];
  try {
    await e.update(a);
  } catch (o) {
    console.warn("monster-anatomy | falha ao restaurar atributo", o);
  }
  await e.setFlag(m, Re, n);
}
function ct(e) {
  try {
    const t = e.getFlag(m, Re);
    if (t && typeof t == "object" && !Array.isArray(t))
      return JSON.parse(JSON.stringify(t));
  } catch {
  }
  return {};
}
async function Zt(e) {
  try {
    const n = await fromUuid(e);
    typeof (n == null ? void 0 : n.execute) == "function" ? await n.execute() : console.warn(`monster-anatomy | macro não encontrada (${e})`);
  } catch (t) {
    console.warn(`monster-anatomy | falha ao executar macro (${e})`, t);
  }
}
function en(e) {
  const t = e.trim();
  return t === "true" ? !0 : t === "false" ? !1 : t !== "" && Number.isFinite(Number(t)) ? Number(t) : e;
}
function y(e) {
  const t = e.getFlag(at, rt);
  return Array.isArray(t) ? t.map((n) => ({ ...n, hp: { ...n.hp } })) : [];
}
async function ie(e, t) {
  var r;
  if (!e.isOwner)
    throw (r = ui.notifications) == null || r.warn(p("MONSTER_ANATOMY.Errors.NoPermission")), new Error("monster-anatomy: actor não editável pelo usuário atual");
  const n = y(e);
  await e.setFlag(at, rt, t.map(Me)), await tn(e, n, t), Q(W.PARTS_CHANGED, e, y(e));
}
async function tn(e, t, n) {
  var o;
  const r = new Map(t.map((i) => [i.id, i])), a = new Set(n.map((i) => i.id));
  for (const i of n) {
    const c = G(((o = r.get(i.id)) == null ? void 0 : o.state) ?? "intact"), s = G(i.state);
    if (s !== c)
      try {
        s ? await jt(e, i) : await Qe(e, i);
      } catch (u) {
        console.warn("monster-anatomy | falha na vinculação de ruptura", u);
      }
  }
  for (const i of t)
    if (!(a.has(i.id) || !G(i.state)))
      try {
        await Qe(e, i);
      } catch (c) {
        console.warn("monster-anatomy | falha na limpeza de ruptura", c);
      }
}
async function ut(e, t) {
  const n = y(e);
  if (n.some((r) => r.id === t.id))
    throw new Error(`monster-anatomy: id de parte duplicado (${t.id})`);
  n.push(Me(t)), await ie(e, n);
}
async function le(e, t, n) {
  const r = y(e), a = r.findIndex((i) => i.id === t);
  if (a < 0) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = r[a];
  r[a] = {
    ...o,
    ...n,
    id: o.id,
    // id é imutável (§5.1 do design)
    hp: { ...o.hp, ...n.hp ?? {} }
  }, await ie(e, r);
}
async function nn(e, t) {
  const n = y(e).filter((r) => r.id !== t);
  await ie(e, n);
}
async function lt(e, t) {
  const n = y(e), r = n.find((o) => o.id === t);
  if (!r) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const a = {
    ...Me(r),
    id: ot(),
    name: `${r.name}${p("MONSTER_ANATOMY.Panel.CopySuffix")}`
  };
  return n.push(a), await ie(e, n), a;
}
function k(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function te() {
  var e;
  return ((e = game.user) == null ? void 0 : e.isGM) === !0;
}
function an(e) {
  const t = e.name.startsWith("MONSTER_ANATOMY.") ? p(e.name) : e.name;
  return e.builtin ? `${t} ${p("MONSTER_ANATOMY.Template.BuiltinTag")}` : t;
}
function _e() {
  return [...Ut, ...me()];
}
function me() {
  try {
    const e = g("templatesJson");
    if (typeof e != "string" || e.trim() === "") return [];
    const t = JSON.parse(e);
    return Array.isArray(t) ? t.filter(
      (n) => !!n && typeof n == "object" && typeof n.id == "string"
    ) : [];
  } catch {
    return [];
  }
}
async function mt(e) {
  await game.settings.set(m, "templatesJson", JSON.stringify(e));
}
async function rn(e, t, n, r) {
  const a = Dt(e, t);
  return await mt([...me(), a]), a;
}
async function on(e) {
  if (e.startsWith("builtin-")) return !1;
  const t = me().filter((n) => n.id !== e);
  return t.length === me().length ? !1 : (await mt(t), !0);
}
async function dt(e, t) {
  const n = _e().find((a) => a.id === t);
  if (!n) throw new Error(`monster-anatomy: modelo não encontrado (${t})`);
  const r = Lt(n, e);
  return await ie(e, [...y(e), ...r]), n.map && await e.setFlag(m, "mapLayout", n.map), typeof n.mapImage == "string" && n.mapImage !== "" && await e.setFlag(m, "mapImage", n.mapImage), r.length;
}
function ft(e) {
  try {
    const t = e.getFlag(m, "phase");
    return typeof t == "string" ? t : "";
  } catch {
    return "";
  }
}
async function sn(e, t) {
  await e.setFlag(m, "phase", t);
}
function de(e) {
  try {
    return e.getFlag(m, "hideAc") === !0;
  } catch {
    return !1;
  }
}
async function cn(e, t) {
  await e.setFlag(m, "hideAc", t);
}
function Ye() {
  var e;
  try {
    if (g("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function un(e) {
  if (Ye()) return;
  const t = e.textContent ?? "";
  if (t.length === 0 || t.length > 24) return;
  e.textContent = "";
  let n = 0;
  for (const r of Array.from(t)) {
    if (r === " ") {
      e.appendChild(document.createTextNode(" "));
      continue;
    }
    const a = document.createElement("span");
    a.className = "ma-letter", a.textContent = r, a.style.setProperty("--i", String(n)), e.appendChild(a), n++;
  }
}
function Pe(e) {
  try {
    if (g("particles") !== !0 || Ye() || document.hidden) return;
  } catch {
    return;
  }
  const t = document.createElement("canvas");
  t.className = "monster-anatomy-particles";
  const n = Math.min(2, window.devicePixelRatio || 1);
  t.width = Math.floor(window.innerWidth * n), t.height = Math.floor(window.innerHeight * n), document.body.appendChild(t);
  const r = t.getContext("2d");
  if (!r) {
    t.remove();
    return;
  }
  r.scale(n, n);
  const a = window.innerWidth / 2, o = window.innerHeight / 2 - window.innerHeight * 0.06, i = e ? ["#9adcff", "#e8f7ff", "#4da6d8", "#0e4d64", "#ffffff"] : ["#ff3b3b", "#ffb454", "#fff3d6", "#7a1a00", "#1a1a1a"], c = [], s = 90;
  for (let T = 0; T < s; T++) {
    const M = Math.random() * Math.PI * 2, h = 180 + Math.random() * 560, f = 0.7 + Math.random() * 0.6;
    c.push({
      x: a + (Math.random() - 0.5) * 60,
      y: o + (Math.random() - 0.5) * 30,
      vx: Math.cos(M) * h,
      vy: Math.sin(M) * h - 160,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 14,
      size: 3 + Math.random() * 8,
      life: f,
      maxLife: f,
      color: i[Math.floor(Math.random() * i.length)],
      circle: Math.random() < 0.3
    });
  }
  const u = 900;
  let l = performance.now();
  const d = (T) => {
    const M = Math.min(0.05, (T - l) / 1e3);
    l = T, r.clearRect(0, 0, window.innerWidth, window.innerHeight);
    let h = !1;
    for (const f of c)
      f.life -= M, !(f.life <= 0) && (h = !0, f.vy += u * M, f.x += f.vx * M, f.y += f.vy * M, f.rot += f.vr * M, r.save(), r.globalAlpha = Math.max(0, f.life / f.maxLife), r.translate(f.x, f.y), r.rotate(f.rot), r.fillStyle = f.color, f.circle ? (r.beginPath(), r.arc(0, 0, f.size / 2, 0, Math.PI * 2), r.fill()) : r.fillRect(-f.size / 2, -f.size / 4, f.size, f.size / 2), r.restore());
    h ? requestAnimationFrame(d) : t.remove();
  };
  requestAnimationFrame(d);
}
function Ie() {
  try {
    if (g("screenShake") !== !0 || Ye()) return;
  } catch {
    return;
  }
  const e = document.getElementById("board");
  if (!e) return;
  const t = 11, n = 380, r = performance.now(), a = (o) => {
    const i = o - r;
    if (i >= n) {
      e.style.transform = "";
      return;
    }
    const c = 1 - i / n, s = Math.sin(o / 17) * t * c, u = Math.cos(o / 23) * t * 0.7 * c;
    e.style.transform = `translate(${s.toFixed(1)}px, ${u.toFixed(1)}px)`, requestAnimationFrame(a);
  };
  requestAnimationFrame(a);
}
async function ln(e, t, n) {
  g("showAnnouncement") && ht(e, t), g("chatMessage") && await hn(e, t, n), g("tokenEffect") && await An(e, t), await pt();
}
async function mn(e, t, n) {
  g("showAnnouncement") && gt(e, t), g("chatMessage") && await gn(e, t, n), g("tokenEffect") && await yn(e, t), await pt();
}
async function pt() {
  const e = String(g("breakSound") ?? "").trim();
  if (e)
    try {
      await foundry.audio.AudioHelper.play({ src: e, volume: 0.8 });
    } catch (t) {
      console.warn(`monster-anatomy | falha ao tocar som (${e})`, t);
    }
}
function Y(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function ht(e, t) {
  const n = Math.max(0.5, Math.min(10, Number(g("announceDuration") ?? 2.5)));
  Be(e, t, n, !1), $e(!1), Fe(e), Pe(!1), Ie();
}
function gt(e, t) {
  const n = Math.max(0.5, Math.min(10, Number(g("announceDuration") ?? 2.5)));
  Be(e, t, n, !0), $e(!0), Fe(e), Pe(!0), Ie();
}
function At(e, t, n) {
  const r = Math.max(0.5, Math.min(10, Number(g("announceDuration") ?? 2.5)));
  Be(e, t, r, !1, n, "is-phase"), $e(!1), Fe(e), Pe(!1), Ie();
}
function He() {
  var e;
  try {
    if (g("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function dn() {
  const e = String(g("announceTheme") ?? "persona");
  return e === "monsterhunter" || e === "jrpg" || e === "minimal" || e === "impact" || e === "arcade" || e === "carved" ? e : "persona";
}
function fn(e) {
  const t = String(
    g(e ? "customKickerSever" : "customKickerBreak") ?? ""
  ).trim();
  return t !== "" ? t : p(e ? "MONSTER_ANATOMY.Announce.Severed" : "MONSTER_ANATOMY.Announce.Break");
}
function Be(e, t, n, r, a, o) {
  document.querySelectorAll(".monster-anatomy-announce").forEach((u) => u.remove());
  const i = document.createElement("div");
  i.className = `monster-anatomy-announce theme-${dn()}` + (r ? " is-sever" : "") + (o ? ` ${o}` : ""), i.style.setProperty("--ma-duration", `${n}s`), He() && i.classList.add("is-reduced");
  const c = (a ?? "") !== "" ? a : fn(r);
  i.innerHTML = `<div class="ma-announce-kicker">${Y(c)}</div><div class="ma-announce-part">${Y(t.name)}</div><div class="ma-announce-actor">${Y(e.name)}</div>`, document.body.appendChild(i);
  const s = i.querySelector(".ma-announce-kicker");
  s && un(s), requestAnimationFrame(() => i.classList.add("is-showing")), window.setTimeout(() => {
    i.classList.remove("is-showing"), window.setTimeout(() => i.remove(), 450);
  }, Math.max(400, Math.round(n * 1e3)));
}
function $e(e) {
  try {
    if (g("screenFlash") !== !0 || He()) return;
  } catch {
    return;
  }
  const t = document.createElement("div");
  t.className = "monster-anatomy-flash" + (e ? " is-sever" : ""), document.body.appendChild(t), requestAnimationFrame(() => t.classList.add("is-showing")), window.setTimeout(() => t.classList.remove("is-showing"), 120), window.setTimeout(() => t.remove(), 450);
}
function Fe(e) {
  try {
    if (g("tokenShake") !== !0 || He()) return;
  } catch {
    return;
  }
  try {
    const t = e.getActiveTokens();
    for (const n of t) {
      const r = n == null ? void 0 : n.mesh;
      pn(r);
    }
  } catch {
  }
}
function pn(e) {
  const t = e == null ? void 0 : e.position;
  if (!t || typeof t.x != "number" || typeof t.y != "number") return;
  const n = t.x, r = t.y, a = 9, o = 420, i = performance.now(), c = typeof t.set == "function" ? t.set.bind(t) : null, s = (l, d) => {
    c ? c(l, d) : (t.x = l, t.y = d);
  }, u = (l) => {
    const d = l - i;
    if (d >= o) {
      s(n, r);
      return;
    }
    const T = 1 - d / o;
    s(n + Math.sin(l / 16) * a * T, r), requestAnimationFrame(u);
  };
  requestAnimationFrame(u);
}
async function hn(e, t, n) {
  const r = n.attacker ? `<p class="ma-chat-attacker">${Y(
    w("MONSTER_ANATOMY.Chat.BreakBy", {
      attacker: n.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", a = `<div class="monster-anatomy-chat ma-break"><h3>💥 ${Y(p("MONSTER_ANATOMY.Announce.Break"))}</h3><p>${Y(
    w("MONSTER_ANATOMY.Chat.BreakText", {
      part: t.name,
      actor: e.name,
      amount: String(n.amount)
    })
  )}</p>${r}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: a
  });
}
async function yt(e, t, n, r, a = 0, o = 0) {
  let i = !1;
  try {
    i = g("attackNotes") === !0;
  } catch {
    return;
  }
  if (!i) return;
  const c = [];
  a > 0 && c.push(`+${a}%`), o > 0 && c.push(`+${o}`);
  const s = c.length > 0 ? ` ${w("MONSTER_ANATOMY.Routed.Bonus", { mark: c.join(" ") })}` : "";
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-routed"><p>${Y(
      w("MONSTER_ANATOMY.Routed.Text", {
        amount: String(n),
        part: t,
        actor: e.name,
        global: String(r)
      })
    )}${Y(s)}</p></div>`
  });
}
async function gn(e, t, n) {
  const r = n.attacker ? `<p class="ma-chat-attacker">${Y(
    w("MONSTER_ANATOMY.Chat.SeverBy", {
      attacker: n.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", a = `<div class="monster-anatomy-chat ma-break ma-sever"><h3>🗡️ ${Y(p("MONSTER_ANATOMY.Announce.Severed"))}</h3><p>${Y(
    w("MONSTER_ANATOMY.Chat.SeverText", {
      part: t.name,
      actor: e.name,
      amount: String(n.amount)
    })
  )}</p>${r}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: a
  });
}
async function An(e, t) {
  if (e.effects.some((a) => {
    try {
      return a.getFlag(m, "partId") === t.id;
    } catch {
      return !1;
    }
  })) return;
  const r = {};
  r[m] = { partId: t.id, kind: "part-broken" }, await ActiveEffect.create(
    {
      name: w("MONSTER_ANATOMY.Effect.BrokenName", { part: t.name }),
      img: "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      flags: r
    },
    { parent: e }
  );
}
async function yn(e, t) {
  if (e.effects.some((a) => {
    try {
      return a.getFlag(m, "partId") === t.id && a.getFlag(m, "kind") === "part-severed";
    } catch {
      return !1;
    }
  })) return;
  const r = {};
  r[m] = { partId: t.id, kind: "part-severed" }, await ActiveEffect.create(
    {
      name: w("MONSTER_ANATOMY.Effect.SeveredName", { part: t.name }),
      img: "systems/dnd5e/icons/svg/damage/slashing.svg",
      origin: e.uuid,
      disabled: !1,
      flags: r
    },
    { parent: e }
  );
}
const Ce = "loot", Mn = 20;
async function Xe(e, t, n, r = {}) {
  const a = ye(t).filter((s) => s.onEvent === n);
  if (a.length === 0) return;
  const o = await Tn(e, r.attackerUuid), i = [];
  let c;
  for (const s of a) {
    if (s.kind === "item") {
      const l = await Nn(e, o, s.uuid, s.draws);
      l && (i.push(s.draws > 1 ? `${l} ×${s.draws}` : l), o && (c = o.name));
      continue;
    }
    const u = await bn(s.uuid);
    if (!u) {
      console.warn(`monster-anatomy | tabela não encontrada (${s.uuid})`);
      continue;
    }
    for (let l = 0; l < Math.min(Math.floor(s.draws), Mn); l++)
      try {
        const d = await u.draw({ displayChat: !1 });
        for (const T of d.results ?? []) {
          const M = Sn(T);
          M && i.push(M);
        }
      } catch (d) {
        console.warn("monster-anatomy | falha no sorteio", d);
        break;
      }
  }
  i.length !== 0 && (await vn(e, {
    partId: t.id,
    partName: t.name,
    event: n,
    items: i,
    ...c ? { grantedTo: c } : {},
    at: Date.now()
  }), g("chatMessage") && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-loot"><h3>🎁 ${Ze(p("MONSTER_ANATOMY.Loot.Title"))}</h3><p>${Ze(
      w("MONSTER_ANATOMY.Loot.Text", {
        part: t.name,
        actor: e.name,
        items: i.join(", ")
      })
    )}</p></div>`
  }));
}
async function Tn(e, t) {
  const n = t && t !== e.uuid ? t : void 0;
  if (n) {
    const a = await De(n);
    if (a instanceof Actor && a.uuid !== e.uuid) return a;
  }
  const r = game.user;
  if (r && !r.isGM) {
    const a = r.character;
    if (a instanceof Actor && a.uuid !== e.uuid) return a;
  }
  return null;
}
async function Nn(e, t, n, r) {
  var i, c, s;
  const a = await De(n);
  if (!(a instanceof Item))
    return console.warn(`monster-anatomy | item não encontrado (${n})`), null;
  const o = typeof a.name == "string" ? a.name : n;
  if (!t)
    return console.warn("monster-anatomy | sem atacante para entregar o item; registrado no pool"), o;
  try {
    const u = a.toObject() ?? {};
    delete u._id;
    const d = await t.createEmbeddedDocuments.call(t, "Item", [u]);
    if (r > 1 && ((i = d[0]) != null && i.update))
      try {
        await ((s = (c = d[0]).update) == null ? void 0 : s.call(c, { "system.quantity": r }));
      } catch {
      }
    return o;
  } catch (u) {
    return console.warn("monster-anatomy | falha ao criar item no recebedor", u), o;
  }
}
function Mt(e) {
  try {
    const t = e.getFlag(m, Ce);
    return Array.isArray(t) ? t.filter((n) => n && Array.isArray(n.items)) : [];
  } catch {
    return [];
  }
}
async function wn(e) {
  await e.setFlag(m, Ce, []);
}
async function vn(e, t) {
  const n = [...Mt(e), t].slice(-200);
  await e.setFlag(m, Ce, n);
}
async function bn(e) {
  const t = await De(e);
  return t instanceof RollTable ? t : null;
}
async function De(e) {
  try {
    return await fromUuid(e);
  } catch {
    return null;
  }
}
function Sn(e) {
  const t = e;
  return typeof (t == null ? void 0 : t.name) == "string" && t.name ? t.name : typeof (t == null ? void 0 : t.text) == "string" && t.text ? t.text : typeof (t == null ? void 0 : t.id) == "string" && t.id ? t.id : "";
}
function Ze(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
const ve = "system.attributes.hp.value";
async function Tt(e, t, n, r = {}) {
  return Te(e, t, [{ amount: n, type: r.type }], r);
}
async function Te(e, t, n, r = {}) {
  const a = y(e).find((A) => A.id === t);
  if (!a) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  let o = 0, i = 0;
  const c = Ct(a);
  for (const A of n) {
    const x = Math.max(0, Math.floor(Number(A == null ? void 0 : A.amount) || 0));
    x <= 0 || (o += x * Ft(a, A == null ? void 0 : A.type), c && typeof (A == null ? void 0 : A.type) == "string" && (a.severTypes ?? []).includes(A.type) && (i += x));
  }
  o = Math.floor(o);
  const s = a.state, u = xe(a);
  let l = 0, d = 0;
  if (G(s) && (u.mode === "percent" ? l = Math.max(0, Math.min(200, u.value)) : u.mode === "flat" ? d = Math.max(0, Math.floor(u.value)) : u.mode !== "off" && (l = Math.max(0, Math.min(200, Number(g("brokenBonus") ?? 0))))), l > 0 || d > 0) {
    const A = 1 + l / 100;
    o = Math.floor(o * A) + d, i = Math.floor(i * A) + d;
  }
  const T = Math.max(0, a.hp.value - o);
  let M = s;
  T <= 0 && a.breakable ? M = s === "severed" ? "severed" : "broken" : T < a.hp.max && s === "intact" && (M = "damaged"), await le(e, t, { hp: { ...a.hp, value: T }, state: M });
  let h = y(e).find((A) => A.id === t);
  const f = await kn(e, o);
  Q(W.PART_DAMAGE, e, h, o, r.attacker ?? null);
  const F = M === "broken" && s !== "broken";
  let C = "";
  if (F) {
    await ln(e, h, { amount: o, attacker: r.attacker }), await Xe(e, h, "break", { attackerUuid: r.attackerUuid }), Q(W.PART_BREAK, e, h, o, r.attacker ?? null);
    const A = (h.phaseName ?? "").trim();
    A !== "" && (C = A, await sn(e, A), At(e, h, A), Q(W.PART_PHASE, e, h, A));
  }
  let z = !1;
  const $ = h.sever ?? { value: h.hp.max, max: h.hp.max };
  if (c && i > 0 && h.state !== "severed") {
    const A = Math.max(0, $.value - i);
    await le(e, t, {
      sever: { value: A, max: $.max },
      ...A <= 0 ? { state: "severed" } : {}
    }), h = y(e).find((x) => x.id === t), A <= 0 && (z = !0, await mn(e, h, { amount: i, attacker: r.attacker }), await Xe(e, h, "sever", { attackerUuid: r.attackerUuid }), Q(W.PART_SEVER, e, h, i, r.attacker ?? null));
  }
  return { part: h, broke: F, severed: z, globalApplied: f, applied: o, bonus: l, bonusFlat: d, phased: C };
}
async function Le(e, t, n) {
  const r = Math.max(0, Math.floor(Number(n) || 0)), a = y(e).find((u) => u.id === t);
  if (!a) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = Math.min(a.hp.max, a.hp.value + r), i = o >= a.hp.max, c = i && (a.state === "damaged" || a.state === "broken") ? "intact" : a.state, s = a.sever ?? { value: a.hp.max, max: a.hp.max };
  return await le(e, t, {
    hp: { ...a.hp, value: o },
    state: c,
    ...i ? { sever: { value: s.max, max: s.max } } : {}
  }), y(e).find((u) => u.id === t);
}
async function kn(e, t) {
  if (t <= 0) return 0;
  const n = g("damageModel");
  if (n === "independent") return 0;
  const r = n === "percent" ? Math.max(0, Math.min(100, Number(g("damagePercent") ?? 50))) : 100, a = Math.floor(t * r / 100);
  if (a <= 0) return 0;
  const o = foundry.utils.getProperty(e, ve);
  if (typeof o != "number")
    return console.warn(`monster-anatomy | HP global não encontrado em ${ve}`), 0;
  const i = Math.max(0, o - a);
  return await e.update({
    [ve]: i
  }), a;
}
const { ApplicationV2: On, HandlebarsApplicationMixin: En } = foundry.applications.api;
function xn(e, t) {
  const n = e.hp.max > 0 ? e.hp.value / e.hp.max * 100 : 0;
  return {
    id: e.id,
    img: e.img ?? "",
    name: e.name,
    state: e.state,
    stateLabel: p(oe[e.state]),
    acDisplay: t ? "??" : String(e.ac),
    hpValue: e.hp.value,
    hpMax: e.hp.max,
    hpPct: Math.max(0, Math.min(100, Math.round(n)))
  };
}
var H, ee, Nt, wt;
const ne = class ne extends En(On) {
  constructor(n, r) {
    super(n);
    V(this, ee);
    V(this, H, null);
    I(this, H, r);
  }
  /** Abre o seletor e resolve com o id da parte (null = normal/dispensado). */
  static pick(n) {
    return new Promise((r) => {
      var o;
      (o = foundry.applications.instances.get("monster-anatomy-target-map")) == null || o.close(), new ne({ actor: n }, r).render(!0);
    });
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const r = await super._prepareContext(n), a = this.actor, o = de(a) && !te();
    return {
      ...r,
      actorName: a.name,
      canAdd: k(a),
      parts: y(a).map((i) => xn(i, o))
    };
  }
  async _onRender(n, r) {
    var o, i;
    await super._onRender(n, r);
    const a = (c) => {
      if (!b(this, H)) return;
      const s = b(this, H);
      I(this, H, null), s(c), this.close();
    };
    (o = this.element.querySelector("[data-parts]")) == null || o.addEventListener("click", (c) => {
      const s = c.target.closest("[data-part-id]"), u = s == null ? void 0 : s.dataset.partId;
      u && a(u);
    }), (i = this.element.querySelector("[data-normal]")) == null || i.addEventListener("click", () => a(null)), se(this, ee, Nt).call(this);
  }
  async close(n) {
    if (b(this, H)) {
      const r = b(this, H);
      I(this, H, null), r(null);
    }
    return super.close(n);
  }
};
H = new WeakMap(), ee = new WeakSet(), /** Quick-add: cria parte na hora (nome + imagem opcional) e atualiza a lista. */
Nt = function() {
  var i, c;
  const n = this.element.querySelector('[data-qa="name"]'), r = this.element.querySelector('[data-qa="img"]'), a = this.element.querySelector('[data-qa="preview"]');
  if (!n || !r) return;
  const o = () => {
    if (!a) return;
    const s = r.value.trim();
    a.hidden = s === "", s !== "" && (a.src = s);
  };
  r.addEventListener("input", o), a == null || a.addEventListener("error", () => {
    a && (a.hidden = !0);
  }), (i = this.element.querySelector("[data-qa-browse]")) == null || i.addEventListener("click", () => {
    new foundry.applications.apps.FilePicker({
      type: "image",
      current: r.value,
      callback: (u) => {
        r.value = u, o();
      }
    }).render(!0);
  }), (c = this.element.querySelector("[data-qa-add]")) == null || c.addEventListener("click", () => {
    se(this, ee, wt).call(this);
  });
}, wt = async function() {
  const n = this.actor;
  if (!k(n)) return;
  const r = this.element.querySelector('[data-qa="name"]'), a = this.element.querySelector('[data-qa="img"]');
  if (!r || !a) return;
  const o = y(n).length, i = r.value.trim() || `${p("MONSTER_ANATOMY.Part.New")} ${o + 1}`, c = Number(g("defaultAc") ?? 10), s = Number(g("defaultHp") ?? 20), u = ue(i, {
    ac: Number.isFinite(c) ? c : 10,
    hp: Number.isFinite(s) ? s : 20
  }), l = a.value.trim();
  l !== "" && (u.img = l), await ut(n, u), r.value = "", a.value = "", await this.render();
}, R(ne, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-target-map",
  classes: ["monster-anatomy", "monster-anatomy-target"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Target.Title",
    icon: "fa-solid fa-crosshairs",
    resizable: !1
  },
  position: { width: 340, height: "auto" },
  actions: {}
}), R(ne, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/target-map.hbs" }
});
let ke = ne, B = null;
function vt() {
  return B;
}
function _() {
  B = null, bt();
}
function bt() {
  var i;
  if ((i = document.getElementById("monster-anatomy-aim")) == null || i.remove(), !B) return;
  const e = fromUuidSync(B.actorUuid), t = e instanceof Actor ? y(e).find((c) => c.id === (B == null ? void 0 : B.partId)) : void 0;
  if (!t) return;
  const n = document.createElement("button");
  n.type = "button", n.id = "monster-anatomy-aim", n.className = "monster-anatomy ma-aim-chip", n.title = p("MONSTER_ANATOMY.Target.AimClear");
  const r = document.createElement("i");
  r.className = "fa-solid fa-crosshairs";
  const a = document.createElement("span");
  a.textContent = w("MONSTER_ANATOMY.Target.Aiming", { part: t.name });
  const o = document.createElement("i");
  o.className = "fa-solid fa-xmark", n.append(r, a, o), n.addEventListener("click", () => _()), document.body.append(n);
}
async function St(e) {
  var l;
  const t = re(e), n = /* @__PURE__ */ new Set();
  t && n.add(t);
  let r;
  for (const d of ((l = game.user) == null ? void 0 : l.targets) ?? []) {
    const T = re(d);
    T && (n.add(T), (T === t || !t && n.size === 1) && (r = d));
  }
  if (n.size !== 1) {
    _();
    return;
  }
  const a = [...n][0], o = t === a ? e : r, i = o == null ? void 0 : o.actor;
  if (!(i instanceof Actor)) {
    _();
    return;
  }
  if (y(i).length === 0) {
    _();
    return;
  }
  const s = await ke.pick(i);
  if (!s) {
    _();
    return;
  }
  const u = y(i).find((d) => d.id === s);
  if (!u) {
    _();
    return;
  }
  B = {
    tokenUuid: a,
    actorUuid: i.uuid,
    partId: u.id
  }, bt();
}
function Rn() {
  Hooks.on("targetToken", (e, t, n) => {
    var r;
    if (e.id === ((r = game.user) == null ? void 0 : r.id)) {
      if (!n) {
        B && re(t) === B.tokenUuid && _();
        return;
      }
      if (!g("promptOnTarget")) {
        _();
        return;
      }
      St(t);
    }
  });
}
const { ApplicationV2: _n, HandlebarsApplicationMixin: Yn } = foundry.applications.api;
var Ae, kt;
const D = class D extends Yn(_n) {
  constructor() {
    super(...arguments);
    V(this, Ae);
  }
  static async openFor(n, r, a) {
    const o = `monster-anatomy-editor-${n.uuid.replaceAll(".", "-")}-${r ?? "new"}`, i = foundry.applications.instances.get(o);
    if (i) {
      await i.render({ force: !0 }), i.bringToFront();
      return;
    }
    await new D({ id: o, actor: n, partId: r, onSaved: a }).render(!0);
  }
  get editorOptions() {
    return this.options;
  }
  get editing() {
    const { actor: n, partId: r } = this.editorOptions;
    if (r) {
      const i = y(n).find((c) => c.id === r);
      if (i) return Me(i);
    }
    const a = Number(g("defaultAc") ?? 10), o = Number(g("defaultHp") ?? 20);
    return ue("", {
      ac: Number.isFinite(a) ? a : 10,
      hp: Number.isFinite(o) ? o : 20
    });
  }
  get isNew() {
    return !this.editorOptions.partId;
  }
  async _prepareContext(n) {
    const r = await super._prepareContext(n), a = this.editing, o = this.editorOptions.actor, i = be(), c = (s) => {
      var u;
      return ((u = i.find((l) => l.key === s)) == null ? void 0 : u.label) ?? s;
    };
    return {
      ...r,
      part: a,
      isNew: this.isNew,
      actorName: o.name,
      link: K(a),
      sever: a.sever ?? { value: a.hp.max, max: a.hp.max },
      severTypes: a.severTypes ?? ["slashing"],
      rewards: ye(a).map((s) => ({ ...s })),
      items: [...o.items].flatMap(
        (s) => typeof s.id == "string" ? [{ id: s.id, label: `${s.name} (${s.type})` }] : []
      ),
      damageTypes: be(),
      physicalTypes: Bt.map((s) => ({
        key: s,
        label: c(s),
        checked: (a.severTypes ?? ["slashing"]).includes(s)
      })),
      hitzones: i.map((s) => {
        var u;
        return {
          key: s.key,
          label: s.label,
          value: ((u = a.hitzone) == null ? void 0 : u[s.key]) ?? 1
        };
      }),
      statuses: (CONFIG.statusEffects ?? []).filter((s) => typeof (s == null ? void 0 : s.id) == "string").map((s) => ({ value: s.id, label: s.name ?? s.id })),
      states: Object.entries(oe).map(
        ([s, u]) => ({ value: s, label: p(u) })
      )
    };
  }
  async _onRender(n, r) {
    var i;
    await super._onRender(n, r), (i = this.element.querySelector("form.monster-anatomy-form")) == null || i.addEventListener("submit", (c) => void se(this, Ae, kt).call(this, c));
    const a = this.element.querySelector("#ma-img"), o = this.element.querySelector(".ma-imgpreview");
    a == null || a.addEventListener("input", () => et(a, o)), o == null || o.addEventListener("error", () => {
      o && (o.hidden = !0);
    });
  }
  static onBrowseImage(n, r) {
    const a = this, o = a.element.querySelector("#ma-img"), i = a.element.querySelector(".ma-imgpreview");
    new foundry.applications.apps.FilePicker({
      type: "image",
      current: (o == null ? void 0 : o.value) ?? "",
      callback: (s) => {
        o && (o.value = s, o.dispatchEvent(new Event("input", { bubbles: !0 }))), et(o, i);
      }
    }).render(!0);
  }
  static onAddReward(n, r) {
    const o = this.element.querySelector("[data-rewards]");
    if (!o) return;
    const i = document.createElement("div");
    i.className = "ma-reward", i.setAttribute("data-reward", ""), i.setAttribute("data-reward-id", foundry.utils.randomID()), i.innerHTML = `<select name="rw_event" title="${p("MONSTER_ANATOMY.Editor.RewardEvent")}"><option value="break">${p("MONSTER_ANATOMY.Reward.Break")}</option><option value="sever">${p("MONSTER_ANATOMY.Reward.Sever")}</option></select><select name="rw_kind" title="${p("MONSTER_ANATOMY.Editor.RewardKind")}"><option value="table">${p("MONSTER_ANATOMY.Reward.TableKind")}</option><option value="item">${p("MONSTER_ANATOMY.Reward.ItemKind")}</option></select><input name="rw_table" type="text" placeholder="RollTable.xxx / Item.xxx" title="${p("MONSTER_ANATOMY.Editor.RewardTable")}" /><input name="rw_draws" type="number" min="1" max="20" step="1" value="1" title="${p("MONSTER_ANATOMY.Editor.RewardDraws")}" /><button type="button" data-action="remove-reward" title="${p("MONSTER_ANATOMY.Editor.RewardRemove")}"><i class="fa-solid fa-xmark"></i></button>`, o.appendChild(i);
  }
  static onRemoveReward(n, r) {
    var a;
    (a = r.closest("[data-reward]")) == null || a.remove();
  }
};
Ae = new WeakSet(), kt = async function(n) {
  var qe, ze, Ve, Ge;
  n.preventDefault();
  const r = n.target, a = new FormData(r), o = (N) => String(a.get(N) ?? "").trim(), i = (N, O) => {
    const P = Number(a.get(N));
    return Number.isFinite(P) ? P : O;
  }, { actor: c, partId: s, onSaved: u } = this.editorOptions, l = s ? y(c).find((N) => N.id === s) : void 0, d = Math.max(1, Math.floor(i("hpMax", (l == null ? void 0 : l.hp.max) ?? 10))), T = Math.max(0, Math.floor(i("regen", (l == null ? void 0 : l.regen) ?? 0))), M = o("phaseName"), h = o("zone"), f = h === "head" || h === "torso" || h === "left" || h === "right" || h === "tail" ? h : (l == null ? void 0 : l.zone) ?? null, F = o("effectDuration"), C = o("disableItemId"), z = {
    disableItemId: C,
    disableItemName: ((qe = c.items.get(C)) == null ? void 0 : qe.name) ?? "",
    effectName: o("effectName"),
    effectIcon: o("effectIcon"),
    effectDuration: F === "" ? null : Math.max(0, Math.floor(i("effectDuration", 0))),
    condition: o("condition"),
    setAttrPath: o("setAttrPath"),
    setAttrValue: o("setAttrValue"),
    macroUuid: o("macroUuid")
  }, $ = {};
  for (const { key: N } of be()) {
    const O = a.get(`hz_${N}`);
    if (O == null) continue;
    const P = Number(O);
    !Number.isFinite(P) || P < 0 || P === 1 || !N || ($[N] = Math.round(P * 100) / 100);
  }
  const A = a.getAll("severType").filter((N) => typeof N == "string" && N !== ""), x = Math.max(
    1,
    Math.floor(i("severMax", ((ze = l == null ? void 0 : l.sever) == null ? void 0 : ze.max) ?? d))
  ), Ne = ((Ve = l == null ? void 0 : l.sever) == null ? void 0 : Ve.value) ?? x, j = o("bonusMode"), Rt = {
    mode: j === "off" || j === "percent" || j === "flat" ? j : "inherit",
    value: Math.max(0, i("bonusValue", 0))
  }, Ue = [];
  r.querySelectorAll("[data-reward]").forEach((N) => {
    const O = (Pt) => {
      var Ke, je;
      return ((je = (Ke = N.querySelector(Pt)) == null ? void 0 : Ke.value) == null ? void 0 : je.trim()) ?? "";
    }, P = O('input[name="rw_table"]');
    if (!P) return;
    const _t = O('select[name="rw_event"]'), Yt = O('select[name="rw_kind"]');
    Ue.push({
      id: N.dataset.rewardId || foundry.utils.randomID(),
      kind: Yt === "item" ? "item" : "table",
      uuid: P,
      draws: Math.max(1, Math.min(20, Math.floor(Number(O('input[name="rw_draws"]')) || 1))),
      onEvent: _t === "sever" ? "sever" : "break"
    });
  });
  const J = {
    id: (l == null ? void 0 : l.id) ?? "",
    name: o("name"),
    img: o("img"),
    zone: f,
    ac: Math.max(0, Math.floor(i("ac", (l == null ? void 0 : l.ac) ?? 10))),
    hp: {
      max: d,
      value: Math.max(0, Math.min(d, Math.floor(i("hpValue", (l == null ? void 0 : l.hp.value) ?? d))))
    },
    breakable: a.get("breakable") === "on",
    severable: a.get("severable") === "on",
    state: o("state") || (l == null ? void 0 : l.state) || "intact",
    notes: o("notes"),
    regen: T,
    phaseName: M,
    onBreak: z,
    hitzone: $,
    sever: { value: Math.min(x, Ne), max: x },
    severTypes: A,
    rewards: Ue,
    bonus: Rt
  };
  if (zt(J).length > 0) {
    (Ge = ui.notifications) == null || Ge.error(p("MONSTER_ANATOMY.Editor.Invalid"));
    return;
  }
  if (l) {
    const { id: N, ...O } = J;
    await le(c, l.id, O);
  } else {
    const N = ue(J.name || p("MONSTER_ANATOMY.Part.New"), {
      ac: J.ac,
      hp: J.hp.max
    });
    await ut(c, { ...N, ...J, id: N.id });
  }
  u == null || u(), await this.close();
}, R(D, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-part-editor",
  classes: ["monster-anatomy", "monster-anatomy-editor"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Editor.Title",
    icon: "fa-solid fa-pen-to-square",
    resizable: !1
  },
  position: { width: 460, height: "auto" },
  actions: {
    "add-reward": D.onAddReward,
    "remove-reward": D.onRemoveReward,
    "browse-image": D.onBrowseImage
  }
}), R(D, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/part-editor.hbs" }
});
let fe = D;
function et(e, t) {
  var r;
  if (!t) return;
  const n = ((r = e == null ? void 0 : e.value) == null ? void 0 : r.trim()) ?? "";
  t.hidden = n === "", n !== "" && (t.src = n);
}
function be() {
  var t;
  const e = (t = CONFIG == null ? void 0 : CONFIG.DND5E) == null ? void 0 : t.damageTypes;
  return e && typeof e == "object" ? Object.entries(e).map(([n, r]) => ({
    key: n,
    label: Pn(
      typeof r == "string" ? r : typeof (r == null ? void 0 : r.label) == "string" ? r.label : n
    )
  })) : [...$t].map((n) => ({ key: n, label: n }));
}
function Pn(e) {
  try {
    return p(e);
  } catch {
    return e;
  }
}
const { ApplicationV2: In, HandlebarsApplicationMixin: Hn } = foundry.applications.api;
var L;
const ae = class ae extends Hn(In) {
  constructor() {
    super(...arguments);
    V(this, L, null);
  }
  static async openFor(n) {
    const r = `monster-anatomy-tracker-${n.uuid.replaceAll(".", "-")}`, a = foundry.applications.instances.get(r);
    if (a) {
      await a.render({ force: !0 }), a.bringToFront();
      return;
    }
    await new ae({ id: r, actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const r = await super._prepareContext(n), a = y(this.actor).map((o) => {
      const i = o.hp.max > 0 ? o.hp.value / o.hp.max * 100 : 0;
      return {
        ...o,
        hp: { ...o.hp },
        hpPct: Math.max(0, Math.min(100, Math.round(i))),
        stateLabel: p(oe[o.state])
      };
    });
    return {
      ...r,
      actorName: this.actor.name,
      parts: a,
      empty: a.length === 0
    };
  }
  async _onRender(n, r) {
    await super._onRender(n, r), b(this, L) === null && I(this, L, Hooks.on("updateActor", (a) => {
      a.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(n) {
    return b(this, L) !== null && (Hooks.off("updateActor", b(this, L)), I(this, L, null)), super.close(n);
  }
};
L = new WeakMap(), R(ae, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-tracker",
  classes: ["monster-anatomy", "monster-anatomy-tracker"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Tracker.Title",
    icon: "fa-solid fa-heart-pulse",
    resizable: !0
  },
  position: { width: 320, height: "auto" },
  actions: {}
}), R(ae, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-tracker.hbs" }
});
let pe = ae;
const { ApplicationV2: Bn, HandlebarsApplicationMixin: $n } = foundry.applications.api;
var U;
const X = class X extends $n(Bn) {
  constructor() {
    super(...arguments);
    V(this, U, null);
  }
  static async openFor(n) {
    const r = `monster-anatomy-summary-${n.uuid.replaceAll(".", "-")}`, a = foundry.applications.instances.get(r);
    if (a) {
      await a.render({ force: !0 }), a.bringToFront();
      return;
    }
    await new X({ id: r, actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const r = await super._prepareContext(n), a = this.actor, o = y(a).map((c) => ({
      name: c.name,
      stateLabel: p(oe[c.state]),
      hp: `${c.hp.value} / ${c.hp.max}`
    })), i = Mt(a).map((c) => ({
      ...c,
      eventLabel: p(
        c.event === "sever" ? "MONSTER_ANATOMY.Reward.Sever" : "MONSTER_ANATOMY.Reward.Break"
      ),
      itemsText: c.items.join(", ")
    }));
    return {
      ...r,
      actorName: a.name,
      parts: o,
      loot: i,
      emptyParts: o.length === 0,
      emptyLoot: i.length === 0,
      canClear: k(a)
    };
  }
  async _onRender(n, r) {
    await super._onRender(n, r), b(this, U) === null && I(this, U, Hooks.on("updateActor", (a) => {
      a.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(n) {
    return b(this, U) !== null && (Hooks.off("updateActor", b(this, U)), I(this, U, null)), super.close(n);
  }
  static async onClearLoot(n, r) {
    const a = this;
    k(a.actor) && await wn(a.actor);
  }
};
U = new WeakMap(), R(X, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-summary",
  classes: ["monster-anatomy", "monster-anatomy-summary"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Summary.Title",
    icon: "fa-solid fa-scroll",
    resizable: !0
  },
  position: { width: 460, height: "auto" },
  actions: {
    "clear-loot": X.onClearLoot
  }
}), R(X, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/loot-summary.hbs" }
});
let he = X;
const { ApplicationV2: Fn, HandlebarsApplicationMixin: Cn } = foundry.applications.api;
function Dn(e, t, n) {
  const r = e.hp.max > 0 ? e.hp.value / e.hp.max * 100 : 0, a = K(e).disableItemId.trim(), o = a ? t.items.get(a) : void 0, i = e.sever ?? { value: e.hp.max, max: e.hp.max }, c = i.max > 0 ? i.value / i.max * 100 : 0;
  return {
    ...e,
    hp: { ...e.hp },
    sever: { value: i.value, max: i.max },
    hpPct: Math.max(0, Math.min(100, Math.round(r))),
    stateLabel: p(oe[e.state]),
    hpMismatch: qt(e) !== e.state,
    linkedItemName: (o == null ? void 0 : o.name) ?? a,
    linkedDisabled: a !== "" && G(e.state),
    severPct: Math.max(0, Math.min(100, Math.round(c))),
    acDisplay: n ? "??" : String(e.ac)
  };
}
function tt(e) {
  const t = e.closest(".ma-part"), n = t == null ? void 0 : t.querySelector("input.ma-amount"), r = Math.floor(Number(n == null ? void 0 : n.value));
  return Number.isFinite(r) && r > 0 ? r : null;
}
var q;
const v = class v extends Cn(Fn) {
  constructor() {
    super(...arguments);
    V(this, q, null);
  }
  /** Abre o painel para um Actor. */
  static async openFor(n) {
    const r = `monster-anatomy-panel-${n.uuid.replaceAll(".", "-")}`, a = foundry.applications.instances.get(r);
    if (a) {
      await a.render({ force: !0 }), a.bringToFront();
      return;
    }
    await new v({ id: r, actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const r = await super._prepareContext(n), a = this.actor, o = te(), i = de(a), c = i && !o, s = y(a).map((u) => Dn(u, a, c));
    return {
      ...r,
      actorName: a.name,
      actorImg: a.img ?? "icons/svg/mystery-man.svg",
      canEdit: k(a),
      isGM: o,
      hideAc: i,
      phase: ft(a),
      templates: _e().map((u) => ({ id: u.id, name: an(u) })),
      parts: s,
      empty: s.length === 0
    };
  }
  async _onRender(n, r) {
    await super._onRender(n, r), b(this, q) === null && (I(this, q, Hooks.on("updateActor", (a) => {
      a.uuid === this.actor.uuid && this.render();
    })), Q(W.PANEL_RENDER, this));
  }
  async close(n) {
    return b(this, q) !== null && (Hooks.off("updateActor", b(this, q)), I(this, q, null)), super.close(n);
  }
  // -- actions (this = instância, injetado pelo ApplicationV2) -----------------
  static async onAddPart(n, r) {
    const a = this;
    k(a.actor) && await fe.openFor(a.actor, void 0, () => void a.render());
  }
  static async onDuplicatePart(n, r) {
    const a = this;
    if (!k(a.actor)) return;
    const o = r.dataset.partId;
    o && await lt(a.actor, o);
  }
  static async onEditPart(n, r) {
    const a = this;
    if (!k(a.actor)) return;
    const o = r.dataset.partId;
    o && await fe.openFor(a.actor, o, () => void a.render());
  }
  static async onOpenTracker(n, r) {
    const a = this;
    await pe.openFor(a.actor);
  }
  static async onOpenSummary(n, r) {
    const a = this;
    await he.openFor(a.actor);
  }
  static async onDamagePart(n, r) {
    const a = this;
    if (!k(a.actor)) return;
    const o = r.dataset.partId, i = tt(r);
    !o || i === null || await Tt(a.actor, o, i);
  }
  static async onHealPart(n, r) {
    const a = this;
    if (!k(a.actor)) return;
    const o = r.dataset.partId, i = tt(r);
    !o || i === null || await Le(a.actor, o, i);
  }
  static async onDeletePart(n, r) {
    const a = this;
    if (!k(a.actor)) return;
    const o = r.dataset.partId, i = y(a.actor).find((s) => s.id === o);
    !o || !i || !await foundry.applications.api.DialogV2.confirm({
      window: { title: p("MONSTER_ANATOMY.Delete.Title") },
      content: `<p>${w("MONSTER_ANATOMY.Delete.Prompt", { name: i.name })}</p>`,
      modal: !0
    }) || await nn(a.actor, o);
  }
  static async onApplyTemplate(n, r) {
    var c;
    const a = this;
    if (!k(a.actor)) return;
    const o = a.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (i)
      try {
        const s = await dt(a.actor, i);
        (c = ui.notifications) == null || c.info(w("MONSTER_ANATOMY.Template.Applied", { count: String(s) }));
      } catch (s) {
        console.warn("monster-anatomy | falha ao aplicar modelo", s);
      }
  }
  static async onSaveTemplate(n, r) {
    var c, s;
    const a = this;
    if (!te()) return;
    const o = y(a.actor);
    if (o.length === 0) {
      (c = ui.notifications) == null || c.warn(p("MONSTER_ANATOMY.Template.Empty"));
      return;
    }
    const i = await Ln(a.actor.name);
    i && (await rn(i, o), (s = ui.notifications) == null || s.info(w("MONSTER_ANATOMY.Template.Saved", { name: i })), a.render());
  }
  static async onDeleteTemplate(n, r) {
    var s, u;
    const a = this;
    if (!te()) return;
    const o = a.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (!i) return;
    if (!await on(i)) {
      (s = ui.notifications) == null || s.warn(p("MONSTER_ANATOMY.Template.Protected"));
      return;
    }
    (u = ui.notifications) == null || u.info(p("MONSTER_ANATOMY.Template.Deleted")), a.render();
  }
  static async onToggleHideAc(n, r) {
    const a = this;
    te() && await cn(a.actor, !de(a.actor));
  }
};
q = new WeakMap(), R(v, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-panel",
  classes: ["monster-anatomy", "monster-anatomy-panel"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Panel.Title",
    icon: "fa-solid fa-dragon",
    resizable: !0
  },
  position: { width: 500, height: "auto" },
  actions: {
    "add-part": v.onAddPart,
    "edit-part": v.onEditPart,
    "delete-part": v.onDeletePart,
    "duplicate-part": v.onDuplicatePart,
    "open-tracker": v.onOpenTracker,
    "open-summary": v.onOpenSummary,
    "damage-part": v.onDamagePart,
    "heal-part": v.onHealPart,
    "apply-template": v.onApplyTemplate,
    "save-template": v.onSaveTemplate,
    "delete-template": v.onDeleteTemplate,
    "toggle-hide-ac": v.onToggleHideAc
  }
}), R(v, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-panel.hbs" }
});
let Oe = v;
async function Ln(e) {
  const t = await foundry.applications.api.DialogV2.wait({
    window: { title: p("MONSTER_ANATOMY.Template.NameTitle") },
    content: `<div class="form-group"><label>${p("MONSTER_ANATOMY.Template.NamePrompt")}</label><input name="templateName" type="text" value="${e}" maxlength="80" /></div>`,
    buttons: [
      {
        action: "save",
        label: p("MONSTER_ANATOMY.Editor.Save"),
        default: !0,
        callback: (n, r) => {
          var o, i;
          const a = (o = r.form) == null ? void 0 : o.querySelector(
            'input[name="templateName"]'
          );
          return ((i = a == null ? void 0 : a.value) == null ? void 0 : i.trim()) ?? "";
        }
      }
    ],
    modal: !0
  });
  return typeof t != "string" || t.trim() === "" ? null : t.trim();
}
function Un() {
  var t, n;
  return {
    version: ((n = (t = game.modules) == null ? void 0 : t.get(m)) == null ? void 0 : n.version) ?? "0.0.0",
    async openAnatomy(r) {
      await Oe.openFor(r);
    },
    getParts(r) {
      return y(r);
    },
    canEdit(r) {
      return k(r);
    },
    damagePart(r, a, o, i) {
      return Tt(r, a, o, i);
    },
    healPart(r, a, o) {
      return Le(r, a, o);
    },
    damagePartDetailed(r, a, o, i) {
      return Te(r, a, o, i);
    },
    getSelection() {
      return vt();
    },
    clearSelection() {
      _();
    },
    promptTargetSelection(r) {
      return St(r);
    },
    openTracker(r) {
      return pe.openFor(r);
    },
    openSummary(r) {
      return he.openFor(r);
    },
    on(r, a) {
      const o = r.startsWith("monsterAnatomy.") ? r : `monsterAnatomy.${r}`, i = ce(o, a);
      return () => Vt(o, i);
    },
    getTemplates() {
      return _e();
    },
    applyTemplate(r, a) {
      return dt(r, a);
    },
    duplicatePart(r, a) {
      return lt(r, a);
    }
  };
}
function qn(e) {
  globalThis.MonsterAnatomy = e;
}
function E(e) {
  return typeof e == "string" ? e : "";
}
function zn(e) {
  if (!Array.isArray(e)) return [];
  const t = [];
  for (const n of e) {
    if (!n || typeof n != "object") continue;
    const r = Math.max(0, Math.floor(Number(n.amount) || 0));
    if (r <= 0) continue;
    const a = n.type;
    t.push(typeof a == "string" && a ? { amount: r, type: a } : { amount: r });
  }
  return t;
}
function Vn() {
  var e;
  return ((e = game.users) == null ? void 0 : e.some((t) => t.isGM && t.active)) ?? !1;
}
function Gn(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function Kn() {
  var e;
  (e = game.socket) == null || e.on(`module.${m}`, (t) => {
    jn(t);
  });
}
async function jn(e) {
  var n, r, a;
  if (!e || typeof e != "object") return;
  const t = e;
  if (t.t === "apply") {
    if (!((n = game.user) != null && n.isActiveGM)) return;
    const o = await fromUuid(
      E(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = typeof t.attacker == "string" ? t.attacker : void 0, c = typeof t.attackerUuid == "string" ? t.attackerUuid : void 0, s = await Te(
      o,
      E(t.partId),
      zn(t.components),
      { attacker: i, attackerUuid: c }
    );
    await yt(
      o,
      ((r = y(o).find((u) => u.id === E(t.partId))) == null ? void 0 : r.name) ?? E(t.partId),
      s.applied,
      s.globalApplied,
      s.bonus,
      s.bonusFlat
    ), s.broke && Z(E(t.actorUuid), E(t.partId), "break"), s.severed && Z(E(t.actorUuid), E(t.partId), "sever"), s.phased !== "" && Z(E(t.actorUuid), E(t.partId), "phase");
  } else if (t.t === "present") {
    if (typeof t.by == "string" && t.by === ((a = game.user) == null ? void 0 : a.id)) return;
    const o = await fromUuid(
      E(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = y(o).find((c) => c.id === E(t.partId));
    if (!i) return;
    t.kind === "sever" ? gt(o, i) : t.kind === "phase" ? At(o, i, ft(o) || "?") : ht(o, i);
  }
}
function Ot(e) {
  var t;
  try {
    (t = game.socket) == null || t.emit(`module.${m}`, e);
  } catch (n) {
    console.warn("monster-anatomy | falha no socket", n);
  }
}
function Jn(e, t, n, r, a) {
  var i;
  const o = { t: "apply", actorUuid: e, partId: t, components: n, attacker: r, attackerUuid: a, by: (i = game.user) == null ? void 0 : i.id };
  Ot(o);
}
function Z(e, t, n = "break") {
  var a;
  const r = { t: "present", actorUuid: e, partId: t, kind: n, by: (a = game.user) == null ? void 0 : a.id };
  Ot(r);
}
let ge = null;
function Wn() {
  ce("dnd5e.rollAttackV2", (...e) => void Xn(e)), ce("dnd5e.rollDamageV2", (...e) => void Zn(e)), ce("dnd5e.preUseActivity", (...e) => Qn(e)), Hooks.on("targetToken", (e, t, n) => {
    var r;
    e.id === ((r = game.user) == null ? void 0 : r.id) && (ge = null);
  });
}
function Qn(e) {
  var i;
  const [t] = e, n = t == null ? void 0 : t.item, r = t == null ? void 0 : t.actor, a = r instanceof Actor ? r : (n == null ? void 0 : n.parent) instanceof Actor ? n.parent : void 0;
  if (!a || typeof (n == null ? void 0 : n.id) != "string" || !Gt(a).has(n.id)) return;
  const o = Kt(a, n.id);
  return (i = ui.notifications) == null || i.warn(
    w("MONSTER_ANATOMY.Usage.Blocked", {
      item: typeof n.name == "string" ? n.name : n.id,
      part: (o == null ? void 0 : o.name) ?? "",
      actor: a.name
    })
  ), !1;
}
async function Xn(e) {
  var C, z;
  const t = vt();
  if (!t) return;
  const n = [...((C = game.user) == null ? void 0 : C.targets) ?? []], r = n.length === 1 ? n[0] : void 0, a = re(r), o = r == null ? void 0 : r.actor;
  if (!r || !a || !o || a !== t.tokenUuid || o.uuid !== t.actorUuid) {
    _();
    return;
  }
  const [i, c] = e, s = i == null ? void 0 : i[0], u = Number((s == null ? void 0 : s.total) ?? NaN);
  if (!Number.isFinite(u)) return;
  const l = ta(s), d = l === 20, T = l === 1, M = y(o).find(($) => $.id === t.partId);
  if (!M) {
    _();
    return;
  }
  const h = d || !T && u >= M.ac, f = na(c == null ? void 0 : c.subject), F = (f == null ? void 0 : f.name) ?? ((z = game.user) == null ? void 0 : z.name) ?? "?";
  if (ge = {
    tokenUuid: a,
    actorUuid: o.uuid,
    partId: M.id,
    hit: h,
    crit: d,
    attacker: F,
    attackerUuid: f == null ? void 0 : f.uuid
  }, g("attackNotes")) {
    const $ = h ? "MONSTER_ANATOMY.Attack.Hit" : "MONSTER_ANATOMY.Attack.Miss", A = d && h ? ` ${p("MONSTER_ANATOMY.Attack.CritSuffix")}` : "", x = de(o) ? "??" : String(M.ac), Ne = `<div class="monster-anatomy-chat ma-attack"><p>${w($, {
      attacker: F,
      part: M.name,
      actor: o.name,
      total: String(u),
      ac: x
    })}${A}</p></div>`, j = f ? ChatMessage.getSpeaker({ actor: f }) : ChatMessage.getSpeaker({ alias: F });
    await ChatMessage.create({ speaker: j, content: Ne });
  }
}
async function Zn(e) {
  var c, s, u, l;
  const t = ge;
  if (ge = null, !(t != null && t.hit)) return;
  const [n] = e, r = (n ?? []).map((d) => ({ amount: Number(d == null ? void 0 : d.total) || 0, type: ea(d) })).filter((d) => d.amount > 0);
  if (r.length === 0) return;
  const a = [...((c = game.user) == null ? void 0 : c.targets) ?? []].find((d) => re(d) === t.tokenUuid), o = a == null ? void 0 : a.actor;
  if (!o || o.uuid !== t.actorUuid) return;
  const i = ((s = y(o).find((d) => d.id === t.partId)) == null ? void 0 : s.name) ?? t.partId;
  if (Gn(o)) {
    const d = await Te(o, t.partId, r, {
      attacker: t.attacker,
      attackerUuid: t.attackerUuid
    });
    await yt(o, i, d.applied, d.globalApplied, d.bonus, d.bonusFlat), d.broke && Z(o.uuid, t.partId, "break"), d.severed && Z(o.uuid, t.partId, "sever"), d.phased !== "" && Z(o.uuid, t.partId, "phase");
  } else Vn() ? (Jn(o.uuid, t.partId, r, t.attacker, t.attackerUuid), (u = ui.notifications) == null || u.info(w("MONSTER_ANATOMY.Target.SentToGM", { part: i }))) : (l = ui.notifications) == null || l.warn(p("MONSTER_ANATOMY.Target.NoGM"));
}
function ea(e) {
  var r, a;
  const t = e;
  if (typeof ((r = t.options) == null ? void 0 : r.type) == "string" && t.options.type) return t.options.type;
  const n = (a = t.options) == null ? void 0 : a.types;
  if (Array.isArray(n) && typeof n[0] == "string" && n[0]) return n[0];
}
function ta(e) {
  var n;
  const t = e == null ? void 0 : e.dice;
  if (Array.isArray(t))
    for (const r of t) {
      if ((r == null ? void 0 : r.faces) !== 20) continue;
      const a = r == null ? void 0 : r.results;
      if (!Array.isArray(a)) continue;
      const o = (n = a[0]) == null ? void 0 : n.result;
      if (typeof o == "number") return o;
    }
}
function na(e) {
  const t = e == null ? void 0 : e.actor;
  return t instanceof Actor ? t : void 0;
}
function aa() {
  Hooks.on("combatTurnChange", (e, t, n) => {
    var c;
    if (!((c = game.user) != null && c.isActiveGM)) return;
    const r = t, a = n;
    if (r && a) {
      const s = r.round ?? 0, u = a.round ?? 0;
      if (u < s || u === s && (a.turn ?? 0) < (r.turn ?? 0)) return;
    }
    const o = a != null && a.combatantId ? e.combatants.get(a.combatantId) : void 0, i = o == null ? void 0 : o.actor;
    i instanceof Actor && ra(i);
  });
}
async function ra(e) {
  const t = y(e).filter(
    (a) => (a.regen ?? 0) > 0 && a.hp.value < a.hp.max && a.state !== "destroyed"
  );
  if (t.length === 0) return;
  const n = [];
  for (const a of t)
    try {
      const o = Math.max(1, Math.floor(a.regen ?? 0)), i = a.hp.value, c = await Le(e, a.id, o), s = c.hp.value - i;
      s > 0 && n.push(`${c.name} +${s}`);
    } catch (o) {
      console.warn("monster-anatomy | falha na regeneração", o);
    }
  if (n.length === 0) return;
  let r = !1;
  try {
    r = g("chatMessage") === !0;
  } catch {
    return;
  }
  r && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-regen"><p>${w("MONSTER_ANATOMY.Regen.Text", {
      actor: e.name,
      bits: n.join(", ")
    })}</p></div>`
  });
}
function oa() {
  Rn(), Wn(), aa();
}
function ia() {
  game.settings.register(m, "showHeaderButton", {
    name: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "defaultAc", {
    name: "MONSTER_ANATOMY.Settings.DefaultAc.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultAc.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 10
  }), game.settings.register(m, "defaultHp", {
    name: "MONSTER_ANATOMY.Settings.DefaultHp.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultHp.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 20
  }), game.settings.register(m, "damageModel", {
    name: "MONSTER_ANATOMY.Settings.DamageModel.Name",
    hint: "MONSTER_ANATOMY.Settings.DamageModel.Hint",
    scope: "world",
    config: !0,
    type: String,
    choices: {
      independent: "MONSTER_ANATOMY.Settings.DamageModel.Independent",
      shared: "MONSTER_ANATOMY.Settings.DamageModel.Shared",
      percent: "MONSTER_ANATOMY.Settings.DamageModel.Percent"
    },
    default: "shared"
  }), game.settings.register(m, "damagePercent", {
    name: "MONSTER_ANATOMY.Settings.DamagePercent.Name",
    hint: "MONSTER_ANATOMY.Settings.DamagePercent.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 100, step: 5 },
    default: 50
  }), game.settings.register(m, "brokenBonus", {
    name: "MONSTER_ANATOMY.Settings.BrokenBonus.Name",
    hint: "MONSTER_ANATOMY.Settings.BrokenBonus.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 200, step: 5 },
    default: 50
  }), game.settings.register(m, "showAnnouncement", {
    name: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "announceDuration", {
    name: "MONSTER_ANATOMY.Settings.AnnounceDuration.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceDuration.Hint",
    scope: "client",
    config: !0,
    type: Number,
    range: { min: 0.5, max: 10, step: 0.5 },
    default: 2.5
  }), game.settings.register(m, "chatMessage", {
    name: "MONSTER_ANATOMY.Settings.ChatMessage.Name",
    hint: "MONSTER_ANATOMY.Settings.ChatMessage.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "tokenEffect", {
    name: "MONSTER_ANATOMY.Settings.TokenEffect.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenEffect.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "breakSound", {
    name: "MONSTER_ANATOMY.Settings.BreakSound.Name",
    hint: "MONSTER_ANATOMY.Settings.BreakSound.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "promptOnTarget", {
    name: "MONSTER_ANATOMY.Settings.PromptOnTarget.Name",
    hint: "MONSTER_ANATOMY.Settings.PromptOnTarget.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "attackNotes", {
    name: "MONSTER_ANATOMY.Settings.AttackNotes.Name",
    hint: "MONSTER_ANATOMY.Settings.AttackNotes.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "announceTheme", {
    name: "MONSTER_ANATOMY.Settings.AnnounceTheme.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceTheme.Hint",
    scope: "client",
    config: !0,
    type: String,
    choices: {
      persona: "MONSTER_ANATOMY.Settings.AnnounceTheme.Persona",
      monsterhunter: "MONSTER_ANATOMY.Settings.AnnounceTheme.MonsterHunter",
      jrpg: "MONSTER_ANATOMY.Settings.AnnounceTheme.Jrpg",
      minimal: "MONSTER_ANATOMY.Settings.AnnounceTheme.Minimal",
      impact: "MONSTER_ANATOMY.Settings.AnnounceTheme.Impact",
      arcade: "MONSTER_ANATOMY.Settings.AnnounceTheme.Arcade",
      carved: "MONSTER_ANATOMY.Settings.AnnounceTheme.Carved"
    },
    default: "persona"
  }), game.settings.register(m, "customKickerBreak", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "customKickerSever", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerSever.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerSever.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "tokenShake", {
    name: "MONSTER_ANATOMY.Settings.TokenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "screenFlash", {
    name: "MONSTER_ANATOMY.Settings.ScreenFlash.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenFlash.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "reducedMotion", {
    name: "MONSTER_ANATOMY.Settings.ReducedMotion.Name",
    hint: "MONSTER_ANATOMY.Settings.ReducedMotion.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !1
  }), game.settings.register(m, "particles", {
    name: "MONSTER_ANATOMY.Settings.Particles.Name",
    hint: "MONSTER_ANATOMY.Settings.Particles.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "screenShake", {
    name: "MONSTER_ANATOMY.Settings.ScreenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "templatesJson", {
    name: "MONSTER_ANATOMY.Settings.TemplatesJson.Name",
    hint: "MONSTER_ANATOMY.Settings.TemplatesJson.Hint",
    scope: "world",
    config: !1,
    type: String,
    default: "[]"
  });
}
function Et(e) {
  const t = e == null ? void 0 : e.document;
  return t instanceof Actor ? t : void 0;
}
function xt() {
  try {
    return g("showHeaderButton");
  } catch {
    return !0;
  }
}
function nt(e, t) {
  const n = Et(e);
  !n || !Array.isArray(t) || !xt() || t.some((r) => (r == null ? void 0 : r.action) === "monster-anatomy") || t.unshift({
    action: "monster-anatomy",
    label: "MONSTER_ANATOMY.Panel.OpenButton",
    icon: "fa-solid fa-dragon",
    onClick: () => {
      var r;
      (r = it()) == null || r.openAnatomy(n);
    }
  });
}
function sa() {
  Hooks.on("getHeaderControlsActorSheetV2", (...e) => {
    nt(e[0], e[1]);
  }), Hooks.on("getHeaderControlsApplicationV2", (...e) => {
    nt(e[0], e[1]);
  }), Hooks.on("getActorSheetHeaderButtons", (...e) => {
    const [t, n] = e, r = Et(t) ?? (t == null ? void 0 : t.actor);
    if (!(r instanceof Actor) || !Array.isArray(n) || !xt()) return;
    const a = r;
    n.unshift({
      class: "monster-anatomy-open",
      icon: "fas fa-dragon",
      label: "MONSTER_ANATOMY.Panel.OpenButton",
      onclick: () => {
        var o;
        (o = it()) == null || o.openAnatomy(a);
      }
    });
  });
}
async function ca() {
  await foundry.applications.handlebars.loadTemplates([
    "modules/monster-anatomy/templates/anatomy-panel.hbs",
    "modules/monster-anatomy/templates/anatomy-tracker.hbs",
    "modules/monster-anatomy/templates/loot-summary.hbs",
    "modules/monster-anatomy/templates/part-editor.hbs",
    "modules/monster-anatomy/templates/target-map.hbs"
  ]);
}
function Se(e, t) {
  try {
    t();
  } catch (n) {
    console.error(`${m} | falha no init (${e})`, n);
  }
}
Hooks.once("init", () => {
  var n;
  console.log(`${m} | init`), Se("settings", ia), Se("header", sa), Se("combat", oa);
  const e = Un(), t = (n = game.modules) == null ? void 0 : n.get(m);
  t && (t.api = e), qn(e), ca();
});
Hooks.once("setup", () => {
  console.log(`${m} | setup`);
});
Hooks.once("ready", () => {
  var e, t;
  console.log(`${m} | ready (v${((t = (e = game.modules) == null ? void 0 : e.get(m)) == null ? void 0 : t.version) ?? "?"})`), Kn();
});
//# sourceMappingURL=main.js.map
