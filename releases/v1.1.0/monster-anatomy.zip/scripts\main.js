var Ot = Object.defineProperty;
var De = (e) => {
  throw TypeError(e);
};
var kt = (e, t, a) => t in e ? Ot(e, t, { enumerable: !0, configurable: !0, writable: !0, value: a }) : e[t] = a;
var k = (e, t, a) => kt(e, typeof t != "symbol" ? t + "" : t, a), Te = (e, t, a) => t.has(e) || De("Cannot " + a);
var v = (e, t, a) => (Te(e, t, "read from private field"), a ? a.call(e) : t.get(e)), G = (e, t, a) => t.has(e) ? De("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, a), _ = (e, t, a, n) => (Te(e, t, "write to private field"), n ? n.call(e, a) : t.set(e, a), a), Le = (e, t, a) => (Te(e, t, "access private method"), a);
const m = "monster-anatomy", Je = m, Ze = "parts", Q = {
  /** Disparado quando o painel de anatomia termina de renderizar. */
  PANEL_RENDER: "monsterAnatomy.panelRender",
  /** Disparado após criar/atualizar/remover uma parte. */
  PARTS_CHANGED: "monsterAnatomy.partsChanged",
  /** Disparado após aplicar dano a uma parte (sempre, mesmo sem quebra). */
  PART_DAMAGE: "monsterAnatomy.partDamage",
  /** Disparado na transição para quebrado (uma vez por transição). */
  PART_BREAK: "monsterAnatomy.partBreak",
  /** Disparado na transição para cortado (uma vez por transição). */
  PART_SEVER: "monsterAnatomy.partSever"
}, We = { mode: "inherit", value: 0 };
function Xe(e) {
  const t = e.bonus;
  if (!t || typeof t != "object") return { ...We };
  const a = t.mode === "off" || t.mode === "percent" || t.mode === "flat" ? t.mode : "inherit", n = Number.isFinite(Number(t.value)) ? Math.max(0, Number(t.value)) : 0;
  return { mode: a, value: n };
}
function Ae(e) {
  if (!Array.isArray(e.rewards)) return [];
  const t = [];
  for (const a of e.rewards) {
    if (!a || typeof a != "object") continue;
    const n = a, r = typeof n.uuid == "string" && n.uuid.trim() !== "" ? n.uuid.trim() : typeof n.tableUuid == "string" ? n.tableUuid.trim() : "";
    r !== "" && t.push({
      id: typeof n.id == "string" && n.id !== "" ? n.id : foundry.utils.randomID(),
      kind: n.kind === "item" ? "item" : "table",
      uuid: r,
      draws: Math.max(1, Math.min(20, Math.floor(Number(n.draws) || 1))),
      onEvent: n.onEvent === "sever" ? "sever" : "break"
    });
  }
  return t;
}
const Et = ["slashing", "piercing", "bludgeoning"], xt = [
  "slashing",
  "piercing",
  "bludgeoning",
  "fire",
  "cold",
  "lightning",
  "thunder",
  "acid",
  "poison",
  "psychic",
  "necrotic",
  "radiant",
  "force"
];
function Rt(e, t) {
  var n;
  if (!t) return 1;
  const a = (n = e.hitzone) == null ? void 0 : n[t];
  return typeof a == "number" && Number.isFinite(a) && a >= 0 ? a : 1;
}
function _t(e) {
  return e.severable && (e.severTypes ?? []).length > 0;
}
function q(e) {
  return e === "broken" || e === "severed";
}
const b = {
  disableItemId: "",
  disableItemName: "",
  effectName: "",
  effectIcon: "",
  effectDuration: null,
  condition: "",
  setAttrPath: "",
  setAttrValue: "",
  macroUuid: ""
};
function V(e) {
  return { ...b, ...e.onBreak ?? {} };
}
function Yt(e, t, a) {
  return {
    id: foundry.utils.randomID(),
    name: e,
    ...a ? { map: a } : {},
    parts: t.map((n) => {
      var r;
      return {
        name: n.name,
        ac: n.ac,
        hpMax: n.hp.max,
        breakable: n.breakable,
        severable: n.severable,
        hitzone: { ...n.hitzone ?? {} },
        severMax: ((r = n.sever) == null ? void 0 : r.max) ?? n.hp.max,
        severTypes: [...n.severTypes ?? ["slashing"]],
        onBreak: V(n),
        rewards: Ae(n).map((o) => ({ ...o }))
      };
    })
  };
}
function Pt(e, t) {
  return e.parts.map((a) => {
    const n = Math.max(1, Math.floor(a.hpMax)), r = ve(a.name || "Nova parte", {
      ac: Math.max(0, Math.floor(a.ac)),
      hp: n
    });
    r.breakable = a.breakable !== !1, r.severable = a.severable === !0, r.hitzone = { ...a.hitzone ?? {} };
    const o = Math.max(1, Math.floor(a.severMax || n));
    r.sever = { value: o, max: o }, r.severTypes = [...a.severTypes ?? ["slashing"]], r.onBreak = { ...b, ...a.onBreak ?? {} }, r.rewards = (a.rewards ?? []).map((u) => ({ ...u }));
    const i = r.onBreak.disableItemName.trim(), s = i ? [...t.items].find((u) => u.name === i) : void 0, c = !s && r.onBreak.disableItemId.trim() ? t.items.get(r.onBreak.disableItemId.trim()) : void 0, l = s ?? c;
    return r.onBreak.disableItemId = typeof (l == null ? void 0 : l.id) == "string" ? l.id : "", r.onBreak.disableItemName = typeof (l == null ? void 0 : l.name) == "string" ? l.name : i, r;
  });
}
const Ht = [
  {
    id: "builtin-dragonoid",
    name: "MONSTER_ANATOMY.Template.Dragonoid",
    builtin: !0,
    map: "dragonoid",
    parts: [
      { name: "Cabeça", ac: 21, hpMax: 80, breakable: !0, severable: !1, hitzone: { bludgeoning: 1.5, piercing: 0.8 }, severMax: 80, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Corpo", ac: 19, hpMax: 100, breakable: !0, severable: !1, hitzone: {}, severMax: 100, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Asa Esquerda", ac: 20, hpMax: 60, breakable: !0, severable: !1, hitzone: {}, severMax: 60, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Asa Direita", ac: 20, hpMax: 60, breakable: !0, severable: !1, hitzone: {}, severMax: 60, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Cauda", ac: 22, hpMax: 70, breakable: !0, severable: !0, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...b, disableItemName: "Tail Swipe" }, rewards: [] }
    ]
  },
  {
    id: "builtin-humanoid",
    name: "MONSTER_ANATOMY.Template.Humanoid",
    builtin: !0,
    map: "humanoid",
    parts: [
      { name: "Cabeça", ac: 20, hpMax: 50, breakable: !0, severable: !1, hitzone: { bludgeoning: 1.5 }, severMax: 50, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Corpo", ac: 18, hpMax: 80, breakable: !0, severable: !1, hitzone: {}, severMax: 80, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Braço Esquerdo", ac: 18, hpMax: 40, breakable: !0, severable: !1, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Braço Direito", ac: 18, hpMax: 40, breakable: !0, severable: !1, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Perna Esquerda", ac: 18, hpMax: 50, breakable: !0, severable: !1, hitzone: {}, severMax: 50, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Perna Direita", ac: 18, hpMax: 50, breakable: !0, severable: !1, hitzone: {}, severMax: 50, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] }
    ]
  }
], Z = {
  intact: "MONSTER_ANATOMY.State.Intact",
  damaged: "MONSTER_ANATOMY.State.Damaged",
  broken: "MONSTER_ANATOMY.State.Broken",
  severed: "MONSTER_ANATOMY.State.Severed",
  destroyed: "MONSTER_ANATOMY.State.Destroyed"
};
let ze = 0;
function It() {
  ze += 1;
  const e = Math.random().toString(36).slice(2, 8);
  return `part-${Date.now().toString(36)}-${e}-${ze}`;
}
function ve(e, t) {
  const a = Math.max(1, Math.floor(t.hp));
  return {
    id: It(),
    name: e.trim(),
    ac: Math.max(0, Math.floor(t.ac)),
    hp: { value: a, max: a },
    breakable: !0,
    severable: !1,
    state: "intact",
    notes: "",
    onBreak: { ...b },
    hitzone: {},
    sever: { value: a, max: a },
    severTypes: ["slashing"],
    rewards: [],
    bonus: { ...We }
  };
}
function $t(e) {
  return e.hp.value <= 0 && e.breakable ? "broken" : e.hp.value < e.hp.max ? "damaged" : "intact";
}
function Bt(e) {
  var a;
  const t = [];
  return (a = e.name) != null && a.trim() || t.push("name"), (e.ac === void 0 || !Number.isFinite(e.ac) || e.ac < 0) && t.push("ac"), (e.hp === void 0 || !Number.isFinite(e.hp.max) || e.hp.max < 1) && t.push("hp.max"), e.hp !== void 0 && (!Number.isFinite(e.hp.value) || e.hp.value < 0) && t.push("hp.value"), t;
}
function Ee(e) {
  return {
    ...e,
    hp: { ...e.hp },
    onBreak: V(e),
    hitzone: { ...e.hitzone ?? {} },
    sever: e.sever ? { ...e.sever } : { value: e.hp.max, max: e.hp.max },
    severTypes: [...e.severTypes ?? ["slashing"]],
    rewards: Ae(e).map((t) => ({ ...t })),
    bonus: Xe(e)
  };
}
function h(e) {
  var t;
  return ((t = game.i18n) == null ? void 0 : t.localize(e)) ?? e;
}
function S(e, t) {
  var a;
  return ((a = game.i18n) == null ? void 0 : a.format(e, t)) ?? e;
}
function M(e) {
  return game.settings.get(m, e);
}
function ne(e) {
  if (!e || typeof e != "object") return;
  const t = e;
  if (typeof t.uuid == "string" && t.uuid) return t.uuid;
  if (t.document && typeof t.document == "object") {
    const a = t.document.uuid;
    if (typeof a == "string" && a) return a;
  }
}
function Qe() {
  var e, t;
  return (t = (e = game.modules) == null ? void 0 : e.get(m)) == null ? void 0 : t.api;
}
function ee(e, ...t) {
  Hooks.callAll.call(Hooks, e, ...t);
}
function ce(e, t) {
  return Hooks.on.call(Hooks, e, t);
}
function Ct(e, t) {
  Hooks.off.call(Hooks, e, t);
}
const xe = "attrBackup";
function Ft(e) {
  const t = /* @__PURE__ */ new Set();
  for (const a of et(e)) {
    if (!q(a.state)) continue;
    const n = V(a).disableItemId.trim();
    n && t.add(n);
  }
  return t;
}
function Dt(e, t) {
  return et(e).find(
    (a) => q(a.state) && V(a).disableItemId.trim() === t
  );
}
function et(e) {
  const t = e.getFlag(m, "parts");
  return Array.isArray(t) ? t : [];
}
async function Lt(e, t) {
  const a = V(t);
  a.effectName.trim() && await zt(e, t, a.effectName.trim(), a), a.condition.trim() && await Ut(e, t, a.condition.trim()), a.setAttrPath.trim() && await qt(e, t, a), a.macroUuid.trim() && await Gt(a.macroUuid.trim());
}
async function Ue(e, t) {
  for (const a of [...e.effects])
    try {
      if (a.getFlag(m, "partId") !== t.id) continue;
      const n = a.getFlag(m, "kind");
      (n === "break-effect" || n === "break-condition" || n === "part-broken" || n === "part-severed") && await a.delete();
    } catch (n) {
      console.warn("monster-anatomy | falha ao remover efeito da parte", n);
    }
  await Vt(e, t.id);
}
async function zt(e, t, a, n) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(m, "partId") === t.id && i.getFlag(m, "kind") === "break-effect";
    } catch {
      return !1;
    }
  })) return;
  const o = {};
  o[m] = { partId: t.id, kind: "break-effect" }, await ActiveEffect.create(
    {
      name: a,
      img: n.effectIcon.trim() || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      duration: typeof n.effectDuration == "number" ? { rounds: n.effectDuration } : void 0,
      flags: o
    },
    { parent: e }
  );
}
async function Ut(e, t, a) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(m, "partId") === t.id && i.getFlag(m, "kind") === "break-condition";
    } catch {
      return !1;
    }
  })) return;
  const r = CONFIG.statusEffects.find(
    (i) => (i == null ? void 0 : i.id) === a
  ), o = {};
  o[m] = { partId: t.id, kind: "break-condition" }, await ActiveEffect.create(
    {
      name: S("MONSTER_ANATOMY.Effect.ConditionName", {
        status: (r == null ? void 0 : r.name) ?? a,
        part: t.name
      }),
      img: (r == null ? void 0 : r.img) || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      statuses: [a],
      flags: o
    },
    { parent: e }
  );
}
async function qt(e, t, a) {
  const n = a.setAttrPath.trim(), r = tt(e);
  t.id in r || (r[t.id] = { [n]: foundry.utils.getProperty(e, n) }, await e.setFlag(m, xe, r)), await e.update({
    [n]: Kt(a.setAttrValue)
  });
}
async function Vt(e, t) {
  const a = tt(e), n = a[t];
  if (!n) return;
  const r = {};
  for (const [o, i] of Object.entries(n)) r[o] = i;
  delete a[t];
  try {
    await e.update(r);
  } catch (o) {
    console.warn("monster-anatomy | falha ao restaurar atributo", o);
  }
  await e.setFlag(m, xe, a);
}
function tt(e) {
  try {
    const t = e.getFlag(m, xe);
    if (t && typeof t == "object" && !Array.isArray(t))
      return JSON.parse(JSON.stringify(t));
  } catch {
  }
  return {};
}
async function Gt(e) {
  try {
    const a = await fromUuid(e);
    typeof (a == null ? void 0 : a.execute) == "function" ? await a.execute() : console.warn(`monster-anatomy | macro não encontrada (${e})`);
  } catch (t) {
    console.warn(`monster-anatomy | falha ao executar macro (${e})`, t);
  }
}
function Kt(e) {
  const t = e.trim();
  return t === "true" ? !0 : t === "false" ? !1 : t !== "" && Number.isFinite(Number(t)) ? Number(t) : e;
}
function T(e) {
  const t = e.getFlag(Je, Ze);
  return Array.isArray(t) ? t.map((a) => ({ ...a, hp: { ...a.hp } })) : [];
}
async function ye(e, t) {
  var n;
  if (!e.isOwner)
    throw (n = ui.notifications) == null || n.warn(h("MONSTER_ANATOMY.Errors.NoPermission")), new Error("monster-anatomy: actor não editável pelo usuário atual");
  const a = T(e);
  await e.setFlag(Je, Ze, t.map(Ee)), await jt(e, a, t), ee(Q.PARTS_CHANGED, e, T(e));
}
async function jt(e, t, a) {
  var o;
  const n = new Map(t.map((i) => [i.id, i])), r = new Set(a.map((i) => i.id));
  for (const i of a) {
    const s = q(((o = n.get(i.id)) == null ? void 0 : o.state) ?? "intact"), c = q(i.state);
    if (c !== s)
      try {
        c ? await Lt(e, i) : await Ue(e, i);
      } catch (l) {
        console.warn("monster-anatomy | falha na vinculação de ruptura", l);
      }
  }
  for (const i of t)
    if (!(r.has(i.id) || !q(i.state)))
      try {
        await Ue(e, i);
      } catch (s) {
        console.warn("monster-anatomy | falha na limpeza de ruptura", s);
      }
}
async function Jt(e, t) {
  const a = T(e);
  if (a.some((n) => n.id === t.id))
    throw new Error(`monster-anatomy: id de parte duplicado (${t.id})`);
  a.push(Ee(t)), await ye(e, a);
}
async function ue(e, t, a) {
  const n = T(e), r = n.findIndex((i) => i.id === t);
  if (r < 0) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = n[r];
  n[r] = {
    ...o,
    ...a,
    id: o.id,
    // id é imutável (§5.1 do design)
    hp: { ...o.hp, ...a.hp ?? {} }
  }, await ye(e, n);
}
async function Zt(e, t) {
  const a = T(e).filter((n) => n.id !== t);
  await ye(e, a);
}
function E(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function j() {
  var e;
  return ((e = game.user) == null ? void 0 : e.isGM) === !0;
}
function Wt(e) {
  const t = e.name.startsWith("MONSTER_ANATOMY.") ? h(e.name) : e.name;
  return e.builtin ? `${t} ${h("MONSTER_ANATOMY.Template.BuiltinTag")}` : t;
}
function Re() {
  return [...Ht, ...le()];
}
function le() {
  try {
    const e = M("templatesJson");
    if (typeof e != "string" || e.trim() === "") return [];
    const t = JSON.parse(e);
    return Array.isArray(t) ? t.filter(
      (a) => !!a && typeof a == "object" && typeof a.id == "string"
    ) : [];
  } catch {
    return [];
  }
}
async function at(e) {
  await game.settings.set(m, "templatesJson", JSON.stringify(e));
}
async function Xt(e, t, a) {
  const n = Yt(e, t, a);
  return await at([...le(), n]), n;
}
async function Qt(e) {
  if (e.startsWith("builtin-")) return !1;
  const t = le().filter((a) => a.id !== e);
  return t.length === le().length ? !1 : (await at(t), !0);
}
async function nt(e, t) {
  const a = Re().find((r) => r.id === t);
  if (!a) throw new Error(`monster-anatomy: modelo não encontrado (${t})`);
  const n = Pt(a, e);
  return await ye(e, [...T(e), ...n]), a.map && await e.setFlag(m, "mapLayout", a.map), n.length;
}
function be(e) {
  try {
    return e.getFlag(m, "mapLayout") === "humanoid" ? "humanoid" : "dragonoid";
  } catch {
    return "dragonoid";
  }
}
async function ea(e, t) {
  await e.setFlag(m, "mapLayout", t === "humanoid" ? "humanoid" : "dragonoid");
}
function re(e) {
  try {
    return e.getFlag(m, "hideAc") === !0;
  } catch {
    return !1;
  }
}
async function ta(e, t) {
  await e.setFlag(m, "hideAc", t);
}
function _e() {
  var e;
  try {
    if (M("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function aa(e) {
  if (_e()) return;
  const t = e.textContent ?? "";
  if (t.length === 0 || t.length > 24) return;
  e.textContent = "";
  let a = 0;
  for (const n of Array.from(t)) {
    if (n === " ") {
      e.appendChild(document.createTextNode(" "));
      continue;
    }
    const r = document.createElement("span");
    r.className = "ma-letter", r.textContent = n, r.style.setProperty("--i", String(a)), e.appendChild(r), a++;
  }
}
function rt(e) {
  try {
    if (M("particles") !== !0 || _e() || document.hidden) return;
  } catch {
    return;
  }
  const t = document.createElement("canvas");
  t.className = "monster-anatomy-particles";
  const a = Math.min(2, window.devicePixelRatio || 1);
  t.width = Math.floor(window.innerWidth * a), t.height = Math.floor(window.innerHeight * a), document.body.appendChild(t);
  const n = t.getContext("2d");
  if (!n) {
    t.remove();
    return;
  }
  n.scale(a, a);
  const r = window.innerWidth / 2, o = window.innerHeight / 2 - window.innerHeight * 0.06, i = e ? ["#9adcff", "#e8f7ff", "#4da6d8", "#0e4d64", "#ffffff"] : ["#ff3b3b", "#ffb454", "#fff3d6", "#7a1a00", "#1a1a1a"], s = [], c = 90;
  for (let g = 0; g < c; g++) {
    const p = Math.random() * Math.PI * 2, A = 180 + Math.random() * 560, f = 0.7 + Math.random() * 0.6;
    s.push({
      x: r + (Math.random() - 0.5) * 60,
      y: o + (Math.random() - 0.5) * 30,
      vx: Math.cos(p) * A,
      vy: Math.sin(p) * A - 160,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 14,
      size: 3 + Math.random() * 8,
      life: f,
      maxLife: f,
      color: i[Math.floor(Math.random() * i.length)],
      circle: Math.random() < 0.3
    });
  }
  const l = 900;
  let u = performance.now();
  const d = (g) => {
    const p = Math.min(0.05, (g - u) / 1e3);
    u = g, n.clearRect(0, 0, window.innerWidth, window.innerHeight);
    let A = !1;
    for (const f of s)
      f.life -= p, !(f.life <= 0) && (A = !0, f.vy += l * p, f.x += f.vx * p, f.y += f.vy * p, f.rot += f.vr * p, n.save(), n.globalAlpha = Math.max(0, f.life / f.maxLife), n.translate(f.x, f.y), n.rotate(f.rot), n.fillStyle = f.color, f.circle ? (n.beginPath(), n.arc(0, 0, f.size / 2, 0, Math.PI * 2), n.fill()) : n.fillRect(-f.size / 2, -f.size / 4, f.size, f.size / 2), n.restore());
    A ? requestAnimationFrame(d) : t.remove();
  };
  requestAnimationFrame(d);
}
function ot() {
  try {
    if (M("screenShake") !== !0 || _e()) return;
  } catch {
    return;
  }
  const e = document.getElementById("board");
  if (!e) return;
  const t = 11, a = 380, n = performance.now(), r = (o) => {
    const i = o - n;
    if (i >= a) {
      e.style.transform = "";
      return;
    }
    const s = 1 - i / a, c = Math.sin(o / 17) * t * s, l = Math.cos(o / 23) * t * 0.7 * s;
    e.style.transform = `translate(${c.toFixed(1)}px, ${l.toFixed(1)}px)`, requestAnimationFrame(r);
  };
  requestAnimationFrame(r);
}
async function na(e, t, a) {
  M("showAnnouncement") && st(e, t), M("chatMessage") && await ca(e, t, a), M("tokenEffect") && await la(e, t), await it();
}
async function ra(e, t, a) {
  M("showAnnouncement") && ct(e, t), M("chatMessage") && await ua(e, t, a), M("tokenEffect") && await ma(e, t), await it();
}
async function it() {
  const e = String(M("breakSound") ?? "").trim();
  if (e)
    try {
      await foundry.audio.AudioHelper.play({ src: e, volume: 0.8 });
    } catch (t) {
      console.warn(`monster-anatomy | falha ao tocar som (${e})`, t);
    }
}
function x(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function st(e, t) {
  const a = Math.max(0.5, Math.min(10, Number(M("announceDuration") ?? 2.5)));
  ut(e, t, a, !1), lt(!1), mt(e), rt(!1), ot();
}
function ct(e, t) {
  const a = Math.max(0.5, Math.min(10, Number(M("announceDuration") ?? 2.5)));
  ut(e, t, a, !0), lt(!0), mt(e), rt(!0), ot();
}
function Ye() {
  var e;
  try {
    if (M("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function oa() {
  const e = String(M("announceTheme") ?? "persona");
  return e === "monsterhunter" || e === "jrpg" || e === "minimal" || e === "impact" || e === "arcade" || e === "carved" ? e : "persona";
}
function ia(e) {
  const t = String(
    M(e ? "customKickerSever" : "customKickerBreak") ?? ""
  ).trim();
  return t !== "" ? t : h(e ? "MONSTER_ANATOMY.Announce.Severed" : "MONSTER_ANATOMY.Announce.Break");
}
function ut(e, t, a, n) {
  document.querySelectorAll(".monster-anatomy-announce").forEach((s) => s.remove());
  const r = document.createElement("div");
  r.className = `monster-anatomy-announce theme-${oa()}` + (n ? " is-sever" : ""), r.style.setProperty("--ma-duration", `${a}s`), Ye() && r.classList.add("is-reduced");
  const o = ia(n);
  r.innerHTML = `<div class="ma-announce-kicker">${x(o)}</div><div class="ma-announce-part">${x(t.name)}</div><div class="ma-announce-actor">${x(e.name)}</div>`, document.body.appendChild(r);
  const i = r.querySelector(".ma-announce-kicker");
  i && aa(i), requestAnimationFrame(() => r.classList.add("is-showing")), window.setTimeout(() => {
    r.classList.remove("is-showing"), window.setTimeout(() => r.remove(), 450);
  }, Math.max(400, Math.round(a * 1e3)));
}
function lt(e) {
  try {
    if (M("screenFlash") !== !0 || Ye()) return;
  } catch {
    return;
  }
  const t = document.createElement("div");
  t.className = "monster-anatomy-flash" + (e ? " is-sever" : ""), document.body.appendChild(t), requestAnimationFrame(() => t.classList.add("is-showing")), window.setTimeout(() => t.classList.remove("is-showing"), 120), window.setTimeout(() => t.remove(), 450);
}
function mt(e) {
  try {
    if (M("tokenShake") !== !0 || Ye()) return;
  } catch {
    return;
  }
  try {
    const t = e.getActiveTokens();
    for (const a of t) {
      const n = a == null ? void 0 : a.mesh;
      sa(n);
    }
  } catch {
  }
}
function sa(e) {
  const t = e == null ? void 0 : e.position;
  if (!t || typeof t.x != "number" || typeof t.y != "number") return;
  const a = t.x, n = t.y, r = 9, o = 420, i = performance.now(), s = typeof t.set == "function" ? t.set.bind(t) : null, c = (u, d) => {
    s ? s(u, d) : (t.x = u, t.y = d);
  }, l = (u) => {
    const d = u - i;
    if (d >= o) {
      c(a, n);
      return;
    }
    const g = 1 - d / o;
    c(a + Math.sin(u / 16) * r * g, n), requestAnimationFrame(l);
  };
  requestAnimationFrame(l);
}
async function ca(e, t, a) {
  const n = a.attacker ? `<p class="ma-chat-attacker">${x(
    S("MONSTER_ANATOMY.Chat.BreakBy", {
      attacker: a.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", r = `<div class="monster-anatomy-chat ma-break"><h3>💥 ${x(h("MONSTER_ANATOMY.Announce.Break"))}</h3><p>${x(
    S("MONSTER_ANATOMY.Chat.BreakText", {
      part: t.name,
      actor: e.name,
      amount: String(a.amount)
    })
  )}</p>${n}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: r
  });
}
async function dt(e, t, a, n, r = 0, o = 0) {
  let i = !1;
  try {
    i = M("attackNotes") === !0;
  } catch {
    return;
  }
  if (!i) return;
  const s = [];
  r > 0 && s.push(`+${r}%`), o > 0 && s.push(`+${o}`);
  const c = s.length > 0 ? ` ${S("MONSTER_ANATOMY.Routed.Bonus", { mark: s.join(" ") })}` : "";
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-routed"><p>${x(
      S("MONSTER_ANATOMY.Routed.Text", {
        amount: String(a),
        part: t,
        actor: e.name,
        global: String(n)
      })
    )}${x(c)}</p></div>`
  });
}
async function ua(e, t, a) {
  const n = a.attacker ? `<p class="ma-chat-attacker">${x(
    S("MONSTER_ANATOMY.Chat.SeverBy", {
      attacker: a.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", r = `<div class="monster-anatomy-chat ma-break ma-sever"><h3>🗡️ ${x(h("MONSTER_ANATOMY.Announce.Severed"))}</h3><p>${x(
    S("MONSTER_ANATOMY.Chat.SeverText", {
      part: t.name,
      actor: e.name,
      amount: String(a.amount)
    })
  )}</p>${n}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: r
  });
}
async function la(e, t) {
  if (e.effects.some((r) => {
    try {
      return r.getFlag(m, "partId") === t.id;
    } catch {
      return !1;
    }
  })) return;
  const n = {};
  n[m] = { partId: t.id, kind: "part-broken" }, await ActiveEffect.create(
    {
      name: S("MONSTER_ANATOMY.Effect.BrokenName", { part: t.name }),
      img: "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      flags: n
    },
    { parent: e }
  );
}
async function ma(e, t) {
  if (e.effects.some((r) => {
    try {
      return r.getFlag(m, "partId") === t.id && r.getFlag(m, "kind") === "part-severed";
    } catch {
      return !1;
    }
  })) return;
  const n = {};
  n[m] = { partId: t.id, kind: "part-severed" }, await ActiveEffect.create(
    {
      name: S("MONSTER_ANATOMY.Effect.SeveredName", { part: t.name }),
      img: "systems/dnd5e/icons/svg/damage/slashing.svg",
      origin: e.uuid,
      disabled: !1,
      flags: n
    },
    { parent: e }
  );
}
const Pe = "loot", da = 20;
async function qe(e, t, a, n = {}) {
  const r = Ae(t).filter((c) => c.onEvent === a);
  if (r.length === 0) return;
  const o = await fa(e, n.attackerUuid), i = [];
  let s;
  for (const c of r) {
    if (c.kind === "item") {
      const u = await pa(e, o, c.uuid, c.draws);
      u && (i.push(c.draws > 1 ? `${u} ×${c.draws}` : u), o && (s = o.name));
      continue;
    }
    const l = await Aa(c.uuid);
    if (!l) {
      console.warn(`monster-anatomy | tabela não encontrada (${c.uuid})`);
      continue;
    }
    for (let u = 0; u < Math.min(Math.floor(c.draws), da); u++)
      try {
        const d = await l.draw({ displayChat: !1 });
        for (const g of d.results ?? []) {
          const p = ya(g);
          p && i.push(p);
        }
      } catch (d) {
        console.warn("monster-anatomy | falha no sorteio", d);
        break;
      }
  }
  i.length !== 0 && (await ga(e, {
    partId: t.id,
    partName: t.name,
    event: a,
    items: i,
    ...s ? { grantedTo: s } : {},
    at: Date.now()
  }), M("chatMessage") && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-loot"><h3>🎁 ${Ve(h("MONSTER_ANATOMY.Loot.Title"))}</h3><p>${Ve(
      S("MONSTER_ANATOMY.Loot.Text", {
        part: t.name,
        actor: e.name,
        items: i.join(", ")
      })
    )}</p></div>`
  }));
}
async function fa(e, t) {
  const a = t && t !== e.uuid ? t : void 0;
  if (a) {
    const r = await He(a);
    if (r instanceof Actor && r.uuid !== e.uuid) return r;
  }
  const n = game.user;
  if (n && !n.isGM) {
    const r = n.character;
    if (r instanceof Actor && r.uuid !== e.uuid) return r;
  }
  return null;
}
async function pa(e, t, a, n) {
  var i, s, c;
  const r = await He(a);
  if (!(r instanceof Item))
    return console.warn(`monster-anatomy | item não encontrado (${a})`), null;
  const o = typeof r.name == "string" ? r.name : a;
  if (!t)
    return console.warn("monster-anatomy | sem atacante para entregar o item; registrado no pool"), o;
  try {
    const l = r.toObject() ?? {};
    delete l._id;
    const d = await t.createEmbeddedDocuments.call(t, "Item", [l]);
    if (n > 1 && ((i = d[0]) != null && i.update))
      try {
        await ((c = (s = d[0]).update) == null ? void 0 : c.call(s, { "system.quantity": n }));
      } catch {
      }
    return o;
  } catch (l) {
    return console.warn("monster-anatomy | falha ao criar item no recebedor", l), o;
  }
}
function ft(e) {
  try {
    const t = e.getFlag(m, Pe);
    return Array.isArray(t) ? t.filter((a) => a && Array.isArray(a.items)) : [];
  } catch {
    return [];
  }
}
async function ha(e) {
  await e.setFlag(m, Pe, []);
}
async function ga(e, t) {
  const a = [...ft(e), t].slice(-200);
  await e.setFlag(m, Pe, a);
}
async function Aa(e) {
  const t = await He(e);
  return t instanceof RollTable ? t : null;
}
async function He(e) {
  try {
    return await fromUuid(e);
  } catch {
    return null;
  }
}
function ya(e) {
  const t = e;
  return typeof (t == null ? void 0 : t.name) == "string" && t.name ? t.name : typeof (t == null ? void 0 : t.text) == "string" && t.text ? t.text : typeof (t == null ? void 0 : t.id) == "string" && t.id ? t.id : "";
}
function Ve(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
const Ne = "system.attributes.hp.value";
async function pt(e, t, a, n = {}) {
  return Me(e, t, [{ amount: a, type: n.type }], n);
}
async function Me(e, t, a, n = {}) {
  const r = T(e).find((y) => y.id === t);
  if (!r) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  let o = 0, i = 0;
  const s = _t(r);
  for (const y of a) {
    const $ = Math.max(0, Math.floor(Number(y == null ? void 0 : y.amount) || 0));
    $ <= 0 || (o += $ * Rt(r, y == null ? void 0 : y.type), s && typeof (y == null ? void 0 : y.type) == "string" && (r.severTypes ?? []).includes(y.type) && (i += $));
  }
  o = Math.floor(o);
  const c = r.state, l = Xe(r);
  let u = 0, d = 0;
  if (q(c) && (l.mode === "percent" ? u = Math.max(0, Math.min(200, l.value)) : l.mode === "flat" ? d = Math.max(0, Math.floor(l.value)) : l.mode !== "off" && (u = Math.max(0, Math.min(200, Number(M("brokenBonus") ?? 0))))), u > 0 || d > 0) {
    const y = 1 + u / 100;
    o = Math.floor(o * y) + d, i = Math.floor(i * y) + d;
  }
  const g = Math.max(0, r.hp.value - o);
  let p = c;
  g <= 0 && r.breakable ? p = "broken" : g < r.hp.max && c === "intact" && (p = "damaged"), await ue(e, t, { hp: { ...r.hp, value: g }, state: p });
  let A = T(e).find((y) => y.id === t);
  const f = await Ma(e, o);
  ee(Q.PART_DAMAGE, e, A, o, n.attacker ?? null);
  const B = p === "broken" && c !== "broken";
  B && (await na(e, A, { amount: o, attacker: n.attacker }), await qe(e, A, "break", { attackerUuid: n.attackerUuid }), ee(Q.PART_BREAK, e, A, o, n.attacker ?? null));
  let I = !1;
  const z = A.sever ?? { value: A.hp.max, max: A.hp.max };
  if (s && i > 0 && A.state !== "severed") {
    const y = Math.max(0, z.value - i);
    await ue(e, t, {
      sever: { value: y, max: z.max },
      ...y <= 0 ? { state: "severed" } : {}
    }), A = T(e).find(($) => $.id === t), y <= 0 && (I = !0, await ra(e, A, { amount: i, attacker: n.attacker }), await qe(e, A, "sever", { attackerUuid: n.attackerUuid }), ee(Q.PART_SEVER, e, A, i, n.attacker ?? null));
  }
  return { part: A, broke: B, severed: I, globalApplied: f, applied: o, bonus: u, bonusFlat: d };
}
async function ht(e, t, a) {
  const n = Math.max(0, Math.floor(Number(a) || 0)), r = T(e).find((l) => l.id === t);
  if (!r) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = Math.min(r.hp.max, r.hp.value + n), i = o >= r.hp.max, s = i && (r.state === "damaged" || r.state === "broken") ? "intact" : r.state, c = r.sever ?? { value: r.hp.max, max: r.hp.max };
  return await ue(e, t, {
    hp: { ...r.hp, value: o },
    state: s,
    ...i ? { sever: { value: c.max, max: c.max } } : {}
  }), T(e).find((l) => l.id === t);
}
async function Ma(e, t) {
  if (t <= 0) return 0;
  const a = M("damageModel");
  if (a === "independent") return 0;
  const n = a === "percent" ? Math.max(0, Math.min(100, Number(M("damagePercent") ?? 50))) : 100, r = Math.floor(t * n / 100);
  if (r <= 0) return 0;
  const o = foundry.utils.getProperty(e, Ne);
  if (typeof o != "number")
    return console.warn(`monster-anatomy | HP global não encontrado em ${Ne}`), 0;
  const i = Math.max(0, o - r);
  return await e.update({
    [Ne]: i
  }), r;
}
const { ApplicationV2: Ta, HandlebarsApplicationMixin: Na } = foundry.applications.api;
function wa(e) {
  return e.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
}
function K(e, t) {
  return t.some((a) => e.includes(a));
}
function Ge(e) {
  const t = { head: [], torso: [], left: [], right: [], tail: [] }, a = [];
  for (const n of e) {
    const r = wa(n.name), o = /* @__PURE__ */ new Set();
    K(r, ["cauda", "tail", "rabo"]) && o.add("tail"), K(r, [
      "cabeca",
      "head",
      "cranio",
      "skull",
      "olho",
      "eye",
      "focinho",
      "boca",
      "mouth",
      "maw",
      "pescoco",
      "neck",
      "dente",
      "tooth",
      "fang",
      "presa"
    ]) && o.add("head");
    const i = K(r, ["esquerda", "left", "esq"]), s = K(r, ["direita", "right", "dir"]);
    if (i && o.add("left"), s && o.add("right"), K(r, ["corpo", "torso", "body", "peito", "chest", "barriga", "belly", "tronco", "trunk", "costa", "back", "nucleo", "core"]) && o.add("torso"), K(r, ["asa", "wing", "garra", "claw", "pata", "paw", "perna", "leg", "braco", "arm", "chifre", "horn"]) && !i && !s && (o.add("left"), o.add("right")), o.size === 0) a.push(n);
    else for (const c of o) t[c].push(n);
  }
  return { zones: t, unmapped: a };
}
function W(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function Sa(e) {
  let t = 0;
  for (const a of e) {
    if (a.state === "broken" || a.state === "severed" || a.state === "destroyed") return 2;
    a.state === "damaged" && (t = 1);
  }
  return t;
}
function X(e) {
  const t = Sa(e);
  return t === 2 ? "is-broken" : t === 1 ? "is-damaged" : "";
}
var P;
const te = class te extends Na(Ta) {
  constructor(a, n) {
    super(a);
    G(this, P, null);
    _(this, P, n);
  }
  /** Abre o mapa e resolve com o id da parte (null = normal/dispensado). */
  static pick(a) {
    return new Promise((n) => {
      new te({ actor: a }, n).render(!0);
    });
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(a) {
    const n = await super._prepareContext(a), r = this.actor, o = T(r), { zones: i, unmapped: s } = Ge(o), c = {
      head: h("MONSTER_ANATOMY.Target.ZoneHead"),
      torso: h("MONSTER_ANATOMY.Target.ZoneTorso"),
      left: h("MONSTER_ANATOMY.Target.ZoneLeft"),
      right: h("MONSTER_ANATOMY.Target.ZoneRight"),
      tail: h("MONSTER_ANATOMY.Target.ZoneTail")
    }, l = {
      head: i.head.length === 0,
      torso: i.torso.length === 0,
      left: i.left.length === 0,
      right: i.right.length === 0,
      tail: i.tail.length === 0
    }, u = {
      head: X(i.head),
      torso: X(i.torso),
      left: X(i.left),
      right: X(i.right),
      tail: X(i.tail)
    }, d = re(r) && !j(), g = (p) => d ? "??" : String(p);
    return {
      ...n,
      actorName: r.name,
      layout: be(r),
      zoneLabelMap: c,
      zoneEmpty: l,
      zoneClassMap: u,
      others: s.map((p) => ({
        id: p.id,
        display: `${p.name} — CA ${g(p.ac)} — ${p.hp.value}/${p.hp.max} • ${h(Z[p.state])}`
      }))
    };
  }
  async _onRender(a, n) {
    var d;
    await super._onRender(a, n);
    const r = this.actor, o = re(r) && !j(), i = (g) => o ? "??" : String(g), { zones: s } = Ge(T(r)), c = this.element.querySelector("[data-zoneparts]"), l = this.element.querySelector("[data-zonehint]"), u = (g) => {
      if (!v(this, P)) return;
      const p = v(this, P);
      _(this, P, null), p(g), this.close();
    };
    this.element.querySelectorAll("[data-zone]").forEach((g) => {
      g.addEventListener("click", () => {
        const p = g.dataset.zone;
        this.element.querySelectorAll("[data-zone]").forEach((f) => f.classList.toggle("is-active", f === g));
        const A = s[p] ?? [];
        c && (A.length === 0 ? c.innerHTML = `<p class="ma-empty">${W(h("MONSTER_ANATOMY.Target.ZoneEmpty"))}</p>` : c.innerHTML = A.map(
          (f) => `<button type="button" data-part-id="${W(f.id)}">${W(f.name)} — CA ${W(i(f.ac))} — ${f.hp.value}/${f.hp.max} • ${W(h(Z[f.state]))}</button>`
        ).join(""), l && (l.textContent = h("MONSTER_ANATOMY.Target.ZoneHint")));
      });
    }), c == null || c.addEventListener("click", (g) => {
      const p = g.target.closest("[data-part-id]"), A = p == null ? void 0 : p.dataset.partId;
      A && u(A);
    }), this.element.querySelectorAll("[data-pick-part]").forEach((g) => {
      g.addEventListener("click", () => {
        const p = g.dataset.pickPart;
        p && u(p);
      });
    }), (d = this.element.querySelector("[data-normal]")) == null || d.addEventListener("click", () => u(null));
  }
  async close(a) {
    if (v(this, P)) {
      const n = v(this, P);
      _(this, P, null), n(null);
    }
    return super.close(a);
  }
};
P = new WeakMap(), k(te, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-target-map",
  classes: ["monster-anatomy", "monster-anatomy-target"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Target.Title",
    icon: "fa-solid fa-crosshairs",
    resizable: !1
  },
  position: { width: 300, height: "auto" },
  actions: {}
}), k(te, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/target-map.hbs" }
});
let Oe = te, oe = null;
function gt() {
  return oe;
}
function H() {
  oe = null;
}
async function At(e) {
  var u;
  const t = ne(e), a = /* @__PURE__ */ new Set();
  t && a.add(t);
  let n;
  for (const d of ((u = game.user) == null ? void 0 : u.targets) ?? []) {
    const g = ne(d);
    g && (a.add(g), (g === t || !t && a.size === 1) && (n = d));
  }
  if (a.size !== 1) {
    H();
    return;
  }
  const r = [...a][0], o = t === r ? e : n, i = o == null ? void 0 : o.actor;
  if (!(i instanceof Actor)) {
    H();
    return;
  }
  if (T(i).length === 0) {
    H();
    return;
  }
  const c = await Oe.pick(i);
  if (!c) {
    H();
    return;
  }
  const l = T(i).find((d) => d.id === c);
  if (!l) {
    H();
    return;
  }
  oe = {
    tokenUuid: r,
    actorUuid: i.uuid,
    partId: l.id
  };
}
function va() {
  Hooks.on("targetToken", (e, t, a) => {
    var n;
    if (e.id === ((n = game.user) == null ? void 0 : n.id)) {
      if (!a) {
        oe && ne(t) === oe.tokenUuid && H();
        return;
      }
      if (!M("promptOnTarget")) {
        H();
        return;
      }
      At(t);
    }
  });
}
const { ApplicationV2: ba, HandlebarsApplicationMixin: Oa } = foundry.applications.api;
var ge, yt;
const U = class U extends Oa(ba) {
  constructor() {
    super(...arguments);
    G(this, ge);
  }
  static async openFor(a, n, r) {
    await new U({ actor: a, partId: n, onSaved: r }).render(!0);
  }
  get editorOptions() {
    return this.options;
  }
  get editing() {
    const { actor: a, partId: n } = this.editorOptions;
    if (n) {
      const i = T(a).find((s) => s.id === n);
      if (i) return Ee(i);
    }
    const r = Number(M("defaultAc") ?? 10), o = Number(M("defaultHp") ?? 20);
    return ve("", {
      ac: Number.isFinite(r) ? r : 10,
      hp: Number.isFinite(o) ? o : 20
    });
  }
  get isNew() {
    return !this.editorOptions.partId;
  }
  async _prepareContext(a) {
    const n = await super._prepareContext(a), r = this.editing, o = this.editorOptions.actor;
    return {
      ...n,
      part: r,
      isNew: this.isNew,
      actorName: o.name,
      link: V(r),
      sever: r.sever ?? { value: r.hp.max, max: r.hp.max },
      severTypes: r.severTypes ?? ["slashing"],
      rewards: Ae(r).map((i) => ({ ...i })),
      items: [...o.items].flatMap(
        (i) => typeof i.id == "string" ? [{ id: i.id, label: `${i.name} (${i.type})` }] : []
      ),
      damageTypes: we(),
      physicalTypes: Et.map((i) => ({
        key: i,
        label: Mt(i),
        checked: (r.severTypes ?? ["slashing"]).includes(i)
      })),
      hitzones: we().map((i) => {
        var s;
        return {
          key: i.key,
          label: i.label,
          value: ((s = r.hitzone) == null ? void 0 : s[i.key]) ?? 1
        };
      }),
      statuses: (CONFIG.statusEffects ?? []).filter((i) => typeof (i == null ? void 0 : i.id) == "string").map((i) => ({ value: i.id, label: i.name ?? i.id })),
      states: Object.entries(Z).map(
        ([i, s]) => ({ value: i, label: h(s) })
      )
    };
  }
  async _onRender(a, n) {
    var r;
    await super._onRender(a, n), (r = this.element.querySelector("form.monster-anatomy-form")) == null || r.addEventListener("submit", (o) => void Le(this, ge, yt).call(this, o));
  }
  static onAddReward(a, n) {
    const o = this.element.querySelector("[data-rewards]");
    if (!o) return;
    const i = document.createElement("div");
    i.className = "ma-reward", i.setAttribute("data-reward", ""), i.setAttribute("data-reward-id", foundry.utils.randomID()), i.innerHTML = `<select name="rw_event" title="${h("MONSTER_ANATOMY.Editor.RewardEvent")}"><option value="break">${h("MONSTER_ANATOMY.Reward.Break")}</option><option value="sever">${h("MONSTER_ANATOMY.Reward.Sever")}</option></select><select name="rw_kind" title="${h("MONSTER_ANATOMY.Editor.RewardKind")}"><option value="table">${h("MONSTER_ANATOMY.Reward.TableKind")}</option><option value="item">${h("MONSTER_ANATOMY.Reward.ItemKind")}</option></select><input name="rw_table" type="text" placeholder="RollTable.xxx / Item.xxx" title="${h("MONSTER_ANATOMY.Editor.RewardTable")}" /><input name="rw_draws" type="number" min="1" max="20" step="1" value="1" title="${h("MONSTER_ANATOMY.Editor.RewardDraws")}" /><button type="button" data-action="remove-reward" title="${h("MONSTER_ANATOMY.Editor.RewardRemove")}"><i class="fa-solid fa-xmark"></i></button>`, o.appendChild(i);
  }
  static onRemoveReward(a, n) {
    var r;
    (r = n.closest("[data-reward]")) == null || r.remove();
  }
};
ge = new WeakSet(), yt = async function(a) {
  var se, Ie, $e, Be;
  a.preventDefault();
  const n = a.target, r = new FormData(n), o = (N) => String(r.get(N) ?? "").trim(), i = (N, O) => {
    const R = Number(r.get(N));
    return Number.isFinite(R) ? R : O;
  }, { actor: s, partId: c, onSaved: l } = this.editorOptions, u = c ? T(s).find((N) => N.id === c) : void 0, d = Math.max(1, Math.floor(i("hpMax", (u == null ? void 0 : u.hp.max) ?? 10))), g = o("effectDuration"), p = o("disableItemId"), A = {
    disableItemId: p,
    disableItemName: ((se = s.items.get(p)) == null ? void 0 : se.name) ?? "",
    effectName: o("effectName"),
    effectIcon: o("effectIcon"),
    effectDuration: g === "" ? null : Math.max(0, Math.floor(i("effectDuration", 0))),
    condition: o("condition"),
    setAttrPath: o("setAttrPath"),
    setAttrValue: o("setAttrValue"),
    macroUuid: o("macroUuid")
  }, f = {};
  for (const { key: N } of we()) {
    const O = r.get(`hz_${N}`);
    if (O == null) continue;
    const R = Number(O);
    !Number.isFinite(R) || R < 0 || R === 1 || !N || (f[N] = Math.round(R * 100) / 100);
  }
  const B = r.getAll("severType").filter((N) => typeof N == "string" && N !== ""), I = Math.max(
    1,
    Math.floor(i("severMax", ((Ie = u == null ? void 0 : u.sever) == null ? void 0 : Ie.max) ?? d))
  ), z = (($e = u == null ? void 0 : u.sever) == null ? void 0 : $e.value) ?? I, y = o("bonusMode"), $ = {
    mode: y === "off" || y === "percent" || y === "flat" ? y : "inherit",
    value: Math.max(0, i("bonusValue", 0))
  }, ie = [];
  n.querySelectorAll("[data-reward]").forEach((N) => {
    const O = (bt) => {
      var Ce, Fe;
      return ((Fe = (Ce = N.querySelector(bt)) == null ? void 0 : Ce.value) == null ? void 0 : Fe.trim()) ?? "";
    }, R = O('input[name="rw_table"]');
    if (!R) return;
    const St = O('select[name="rw_event"]'), vt = O('select[name="rw_kind"]');
    ie.push({
      id: N.dataset.rewardId || foundry.utils.randomID(),
      kind: vt === "item" ? "item" : "table",
      uuid: R,
      draws: Math.max(1, Math.min(20, Math.floor(Number(O('input[name="rw_draws"]')) || 1))),
      onEvent: St === "sever" ? "sever" : "break"
    });
  });
  const C = {
    id: (u == null ? void 0 : u.id) ?? "",
    name: o("name"),
    ac: Math.max(0, Math.floor(i("ac", (u == null ? void 0 : u.ac) ?? 10))),
    hp: {
      max: d,
      value: Math.max(0, Math.min(d, Math.floor(i("hpValue", (u == null ? void 0 : u.hp.value) ?? d))))
    },
    breakable: r.get("breakable") === "on",
    severable: r.get("severable") === "on",
    state: o("state") || (u == null ? void 0 : u.state) || "intact",
    notes: o("notes"),
    onBreak: A,
    hitzone: f,
    sever: { value: Math.min(I, z), max: I },
    severTypes: B,
    rewards: ie,
    bonus: $
  };
  if (Bt(C).length > 0) {
    (Be = ui.notifications) == null || Be.error(h("MONSTER_ANATOMY.Editor.Invalid"));
    return;
  }
  if (u) {
    const { id: N, ...O } = C;
    await ue(s, u.id, O);
  } else {
    const N = ve(C.name || h("MONSTER_ANATOMY.Part.New"), {
      ac: C.ac,
      hp: C.hp.max
    });
    await Jt(s, { ...N, ...C, id: N.id });
  }
  l == null || l(), await this.close();
}, k(U, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-part-editor",
  classes: ["monster-anatomy", "monster-anatomy-editor"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Editor.Title",
    icon: "fa-solid fa-pen-to-square",
    resizable: !1
  },
  position: { width: 460, height: "auto" },
  actions: {
    "add-reward": U.onAddReward,
    "remove-reward": U.onRemoveReward
  }
}), k(U, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/part-editor.hbs" }
});
let me = U;
function we() {
  var t;
  const e = (t = CONFIG == null ? void 0 : CONFIG.DND5E) == null ? void 0 : t.damageTypes;
  return e && typeof e == "object" ? Object.entries(e).map(([a, n]) => ({ key: a, label: Mt(n) })) : [...xt].map((a) => ({ key: a, label: a }));
}
function Mt(e) {
  try {
    return h(e);
  } catch {
    return e;
  }
}
const { ApplicationV2: ka, HandlebarsApplicationMixin: Ea } = foundry.applications.api;
var F;
const ae = class ae extends Ea(ka) {
  constructor() {
    super(...arguments);
    G(this, F, null);
  }
  static async openFor(a) {
    await new ae({ actor: a }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(a) {
    const n = await super._prepareContext(a), r = T(this.actor).map((o) => {
      const i = o.hp.max > 0 ? o.hp.value / o.hp.max * 100 : 0;
      return {
        ...o,
        hp: { ...o.hp },
        hpPct: Math.max(0, Math.min(100, Math.round(i))),
        stateLabel: h(Z[o.state])
      };
    });
    return {
      ...n,
      actorName: this.actor.name,
      parts: r,
      empty: r.length === 0
    };
  }
  async _onRender(a, n) {
    await super._onRender(a, n), v(this, F) === null && _(this, F, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(a) {
    return v(this, F) !== null && (Hooks.off("updateActor", v(this, F)), _(this, F, null)), super.close(a);
  }
};
F = new WeakMap(), k(ae, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-tracker",
  classes: ["monster-anatomy", "monster-anatomy-tracker"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Tracker.Title",
    icon: "fa-solid fa-heart-pulse",
    resizable: !0
  },
  position: { width: 320, height: "auto" },
  actions: {}
}), k(ae, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-tracker.hbs" }
});
let de = ae;
const { ApplicationV2: xa, HandlebarsApplicationMixin: Ra } = foundry.applications.api;
var D;
const J = class J extends Ra(xa) {
  constructor() {
    super(...arguments);
    G(this, D, null);
  }
  static async openFor(a) {
    await new J({ actor: a }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(a) {
    const n = await super._prepareContext(a), r = this.actor, o = T(r).map((s) => ({
      name: s.name,
      stateLabel: h(Z[s.state]),
      hp: `${s.hp.value} / ${s.hp.max}`
    })), i = ft(r).map((s) => ({
      ...s,
      eventLabel: h(
        s.event === "sever" ? "MONSTER_ANATOMY.Reward.Sever" : "MONSTER_ANATOMY.Reward.Break"
      ),
      itemsText: s.items.join(", ")
    }));
    return {
      ...n,
      actorName: r.name,
      parts: o,
      loot: i,
      emptyParts: o.length === 0,
      emptyLoot: i.length === 0,
      canClear: E(r)
    };
  }
  async _onRender(a, n) {
    await super._onRender(a, n), v(this, D) === null && _(this, D, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(a) {
    return v(this, D) !== null && (Hooks.off("updateActor", v(this, D)), _(this, D, null)), super.close(a);
  }
  static async onClearLoot(a, n) {
    const r = this;
    E(r.actor) && await ha(r.actor);
  }
};
D = new WeakMap(), k(J, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-summary",
  classes: ["monster-anatomy", "monster-anatomy-summary"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Summary.Title",
    icon: "fa-solid fa-scroll",
    resizable: !0
  },
  position: { width: 460, height: "auto" },
  actions: {
    "clear-loot": J.onClearLoot
  }
}), k(J, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/loot-summary.hbs" }
});
let fe = J;
const { ApplicationV2: _a, HandlebarsApplicationMixin: Ya } = foundry.applications.api;
function Pa(e, t, a) {
  const n = e.hp.max > 0 ? e.hp.value / e.hp.max * 100 : 0, r = V(e).disableItemId.trim(), o = r ? t.items.get(r) : void 0, i = e.sever ?? { value: e.hp.max, max: e.hp.max }, s = i.max > 0 ? i.value / i.max * 100 : 0;
  return {
    ...e,
    hp: { ...e.hp },
    sever: { value: i.value, max: i.max },
    hpPct: Math.max(0, Math.min(100, Math.round(n))),
    stateLabel: h(Z[e.state]),
    hpMismatch: $t(e) !== e.state,
    linkedItemName: (o == null ? void 0 : o.name) ?? r,
    linkedDisabled: r !== "" && q(e.state),
    severPct: Math.max(0, Math.min(100, Math.round(s))),
    acDisplay: a ? "??" : String(e.ac)
  };
}
function Ke(e) {
  const t = e.closest(".ma-part"), a = t == null ? void 0 : t.querySelector("input.ma-amount"), n = Math.floor(Number(a == null ? void 0 : a.value));
  return Number.isFinite(n) && n > 0 ? n : null;
}
var L;
const w = class w extends Ya(_a) {
  constructor() {
    super(...arguments);
    G(this, L, null);
  }
  /** Abre o painel para um Actor. */
  static async openFor(a) {
    await new w({ actor: a }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(a) {
    const n = await super._prepareContext(a), r = this.actor, o = j(), i = re(r), s = i && !o, c = T(r).map((l) => Pa(l, r, s));
    return {
      ...n,
      actorName: r.name,
      actorImg: r.img ?? "icons/svg/mystery-man.svg",
      canEdit: E(r),
      isGM: o,
      hideAc: i,
      mapLayout: be(r),
      templates: Re().map((l) => ({ id: l.id, name: Wt(l) })),
      parts: c,
      empty: c.length === 0
    };
  }
  async _onRender(a, n) {
    await super._onRender(a, n);
    const r = this.element.querySelector("select.ma-map-select");
    r && (r.onchange = () => {
      E(this.actor) && ea(this.actor, r.value);
    }), v(this, L) === null && (_(this, L, Hooks.on("updateActor", (o) => {
      o.uuid === this.actor.uuid && this.render();
    })), ee(Q.PANEL_RENDER, this));
  }
  async close(a) {
    return v(this, L) !== null && (Hooks.off("updateActor", v(this, L)), _(this, L, null)), super.close(a);
  }
  // -- actions (this = instância, injetado pelo ApplicationV2) -----------------
  static async onAddPart(a, n) {
    const r = this;
    E(r.actor) && await me.openFor(r.actor, void 0, () => void r.render());
  }
  static async onEditPart(a, n) {
    const r = this;
    if (!E(r.actor)) return;
    const o = n.dataset.partId;
    o && await me.openFor(r.actor, o, () => void r.render());
  }
  static async onOpenTracker(a, n) {
    const r = this;
    await de.openFor(r.actor);
  }
  static async onOpenSummary(a, n) {
    const r = this;
    await fe.openFor(r.actor);
  }
  static async onDamagePart(a, n) {
    const r = this;
    if (!E(r.actor)) return;
    const o = n.dataset.partId, i = Ke(n);
    !o || i === null || await pt(r.actor, o, i);
  }
  static async onHealPart(a, n) {
    const r = this;
    if (!E(r.actor)) return;
    const o = n.dataset.partId, i = Ke(n);
    !o || i === null || await ht(r.actor, o, i);
  }
  static async onDeletePart(a, n) {
    const r = this;
    if (!E(r.actor)) return;
    const o = n.dataset.partId, i = T(r.actor).find((c) => c.id === o);
    !o || !i || !await foundry.applications.api.DialogV2.confirm({
      window: { title: h("MONSTER_ANATOMY.Delete.Title") },
      content: `<p>${S("MONSTER_ANATOMY.Delete.Prompt", { name: i.name })}</p>`,
      modal: !0
    }) || await Zt(r.actor, o);
  }
  static async onApplyTemplate(a, n) {
    var s;
    const r = this;
    if (!E(r.actor)) return;
    const o = r.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (i)
      try {
        const c = await nt(r.actor, i);
        (s = ui.notifications) == null || s.info(S("MONSTER_ANATOMY.Template.Applied", { count: String(c) }));
      } catch (c) {
        console.warn("monster-anatomy | falha ao aplicar modelo", c);
      }
  }
  static async onSaveTemplate(a, n) {
    var s, c;
    const r = this;
    if (!j()) return;
    const o = T(r.actor);
    if (o.length === 0) {
      (s = ui.notifications) == null || s.warn(h("MONSTER_ANATOMY.Template.Empty"));
      return;
    }
    const i = await Ha(r.actor.name);
    i && (await Xt(i, o, be(r.actor)), (c = ui.notifications) == null || c.info(S("MONSTER_ANATOMY.Template.Saved", { name: i })), r.render());
  }
  static async onDeleteTemplate(a, n) {
    var c, l;
    const r = this;
    if (!j()) return;
    const o = r.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (!i) return;
    if (!await Qt(i)) {
      (c = ui.notifications) == null || c.warn(h("MONSTER_ANATOMY.Template.Protected"));
      return;
    }
    (l = ui.notifications) == null || l.info(h("MONSTER_ANATOMY.Template.Deleted")), r.render();
  }
  static async onToggleHideAc(a, n) {
    const r = this;
    j() && await ta(r.actor, !re(r.actor));
  }
};
L = new WeakMap(), k(w, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-panel",
  classes: ["monster-anatomy", "monster-anatomy-panel"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Panel.Title",
    icon: "fa-solid fa-dragon",
    resizable: !0
  },
  position: { width: 500, height: "auto" },
  actions: {
    "add-part": w.onAddPart,
    "edit-part": w.onEditPart,
    "delete-part": w.onDeletePart,
    "open-tracker": w.onOpenTracker,
    "open-summary": w.onOpenSummary,
    "damage-part": w.onDamagePart,
    "heal-part": w.onHealPart,
    "apply-template": w.onApplyTemplate,
    "save-template": w.onSaveTemplate,
    "delete-template": w.onDeleteTemplate,
    "toggle-hide-ac": w.onToggleHideAc
  }
}), k(w, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-panel.hbs" }
});
let ke = w;
async function Ha(e) {
  const t = await foundry.applications.api.DialogV2.wait({
    window: { title: h("MONSTER_ANATOMY.Template.NameTitle") },
    content: `<div class="form-group"><label>${h("MONSTER_ANATOMY.Template.NamePrompt")}</label><input name="templateName" type="text" value="${e}" maxlength="80" /></div>`,
    buttons: [
      {
        action: "save",
        label: h("MONSTER_ANATOMY.Editor.Save"),
        default: !0,
        callback: (a, n) => {
          var o, i;
          const r = (o = n.form) == null ? void 0 : o.querySelector(
            'input[name="templateName"]'
          );
          return ((i = r == null ? void 0 : r.value) == null ? void 0 : i.trim()) ?? "";
        }
      }
    ],
    modal: !0
  });
  return typeof t != "string" || t.trim() === "" ? null : t.trim();
}
function Ia() {
  var t, a;
  return {
    version: ((a = (t = game.modules) == null ? void 0 : t.get(m)) == null ? void 0 : a.version) ?? "0.0.0",
    async openAnatomy(n) {
      await ke.openFor(n);
    },
    getParts(n) {
      return T(n);
    },
    canEdit(n) {
      return E(n);
    },
    damagePart(n, r, o, i) {
      return pt(n, r, o, i);
    },
    healPart(n, r, o) {
      return ht(n, r, o);
    },
    damagePartDetailed(n, r, o, i) {
      return Me(n, r, o, i);
    },
    getSelection() {
      return gt();
    },
    clearSelection() {
      H();
    },
    promptTargetSelection(n) {
      return At(n);
    },
    openTracker(n) {
      return de.openFor(n);
    },
    openSummary(n) {
      return fe.openFor(n);
    },
    on(n, r) {
      const o = n.startsWith("monsterAnatomy.") ? n : `monsterAnatomy.${n}`, i = ce(o, r);
      return () => Ct(o, i);
    },
    getTemplates() {
      return Re();
    },
    applyTemplate(n, r) {
      return nt(n, r);
    }
  };
}
function $a(e) {
  globalThis.MonsterAnatomy = e;
}
function Y(e) {
  return typeof e == "string" ? e : "";
}
function Ba(e) {
  if (!Array.isArray(e)) return [];
  const t = [];
  for (const a of e) {
    if (!a || typeof a != "object") continue;
    const n = Math.max(0, Math.floor(Number(a.amount) || 0));
    if (n <= 0) continue;
    const r = a.type;
    t.push(typeof r == "string" && r ? { amount: n, type: r } : { amount: n });
  }
  return t;
}
function Ca() {
  var e;
  return ((e = game.users) == null ? void 0 : e.some((t) => t.isGM && t.active)) ?? !1;
}
function Fa(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function Da() {
  var e;
  (e = game.socket) == null || e.on(`module.${m}`, (t) => {
    La(t);
  });
}
async function La(e) {
  var a, n, r;
  if (!e || typeof e != "object") return;
  const t = e;
  if (t.t === "apply") {
    if (!((a = game.user) != null && a.isGM)) return;
    const o = await fromUuid(
      Y(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = typeof t.attacker == "string" ? t.attacker : void 0, s = typeof t.attackerUuid == "string" ? t.attackerUuid : void 0, c = await Me(
      o,
      Y(t.partId),
      Ba(t.components),
      { attacker: i, attackerUuid: s }
    );
    await dt(
      o,
      ((n = T(o).find((l) => l.id === Y(t.partId))) == null ? void 0 : n.name) ?? Y(t.partId),
      c.applied,
      c.globalApplied,
      c.bonus,
      c.bonusFlat
    ), c.broke && pe(Y(t.actorUuid), Y(t.partId), "break"), c.severed && pe(Y(t.actorUuid), Y(t.partId), "sever");
  } else if (t.t === "present") {
    if (typeof t.by == "string" && t.by === ((r = game.user) == null ? void 0 : r.id)) return;
    const o = await fromUuid(
      Y(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = T(o).find((s) => s.id === Y(t.partId));
    if (!i) return;
    t.kind === "sever" ? ct(o, i) : st(o, i);
  }
}
function Tt(e) {
  var t;
  try {
    (t = game.socket) == null || t.emit(`module.${m}`, e);
  } catch (a) {
    console.warn("monster-anatomy | falha no socket", a);
  }
}
function za(e, t, a, n, r) {
  var i;
  const o = { t: "apply", actorUuid: e, partId: t, components: a, attacker: n, attackerUuid: r, by: (i = game.user) == null ? void 0 : i.id };
  Tt(o);
}
function pe(e, t, a = "break") {
  var r;
  const n = { t: "present", actorUuid: e, partId: t, kind: a, by: (r = game.user) == null ? void 0 : r.id };
  Tt(n);
}
let he = null;
function Ua() {
  ce("dnd5e.rollAttackV2", (...e) => void Va(e)), ce("dnd5e.rollDamageV2", (...e) => void Ga(e)), ce("dnd5e.preUseActivity", (...e) => qa(e)), Hooks.on("targetToken", (e, t, a) => {
    var n;
    e.id === ((n = game.user) == null ? void 0 : n.id) && (he = null);
  });
}
function qa(e) {
  var i;
  const [t] = e, a = t == null ? void 0 : t.item, n = t == null ? void 0 : t.actor, r = n instanceof Actor ? n : (a == null ? void 0 : a.parent) instanceof Actor ? a.parent : void 0;
  if (!r || typeof (a == null ? void 0 : a.id) != "string" || !Ft(r).has(a.id)) return;
  const o = Dt(r, a.id);
  return (i = ui.notifications) == null || i.warn(
    S("MONSTER_ANATOMY.Usage.Blocked", {
      item: typeof a.name == "string" ? a.name : a.id,
      part: (o == null ? void 0 : o.name) ?? "",
      actor: r.name
    })
  ), !1;
}
async function Va(e) {
  var I, z;
  const t = gt();
  if (!t) return;
  const a = [...((I = game.user) == null ? void 0 : I.targets) ?? []], n = a.length === 1 ? a[0] : void 0, r = ne(n), o = n == null ? void 0 : n.actor;
  if (!n || !r || !o || r !== t.tokenUuid || o.uuid !== t.actorUuid) {
    H();
    return;
  }
  const [i, s] = e, c = i == null ? void 0 : i[0], l = Number((c == null ? void 0 : c.total) ?? NaN);
  if (!Number.isFinite(l)) return;
  const u = ja(c), d = u === 20, g = u === 1, p = T(o).find((y) => y.id === t.partId);
  if (!p) {
    H();
    return;
  }
  const A = d || !g && l >= p.ac, f = Ja(s == null ? void 0 : s.subject), B = (f == null ? void 0 : f.name) ?? ((z = game.user) == null ? void 0 : z.name) ?? "?";
  if (he = {
    tokenUuid: r,
    actorUuid: o.uuid,
    partId: p.id,
    hit: A,
    crit: d,
    attacker: B,
    attackerUuid: f == null ? void 0 : f.uuid
  }, M("attackNotes")) {
    const y = A ? "MONSTER_ANATOMY.Attack.Hit" : "MONSTER_ANATOMY.Attack.Miss", $ = d && A ? ` ${h("MONSTER_ANATOMY.Attack.CritSuffix")}` : "", ie = re(o) ? "??" : String(p.ac), C = `<div class="monster-anatomy-chat ma-attack"><p>${S(y, {
      attacker: B,
      part: p.name,
      actor: o.name,
      total: String(l),
      ac: ie
    })}${$}</p></div>`, se = f ? ChatMessage.getSpeaker({ actor: f }) : ChatMessage.getSpeaker({ alias: B });
    await ChatMessage.create({ speaker: se, content: C });
  }
}
async function Ga(e) {
  var s, c, l, u;
  const t = he;
  if (he = null, !(t != null && t.hit)) return;
  const [a] = e, n = (a ?? []).map((d) => ({ amount: Number(d == null ? void 0 : d.total) || 0, type: Ka(d) })).filter((d) => d.amount > 0);
  if (n.length === 0) return;
  const r = [...((s = game.user) == null ? void 0 : s.targets) ?? []].find((d) => ne(d) === t.tokenUuid), o = r == null ? void 0 : r.actor;
  if (!o || o.uuid !== t.actorUuid) return;
  const i = ((c = T(o).find((d) => d.id === t.partId)) == null ? void 0 : c.name) ?? t.partId;
  if (Fa(o)) {
    const d = await Me(o, t.partId, n, {
      attacker: t.attacker,
      attackerUuid: t.attackerUuid
    });
    await dt(o, i, d.applied, d.globalApplied, d.bonus, d.bonusFlat), d.broke && pe(o.uuid, t.partId, "break"), d.severed && pe(o.uuid, t.partId, "sever");
  } else Ca() ? (za(o.uuid, t.partId, n, t.attacker, t.attackerUuid), (l = ui.notifications) == null || l.info(S("MONSTER_ANATOMY.Target.SentToGM", { part: i }))) : (u = ui.notifications) == null || u.warn(h("MONSTER_ANATOMY.Target.NoGM"));
}
function Ka(e) {
  var n, r;
  const t = e;
  if (typeof ((n = t.options) == null ? void 0 : n.type) == "string" && t.options.type) return t.options.type;
  const a = (r = t.options) == null ? void 0 : r.types;
  if (Array.isArray(a) && typeof a[0] == "string" && a[0]) return a[0];
}
function ja(e) {
  var a;
  const t = e == null ? void 0 : e.dice;
  if (Array.isArray(t))
    for (const n of t) {
      if ((n == null ? void 0 : n.faces) !== 20) continue;
      const r = n == null ? void 0 : n.results;
      if (!Array.isArray(r)) continue;
      const o = (a = r[0]) == null ? void 0 : a.result;
      if (typeof o == "number") return o;
    }
}
function Ja(e) {
  const t = e == null ? void 0 : e.actor;
  return t instanceof Actor ? t : void 0;
}
function Za() {
  va(), Ua();
}
function Wa() {
  game.settings.register(m, "showHeaderButton", {
    name: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "defaultAc", {
    name: "MONSTER_ANATOMY.Settings.DefaultAc.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultAc.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 10
  }), game.settings.register(m, "defaultHp", {
    name: "MONSTER_ANATOMY.Settings.DefaultHp.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultHp.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 20
  }), game.settings.register(m, "damageModel", {
    name: "MONSTER_ANATOMY.Settings.DamageModel.Name",
    hint: "MONSTER_ANATOMY.Settings.DamageModel.Hint",
    scope: "world",
    config: !0,
    type: String,
    choices: {
      independent: "MONSTER_ANATOMY.Settings.DamageModel.Independent",
      shared: "MONSTER_ANATOMY.Settings.DamageModel.Shared",
      percent: "MONSTER_ANATOMY.Settings.DamageModel.Percent"
    },
    default: "shared"
  }), game.settings.register(m, "damagePercent", {
    name: "MONSTER_ANATOMY.Settings.DamagePercent.Name",
    hint: "MONSTER_ANATOMY.Settings.DamagePercent.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 100, step: 5 },
    default: 50
  }), game.settings.register(m, "brokenBonus", {
    name: "MONSTER_ANATOMY.Settings.BrokenBonus.Name",
    hint: "MONSTER_ANATOMY.Settings.BrokenBonus.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 200, step: 5 },
    default: 50
  }), game.settings.register(m, "showAnnouncement", {
    name: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "announceDuration", {
    name: "MONSTER_ANATOMY.Settings.AnnounceDuration.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceDuration.Hint",
    scope: "client",
    config: !0,
    type: Number,
    range: { min: 0.5, max: 10, step: 0.5 },
    default: 2.5
  }), game.settings.register(m, "chatMessage", {
    name: "MONSTER_ANATOMY.Settings.ChatMessage.Name",
    hint: "MONSTER_ANATOMY.Settings.ChatMessage.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "tokenEffect", {
    name: "MONSTER_ANATOMY.Settings.TokenEffect.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenEffect.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "breakSound", {
    name: "MONSTER_ANATOMY.Settings.BreakSound.Name",
    hint: "MONSTER_ANATOMY.Settings.BreakSound.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "promptOnTarget", {
    name: "MONSTER_ANATOMY.Settings.PromptOnTarget.Name",
    hint: "MONSTER_ANATOMY.Settings.PromptOnTarget.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "attackNotes", {
    name: "MONSTER_ANATOMY.Settings.AttackNotes.Name",
    hint: "MONSTER_ANATOMY.Settings.AttackNotes.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "announceTheme", {
    name: "MONSTER_ANATOMY.Settings.AnnounceTheme.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceTheme.Hint",
    scope: "client",
    config: !0,
    type: String,
    choices: {
      persona: "MONSTER_ANATOMY.Settings.AnnounceTheme.Persona",
      monsterhunter: "MONSTER_ANATOMY.Settings.AnnounceTheme.MonsterHunter",
      jrpg: "MONSTER_ANATOMY.Settings.AnnounceTheme.Jrpg",
      minimal: "MONSTER_ANATOMY.Settings.AnnounceTheme.Minimal",
      impact: "MONSTER_ANATOMY.Settings.AnnounceTheme.Impact",
      arcade: "MONSTER_ANATOMY.Settings.AnnounceTheme.Arcade",
      carved: "MONSTER_ANATOMY.Settings.AnnounceTheme.Carved"
    },
    default: "persona"
  }), game.settings.register(m, "customKickerBreak", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "customKickerSever", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerSever.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerSever.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "tokenShake", {
    name: "MONSTER_ANATOMY.Settings.TokenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "screenFlash", {
    name: "MONSTER_ANATOMY.Settings.ScreenFlash.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenFlash.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "reducedMotion", {
    name: "MONSTER_ANATOMY.Settings.ReducedMotion.Name",
    hint: "MONSTER_ANATOMY.Settings.ReducedMotion.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !1
  }), game.settings.register(m, "particles", {
    name: "MONSTER_ANATOMY.Settings.Particles.Name",
    hint: "MONSTER_ANATOMY.Settings.Particles.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "screenShake", {
    name: "MONSTER_ANATOMY.Settings.ScreenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "templatesJson", {
    name: "MONSTER_ANATOMY.Settings.TemplatesJson.Name",
    hint: "MONSTER_ANATOMY.Settings.TemplatesJson.Hint",
    scope: "world",
    config: !1,
    type: String,
    default: "[]"
  });
}
function Nt(e) {
  const t = e == null ? void 0 : e.document;
  return t instanceof Actor ? t : void 0;
}
function wt() {
  try {
    return M("showHeaderButton");
  } catch {
    return !0;
  }
}
function je(e, t) {
  const a = Nt(e);
  !a || !Array.isArray(t) || !wt() || t.some((n) => (n == null ? void 0 : n.action) === "monster-anatomy") || t.unshift({
    action: "monster-anatomy",
    label: "MONSTER_ANATOMY.Panel.OpenButton",
    icon: "fa-solid fa-dragon",
    onClick: () => {
      var n;
      (n = Qe()) == null || n.openAnatomy(a);
    }
  });
}
function Xa() {
  Hooks.on("getHeaderControlsActorSheetV2", (...e) => {
    je(e[0], e[1]);
  }), Hooks.on("getHeaderControlsApplicationV2", (...e) => {
    je(e[0], e[1]);
  }), Hooks.on("getActorSheetHeaderButtons", (...e) => {
    const [t, a] = e, n = Nt(t) ?? (t == null ? void 0 : t.actor);
    if (!(n instanceof Actor) || !Array.isArray(a) || !wt()) return;
    const r = n;
    a.unshift({
      class: "monster-anatomy-open",
      icon: "fas fa-dragon",
      label: "MONSTER_ANATOMY.Panel.OpenButton",
      onclick: () => {
        var o;
        (o = Qe()) == null || o.openAnatomy(r);
      }
    });
  });
}
async function Qa() {
  await foundry.applications.handlebars.loadTemplates([
    "modules/monster-anatomy/templates/anatomy-panel.hbs",
    "modules/monster-anatomy/templates/anatomy-tracker.hbs",
    "modules/monster-anatomy/templates/loot-summary.hbs",
    "modules/monster-anatomy/templates/part-editor.hbs",
    "modules/monster-anatomy/templates/target-map.hbs"
  ]);
}
function Se(e, t) {
  try {
    t();
  } catch (a) {
    console.error(`${m} | falha no init (${e})`, a);
  }
}
Hooks.once("init", () => {
  var a;
  console.log(`${m} | init`), Se("settings", Wa), Se("header", Xa), Se("combat", Za);
  const e = Ia(), t = (a = game.modules) == null ? void 0 : a.get(m);
  t && (t.api = e), $a(e), Qa();
});
Hooks.once("setup", () => {
  console.log(`${m} | setup`);
});
Hooks.once("ready", () => {
  var e, t;
  console.log(`${m} | ready (v${((t = (e = game.modules) == null ? void 0 : e.get(m)) == null ? void 0 : t.version) ?? "?"})`), Da();
});
//# sourceMappingURL=main.js.map
