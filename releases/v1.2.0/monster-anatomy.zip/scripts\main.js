var Et = Object.defineProperty;
var De = (e) => {
  throw TypeError(e);
};
var xt = (e, t, n) => t in e ? Et(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n;
var E = (e, t, n) => xt(e, typeof t != "symbol" ? t + "" : t, n), Ne = (e, t, n) => t.has(e) || De("Cannot " + n);
var S = (e, t, n) => (Ne(e, t, "read from private field"), n ? n.call(e) : t.get(e)), U = (e, t, n) => t.has(e) ? De("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, n), _ = (e, t, n, r) => (Ne(e, t, "write to private field"), r ? r.call(e, n) : t.set(e, n), n), oe = (e, t, n) => (Ne(e, t, "access private method"), n);
const m = "monster-anatomy", je = m, Je = "parts", Q = {
  /** Disparado quando o painel de anatomia termina de renderizar. */
  PANEL_RENDER: "monsterAnatomy.panelRender",
  /** Disparado após criar/atualizar/remover uma parte. */
  PARTS_CHANGED: "monsterAnatomy.partsChanged",
  /** Disparado após aplicar dano a uma parte (sempre, mesmo sem quebra). */
  PART_DAMAGE: "monsterAnatomy.partDamage",
  /** Disparado na transição para quebrado (uma vez por transição). */
  PART_BREAK: "monsterAnatomy.partBreak",
  /** Disparado na transição para cortado (uma vez por transição). */
  PART_SEVER: "monsterAnatomy.partSever"
}, We = { mode: "inherit", value: 0 };
function Qe(e) {
  const t = e.bonus;
  if (!t || typeof t != "object") return { ...We };
  const n = t.mode === "off" || t.mode === "percent" || t.mode === "flat" ? t.mode : "inherit", r = Number.isFinite(Number(t.value)) ? Math.max(0, Number(t.value)) : 0;
  return { mode: n, value: r };
}
function Ae(e) {
  if (!Array.isArray(e.rewards)) return [];
  const t = [];
  for (const n of e.rewards) {
    if (!n || typeof n != "object") continue;
    const r = n, a = typeof r.uuid == "string" && r.uuid.trim() !== "" ? r.uuid.trim() : typeof r.tableUuid == "string" ? r.tableUuid.trim() : "";
    a !== "" && t.push({
      id: typeof r.id == "string" && r.id !== "" ? r.id : foundry.utils.randomID(),
      kind: r.kind === "item" ? "item" : "table",
      uuid: a,
      draws: Math.max(1, Math.min(20, Math.floor(Number(r.draws) || 1))),
      onEvent: r.onEvent === "sever" ? "sever" : "break"
    });
  }
  return t;
}
const Rt = ["slashing", "piercing", "bludgeoning"], _t = [
  "slashing",
  "piercing",
  "bludgeoning",
  "fire",
  "cold",
  "lightning",
  "thunder",
  "acid",
  "poison",
  "psychic",
  "necrotic",
  "radiant",
  "force"
];
function Yt(e, t) {
  var r;
  if (!t) return 1;
  const n = (r = e.hitzone) == null ? void 0 : r[t];
  return typeof n == "number" && Number.isFinite(n) && n >= 0 ? n : 1;
}
function It(e) {
  return e.severable && (e.severTypes ?? []).length > 0;
}
function z(e) {
  return e === "broken" || e === "severed";
}
const b = {
  disableItemId: "",
  disableItemName: "",
  effectName: "",
  effectIcon: "",
  effectDuration: null,
  condition: "",
  setAttrPath: "",
  setAttrValue: "",
  macroUuid: ""
};
function V(e) {
  return { ...b, ...e.onBreak ?? {} };
}
function Pt(e, t, n, r) {
  return {
    id: foundry.utils.randomID(),
    name: e,
    parts: t.map((a) => {
      var o;
      return {
        name: a.name,
        img: a.img ?? "",
        ac: a.ac,
        hpMax: a.hp.max,
        breakable: a.breakable,
        severable: a.severable,
        hitzone: { ...a.hitzone ?? {} },
        severMax: ((o = a.sever) == null ? void 0 : o.max) ?? a.hp.max,
        severTypes: [...a.severTypes ?? ["slashing"]],
        onBreak: V(a),
        rewards: Ae(a).map((i) => ({ ...i }))
      };
    })
  };
}
function Ht(e, t) {
  return e.parts.map((n) => {
    const r = Math.max(1, Math.floor(n.hpMax)), a = se(n.name || "Nova parte", {
      ac: Math.max(0, Math.floor(n.ac)),
      hp: r
    });
    a.img = typeof n.img == "string" ? n.img : "", a.breakable = n.breakable !== !1, a.severable = n.severable === !0, a.hitzone = { ...n.hitzone ?? {} };
    const o = Math.max(1, Math.floor(n.severMax || r));
    a.sever = { value: o, max: o }, a.severTypes = [...n.severTypes ?? ["slashing"]], a.onBreak = { ...b, ...n.onBreak ?? {} }, a.rewards = (n.rewards ?? []).map((l) => ({ ...l }));
    const i = a.onBreak.disableItemName.trim(), s = i ? [...t.items].find((l) => l.name === i) : void 0, c = !s && a.onBreak.disableItemId.trim() ? t.items.get(a.onBreak.disableItemId.trim()) : void 0, u = s ?? c;
    return a.onBreak.disableItemId = typeof (u == null ? void 0 : u.id) == "string" ? u.id : "", a.onBreak.disableItemName = typeof (u == null ? void 0 : u.name) == "string" ? u.name : i, a;
  });
}
const Bt = [
  {
    id: "builtin-dragonoid",
    name: "MONSTER_ANATOMY.Template.Dragonoid",
    builtin: !0,
    map: "dragonoid",
    parts: [
      { name: "Cabeça", ac: 21, hpMax: 80, breakable: !0, severable: !1, hitzone: { bludgeoning: 1.5, piercing: 0.8 }, severMax: 80, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Corpo", ac: 19, hpMax: 100, breakable: !0, severable: !1, hitzone: {}, severMax: 100, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Asa Esquerda", ac: 20, hpMax: 60, breakable: !0, severable: !1, hitzone: {}, severMax: 60, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Asa Direita", ac: 20, hpMax: 60, breakable: !0, severable: !1, hitzone: {}, severMax: 60, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Cauda", ac: 22, hpMax: 70, breakable: !0, severable: !0, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...b, disableItemName: "Tail Swipe" }, rewards: [] }
    ]
  },
  {
    id: "builtin-humanoid",
    name: "MONSTER_ANATOMY.Template.Humanoid",
    builtin: !0,
    map: "humanoid",
    parts: [
      { name: "Cabeça", ac: 20, hpMax: 50, breakable: !0, severable: !1, hitzone: { bludgeoning: 1.5 }, severMax: 50, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Corpo", ac: 18, hpMax: 80, breakable: !0, severable: !1, hitzone: {}, severMax: 80, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Braço Esquerdo", ac: 18, hpMax: 40, breakable: !0, severable: !1, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Braço Direito", ac: 18, hpMax: 40, breakable: !0, severable: !1, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Perna Esquerda", ac: 18, hpMax: 50, breakable: !0, severable: !1, hitzone: {}, severMax: 50, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] },
      { name: "Perna Direita", ac: 18, hpMax: 50, breakable: !0, severable: !1, hitzone: {}, severMax: 50, severTypes: ["slashing"], onBreak: { ...b }, rewards: [] }
    ]
  }
], ae = {
  intact: "MONSTER_ANATOMY.State.Intact",
  damaged: "MONSTER_ANATOMY.State.Damaged",
  broken: "MONSTER_ANATOMY.State.Broken",
  severed: "MONSTER_ANATOMY.State.Severed",
  destroyed: "MONSTER_ANATOMY.State.Destroyed"
};
let Le = 0;
function $t() {
  Le += 1;
  const e = Math.random().toString(36).slice(2, 8);
  return `part-${Date.now().toString(36)}-${e}-${Le}`;
}
function se(e, t) {
  const n = Math.max(1, Math.floor(t.hp));
  return {
    id: $t(),
    name: e.trim(),
    ac: Math.max(0, Math.floor(t.ac)),
    hp: { value: n, max: n },
    breakable: !0,
    severable: !1,
    state: "intact",
    notes: "",
    img: "",
    zone: null,
    onBreak: { ...b },
    hitzone: {},
    sever: { value: n, max: n },
    severTypes: ["slashing"],
    rewards: [],
    bonus: { ...We }
  };
}
function Ft(e) {
  return e.hp.value <= 0 && e.breakable ? "broken" : e.hp.value < e.hp.max ? "damaged" : "intact";
}
function Ct(e) {
  var n;
  const t = [];
  return (n = e.name) != null && n.trim() || t.push("name"), (e.ac === void 0 || !Number.isFinite(e.ac) || e.ac < 0) && t.push("ac"), (e.hp === void 0 || !Number.isFinite(e.hp.max) || e.hp.max < 1) && t.push("hp.max"), e.hp !== void 0 && (!Number.isFinite(e.hp.value) || e.hp.value < 0) && t.push("hp.value"), t;
}
function Oe(e) {
  return {
    ...e,
    hp: { ...e.hp },
    onBreak: V(e),
    hitzone: { ...e.hitzone ?? {} },
    sever: e.sever ? { ...e.sever } : { value: e.hp.max, max: e.hp.max },
    severTypes: [...e.severTypes ?? ["slashing"]],
    rewards: Ae(e).map((t) => ({ ...t })),
    bonus: Qe(e)
  };
}
function p(e) {
  var t;
  return ((t = game.i18n) == null ? void 0 : t.localize(e)) ?? e;
}
function v(e, t) {
  var n;
  return ((n = game.i18n) == null ? void 0 : n.format(e, t)) ?? e;
}
function h(e) {
  return game.settings.get(m, e);
}
function te(e) {
  if (!e || typeof e != "object") return;
  const t = e;
  if (typeof t.uuid == "string" && t.uuid) return t.uuid;
  if (t.document && typeof t.document == "object") {
    const n = t.document.uuid;
    if (typeof n == "string" && n) return n;
  }
}
function Xe() {
  var e, t;
  return (t = (e = game.modules) == null ? void 0 : e.get(m)) == null ? void 0 : t.api;
}
function X(e, ...t) {
  Hooks.callAll.call(Hooks, e, ...t);
}
function ie(e, t) {
  return Hooks.on.call(Hooks, e, t);
}
function Dt(e, t) {
  Hooks.off.call(Hooks, e, t);
}
const Ee = "attrBackup";
function Lt(e) {
  const t = /* @__PURE__ */ new Set();
  for (const n of Ze(e)) {
    if (!z(n.state)) continue;
    const r = V(n).disableItemId.trim();
    r && t.add(r);
  }
  return t;
}
function qt(e, t) {
  return Ze(e).find(
    (n) => z(n.state) && V(n).disableItemId.trim() === t
  );
}
function Ze(e) {
  const t = e.getFlag(m, "parts");
  return Array.isArray(t) ? t : [];
}
async function Ut(e, t) {
  const n = V(t);
  n.effectName.trim() && await zt(e, t, n.effectName.trim(), n), n.condition.trim() && await Vt(e, t, n.condition.trim()), n.setAttrPath.trim() && await Gt(e, t, n), n.macroUuid.trim() && await jt(n.macroUuid.trim());
}
async function qe(e, t) {
  for (const n of [...e.effects])
    try {
      if (n.getFlag(m, "partId") !== t.id) continue;
      const r = n.getFlag(m, "kind");
      (r === "break-effect" || r === "break-condition" || r === "part-broken" || r === "part-severed") && await n.delete();
    } catch (r) {
      console.warn("monster-anatomy | falha ao remover efeito da parte", r);
    }
  await Kt(e, t.id);
}
async function zt(e, t, n, r) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(m, "partId") === t.id && i.getFlag(m, "kind") === "break-effect";
    } catch {
      return !1;
    }
  })) return;
  const o = {};
  o[m] = { partId: t.id, kind: "break-effect" }, await ActiveEffect.create(
    {
      name: n,
      img: r.effectIcon.trim() || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      duration: typeof r.effectDuration == "number" ? { rounds: r.effectDuration } : void 0,
      flags: o
    },
    { parent: e }
  );
}
async function Vt(e, t, n) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(m, "partId") === t.id && i.getFlag(m, "kind") === "break-condition";
    } catch {
      return !1;
    }
  })) return;
  const a = CONFIG.statusEffects.find(
    (i) => (i == null ? void 0 : i.id) === n
  ), o = {};
  o[m] = { partId: t.id, kind: "break-condition" }, await ActiveEffect.create(
    {
      name: v("MONSTER_ANATOMY.Effect.ConditionName", {
        status: (a == null ? void 0 : a.name) ?? n,
        part: t.name
      }),
      img: (a == null ? void 0 : a.img) || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      statuses: [n],
      flags: o
    },
    { parent: e }
  );
}
async function Gt(e, t, n) {
  const r = n.setAttrPath.trim(), a = et(e);
  t.id in a || (a[t.id] = { [r]: foundry.utils.getProperty(e, r) }, await e.setFlag(m, Ee, a)), await e.update({
    [r]: Jt(n.setAttrValue)
  });
}
async function Kt(e, t) {
  const n = et(e), r = n[t];
  if (!r) return;
  const a = {};
  for (const [o, i] of Object.entries(r)) a[o] = i;
  delete n[t];
  try {
    await e.update(a);
  } catch (o) {
    console.warn("monster-anatomy | falha ao restaurar atributo", o);
  }
  await e.setFlag(m, Ee, n);
}
function et(e) {
  try {
    const t = e.getFlag(m, Ee);
    if (t && typeof t == "object" && !Array.isArray(t))
      return JSON.parse(JSON.stringify(t));
  } catch {
  }
  return {};
}
async function jt(e) {
  try {
    const n = await fromUuid(e);
    typeof (n == null ? void 0 : n.execute) == "function" ? await n.execute() : console.warn(`monster-anatomy | macro não encontrada (${e})`);
  } catch (t) {
    console.warn(`monster-anatomy | falha ao executar macro (${e})`, t);
  }
}
function Jt(e) {
  const t = e.trim();
  return t === "true" ? !0 : t === "false" ? !1 : t !== "" && Number.isFinite(Number(t)) ? Number(t) : e;
}
function A(e) {
  const t = e.getFlag(je, Je);
  return Array.isArray(t) ? t.map((n) => ({ ...n, hp: { ...n.hp } })) : [];
}
async function ye(e, t) {
  var r;
  if (!e.isOwner)
    throw (r = ui.notifications) == null || r.warn(p("MONSTER_ANATOMY.Errors.NoPermission")), new Error("monster-anatomy: actor não editável pelo usuário atual");
  const n = A(e);
  await e.setFlag(je, Je, t.map(Oe)), await Wt(e, n, t), X(Q.PARTS_CHANGED, e, A(e));
}
async function Wt(e, t, n) {
  var o;
  const r = new Map(t.map((i) => [i.id, i])), a = new Set(n.map((i) => i.id));
  for (const i of n) {
    const s = z(((o = r.get(i.id)) == null ? void 0 : o.state) ?? "intact"), c = z(i.state);
    if (c !== s)
      try {
        c ? await Ut(e, i) : await qe(e, i);
      } catch (u) {
        console.warn("monster-anatomy | falha na vinculação de ruptura", u);
      }
  }
  for (const i of t)
    if (!(a.has(i.id) || !z(i.state)))
      try {
        await qe(e, i);
      } catch (s) {
        console.warn("monster-anatomy | falha na limpeza de ruptura", s);
      }
}
async function tt(e, t) {
  const n = A(e);
  if (n.some((r) => r.id === t.id))
    throw new Error(`monster-anatomy: id de parte duplicado (${t.id})`);
  n.push(Oe(t)), await ye(e, n);
}
async function ce(e, t, n) {
  const r = A(e), a = r.findIndex((i) => i.id === t);
  if (a < 0) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = r[a];
  r[a] = {
    ...o,
    ...n,
    id: o.id,
    // id é imutável (§5.1 do design)
    hp: { ...o.hp, ...n.hp ?? {} }
  }, await ye(e, r);
}
async function Qt(e, t) {
  const n = A(e).filter((r) => r.id !== t);
  await ye(e, n);
}
function O(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function W() {
  var e;
  return ((e = game.user) == null ? void 0 : e.isGM) === !0;
}
function Xt(e) {
  const t = e.name.startsWith("MONSTER_ANATOMY.") ? p(e.name) : e.name;
  return e.builtin ? `${t} ${p("MONSTER_ANATOMY.Template.BuiltinTag")}` : t;
}
function xe() {
  return [...Bt, ...ue()];
}
function ue() {
  try {
    const e = h("templatesJson");
    if (typeof e != "string" || e.trim() === "") return [];
    const t = JSON.parse(e);
    return Array.isArray(t) ? t.filter(
      (n) => !!n && typeof n == "object" && typeof n.id == "string"
    ) : [];
  } catch {
    return [];
  }
}
async function nt(e) {
  await game.settings.set(m, "templatesJson", JSON.stringify(e));
}
async function Zt(e, t, n, r) {
  const a = Pt(e, t);
  return await nt([...ue(), a]), a;
}
async function en(e) {
  if (e.startsWith("builtin-")) return !1;
  const t = ue().filter((n) => n.id !== e);
  return t.length === ue().length ? !1 : (await nt(t), !0);
}
async function at(e, t) {
  const n = xe().find((a) => a.id === t);
  if (!n) throw new Error(`monster-anatomy: modelo não encontrado (${t})`);
  const r = Ht(n, e);
  return await ye(e, [...A(e), ...r]), n.map && await e.setFlag(m, "mapLayout", n.map), typeof n.mapImage == "string" && n.mapImage !== "" && await e.setFlag(m, "mapImage", n.mapImage), r.length;
}
function le(e) {
  try {
    return e.getFlag(m, "hideAc") === !0;
  } catch {
    return !1;
  }
}
async function tn(e, t) {
  await e.setFlag(m, "hideAc", t);
}
function Re() {
  var e;
  try {
    if (h("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function nn(e) {
  if (Re()) return;
  const t = e.textContent ?? "";
  if (t.length === 0 || t.length > 24) return;
  e.textContent = "";
  let n = 0;
  for (const r of Array.from(t)) {
    if (r === " ") {
      e.appendChild(document.createTextNode(" "));
      continue;
    }
    const a = document.createElement("span");
    a.className = "ma-letter", a.textContent = r, a.style.setProperty("--i", String(n)), e.appendChild(a), n++;
  }
}
function rt(e) {
  try {
    if (h("particles") !== !0 || Re() || document.hidden) return;
  } catch {
    return;
  }
  const t = document.createElement("canvas");
  t.className = "monster-anatomy-particles";
  const n = Math.min(2, window.devicePixelRatio || 1);
  t.width = Math.floor(window.innerWidth * n), t.height = Math.floor(window.innerHeight * n), document.body.appendChild(t);
  const r = t.getContext("2d");
  if (!r) {
    t.remove();
    return;
  }
  r.scale(n, n);
  const a = window.innerWidth / 2, o = window.innerHeight / 2 - window.innerHeight * 0.06, i = e ? ["#9adcff", "#e8f7ff", "#4da6d8", "#0e4d64", "#ffffff"] : ["#ff3b3b", "#ffb454", "#fff3d6", "#7a1a00", "#1a1a1a"], s = [], c = 90;
  for (let y = 0; y < c; y++) {
    const T = Math.random() * Math.PI * 2, M = 180 + Math.random() * 560, f = 0.7 + Math.random() * 0.6;
    s.push({
      x: a + (Math.random() - 0.5) * 60,
      y: o + (Math.random() - 0.5) * 30,
      vx: Math.cos(T) * M,
      vy: Math.sin(T) * M - 160,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 14,
      size: 3 + Math.random() * 8,
      life: f,
      maxLife: f,
      color: i[Math.floor(Math.random() * i.length)],
      circle: Math.random() < 0.3
    });
  }
  const u = 900;
  let l = performance.now();
  const d = (y) => {
    const T = Math.min(0.05, (y - l) / 1e3);
    l = y, r.clearRect(0, 0, window.innerWidth, window.innerHeight);
    let M = !1;
    for (const f of s)
      f.life -= T, !(f.life <= 0) && (M = !0, f.vy += u * T, f.x += f.vx * T, f.y += f.vy * T, f.rot += f.vr * T, r.save(), r.globalAlpha = Math.max(0, f.life / f.maxLife), r.translate(f.x, f.y), r.rotate(f.rot), r.fillStyle = f.color, f.circle ? (r.beginPath(), r.arc(0, 0, f.size / 2, 0, Math.PI * 2), r.fill()) : r.fillRect(-f.size / 2, -f.size / 4, f.size, f.size / 2), r.restore());
    M ? requestAnimationFrame(d) : t.remove();
  };
  requestAnimationFrame(d);
}
function ot() {
  try {
    if (h("screenShake") !== !0 || Re()) return;
  } catch {
    return;
  }
  const e = document.getElementById("board");
  if (!e) return;
  const t = 11, n = 380, r = performance.now(), a = (o) => {
    const i = o - r;
    if (i >= n) {
      e.style.transform = "";
      return;
    }
    const s = 1 - i / n, c = Math.sin(o / 17) * t * s, u = Math.cos(o / 23) * t * 0.7 * s;
    e.style.transform = `translate(${c.toFixed(1)}px, ${u.toFixed(1)}px)`, requestAnimationFrame(a);
  };
  requestAnimationFrame(a);
}
async function an(e, t, n) {
  h("showAnnouncement") && st(e, t), h("chatMessage") && await un(e, t, n), h("tokenEffect") && await mn(e, t), await it();
}
async function rn(e, t, n) {
  h("showAnnouncement") && ct(e, t), h("chatMessage") && await ln(e, t, n), h("tokenEffect") && await dn(e, t), await it();
}
async function it() {
  const e = String(h("breakSound") ?? "").trim();
  if (e)
    try {
      await foundry.audio.AudioHelper.play({ src: e, volume: 0.8 });
    } catch (t) {
      console.warn(`monster-anatomy | falha ao tocar som (${e})`, t);
    }
}
function x(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function st(e, t) {
  const n = Math.max(0.5, Math.min(10, Number(h("announceDuration") ?? 2.5)));
  ut(e, t, n, !1), lt(!1), mt(e), rt(!1), ot();
}
function ct(e, t) {
  const n = Math.max(0.5, Math.min(10, Number(h("announceDuration") ?? 2.5)));
  ut(e, t, n, !0), lt(!0), mt(e), rt(!0), ot();
}
function _e() {
  var e;
  try {
    if (h("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function on() {
  const e = String(h("announceTheme") ?? "persona");
  return e === "monsterhunter" || e === "jrpg" || e === "minimal" || e === "impact" || e === "arcade" || e === "carved" ? e : "persona";
}
function sn(e) {
  const t = String(
    h(e ? "customKickerSever" : "customKickerBreak") ?? ""
  ).trim();
  return t !== "" ? t : p(e ? "MONSTER_ANATOMY.Announce.Severed" : "MONSTER_ANATOMY.Announce.Break");
}
function ut(e, t, n, r) {
  document.querySelectorAll(".monster-anatomy-announce").forEach((s) => s.remove());
  const a = document.createElement("div");
  a.className = `monster-anatomy-announce theme-${on()}` + (r ? " is-sever" : ""), a.style.setProperty("--ma-duration", `${n}s`), _e() && a.classList.add("is-reduced");
  const o = sn(r);
  a.innerHTML = `<div class="ma-announce-kicker">${x(o)}</div><div class="ma-announce-part">${x(t.name)}</div><div class="ma-announce-actor">${x(e.name)}</div>`, document.body.appendChild(a);
  const i = a.querySelector(".ma-announce-kicker");
  i && nn(i), requestAnimationFrame(() => a.classList.add("is-showing")), window.setTimeout(() => {
    a.classList.remove("is-showing"), window.setTimeout(() => a.remove(), 450);
  }, Math.max(400, Math.round(n * 1e3)));
}
function lt(e) {
  try {
    if (h("screenFlash") !== !0 || _e()) return;
  } catch {
    return;
  }
  const t = document.createElement("div");
  t.className = "monster-anatomy-flash" + (e ? " is-sever" : ""), document.body.appendChild(t), requestAnimationFrame(() => t.classList.add("is-showing")), window.setTimeout(() => t.classList.remove("is-showing"), 120), window.setTimeout(() => t.remove(), 450);
}
function mt(e) {
  try {
    if (h("tokenShake") !== !0 || _e()) return;
  } catch {
    return;
  }
  try {
    const t = e.getActiveTokens();
    for (const n of t) {
      const r = n == null ? void 0 : n.mesh;
      cn(r);
    }
  } catch {
  }
}
function cn(e) {
  const t = e == null ? void 0 : e.position;
  if (!t || typeof t.x != "number" || typeof t.y != "number") return;
  const n = t.x, r = t.y, a = 9, o = 420, i = performance.now(), s = typeof t.set == "function" ? t.set.bind(t) : null, c = (l, d) => {
    s ? s(l, d) : (t.x = l, t.y = d);
  }, u = (l) => {
    const d = l - i;
    if (d >= o) {
      c(n, r);
      return;
    }
    const y = 1 - d / o;
    c(n + Math.sin(l / 16) * a * y, r), requestAnimationFrame(u);
  };
  requestAnimationFrame(u);
}
async function un(e, t, n) {
  const r = n.attacker ? `<p class="ma-chat-attacker">${x(
    v("MONSTER_ANATOMY.Chat.BreakBy", {
      attacker: n.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", a = `<div class="monster-anatomy-chat ma-break"><h3>💥 ${x(p("MONSTER_ANATOMY.Announce.Break"))}</h3><p>${x(
    v("MONSTER_ANATOMY.Chat.BreakText", {
      part: t.name,
      actor: e.name,
      amount: String(n.amount)
    })
  )}</p>${r}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: a
  });
}
async function dt(e, t, n, r, a = 0, o = 0) {
  let i = !1;
  try {
    i = h("attackNotes") === !0;
  } catch {
    return;
  }
  if (!i) return;
  const s = [];
  a > 0 && s.push(`+${a}%`), o > 0 && s.push(`+${o}`);
  const c = s.length > 0 ? ` ${v("MONSTER_ANATOMY.Routed.Bonus", { mark: s.join(" ") })}` : "";
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-routed"><p>${x(
      v("MONSTER_ANATOMY.Routed.Text", {
        amount: String(n),
        part: t,
        actor: e.name,
        global: String(r)
      })
    )}${x(c)}</p></div>`
  });
}
async function ln(e, t, n) {
  const r = n.attacker ? `<p class="ma-chat-attacker">${x(
    v("MONSTER_ANATOMY.Chat.SeverBy", {
      attacker: n.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", a = `<div class="monster-anatomy-chat ma-break ma-sever"><h3>🗡️ ${x(p("MONSTER_ANATOMY.Announce.Severed"))}</h3><p>${x(
    v("MONSTER_ANATOMY.Chat.SeverText", {
      part: t.name,
      actor: e.name,
      amount: String(n.amount)
    })
  )}</p>${r}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: a
  });
}
async function mn(e, t) {
  if (e.effects.some((a) => {
    try {
      return a.getFlag(m, "partId") === t.id;
    } catch {
      return !1;
    }
  })) return;
  const r = {};
  r[m] = { partId: t.id, kind: "part-broken" }, await ActiveEffect.create(
    {
      name: v("MONSTER_ANATOMY.Effect.BrokenName", { part: t.name }),
      img: "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      flags: r
    },
    { parent: e }
  );
}
async function dn(e, t) {
  if (e.effects.some((a) => {
    try {
      return a.getFlag(m, "partId") === t.id && a.getFlag(m, "kind") === "part-severed";
    } catch {
      return !1;
    }
  })) return;
  const r = {};
  r[m] = { partId: t.id, kind: "part-severed" }, await ActiveEffect.create(
    {
      name: v("MONSTER_ANATOMY.Effect.SeveredName", { part: t.name }),
      img: "systems/dnd5e/icons/svg/damage/slashing.svg",
      origin: e.uuid,
      disabled: !1,
      flags: r
    },
    { parent: e }
  );
}
const Ye = "loot", fn = 20;
async function Ue(e, t, n, r = {}) {
  const a = Ae(t).filter((c) => c.onEvent === n);
  if (a.length === 0) return;
  const o = await pn(e, r.attackerUuid), i = [];
  let s;
  for (const c of a) {
    if (c.kind === "item") {
      const l = await hn(e, o, c.uuid, c.draws);
      l && (i.push(c.draws > 1 ? `${l} ×${c.draws}` : l), o && (s = o.name));
      continue;
    }
    const u = await yn(c.uuid);
    if (!u) {
      console.warn(`monster-anatomy | tabela não encontrada (${c.uuid})`);
      continue;
    }
    for (let l = 0; l < Math.min(Math.floor(c.draws), fn); l++)
      try {
        const d = await u.draw({ displayChat: !1 });
        for (const y of d.results ?? []) {
          const T = Mn(y);
          T && i.push(T);
        }
      } catch (d) {
        console.warn("monster-anatomy | falha no sorteio", d);
        break;
      }
  }
  i.length !== 0 && (await An(e, {
    partId: t.id,
    partName: t.name,
    event: n,
    items: i,
    ...s ? { grantedTo: s } : {},
    at: Date.now()
  }), h("chatMessage") && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-loot"><h3>🎁 ${ze(p("MONSTER_ANATOMY.Loot.Title"))}</h3><p>${ze(
      v("MONSTER_ANATOMY.Loot.Text", {
        part: t.name,
        actor: e.name,
        items: i.join(", ")
      })
    )}</p></div>`
  }));
}
async function pn(e, t) {
  const n = t && t !== e.uuid ? t : void 0;
  if (n) {
    const a = await Ie(n);
    if (a instanceof Actor && a.uuid !== e.uuid) return a;
  }
  const r = game.user;
  if (r && !r.isGM) {
    const a = r.character;
    if (a instanceof Actor && a.uuid !== e.uuid) return a;
  }
  return null;
}
async function hn(e, t, n, r) {
  var i, s, c;
  const a = await Ie(n);
  if (!(a instanceof Item))
    return console.warn(`monster-anatomy | item não encontrado (${n})`), null;
  const o = typeof a.name == "string" ? a.name : n;
  if (!t)
    return console.warn("monster-anatomy | sem atacante para entregar o item; registrado no pool"), o;
  try {
    const u = a.toObject() ?? {};
    delete u._id;
    const d = await t.createEmbeddedDocuments.call(t, "Item", [u]);
    if (r > 1 && ((i = d[0]) != null && i.update))
      try {
        await ((c = (s = d[0]).update) == null ? void 0 : c.call(s, { "system.quantity": r }));
      } catch {
      }
    return o;
  } catch (u) {
    return console.warn("monster-anatomy | falha ao criar item no recebedor", u), o;
  }
}
function ft(e) {
  try {
    const t = e.getFlag(m, Ye);
    return Array.isArray(t) ? t.filter((n) => n && Array.isArray(n.items)) : [];
  } catch {
    return [];
  }
}
async function gn(e) {
  await e.setFlag(m, Ye, []);
}
async function An(e, t) {
  const n = [...ft(e), t].slice(-200);
  await e.setFlag(m, Ye, n);
}
async function yn(e) {
  const t = await Ie(e);
  return t instanceof RollTable ? t : null;
}
async function Ie(e) {
  try {
    return await fromUuid(e);
  } catch {
    return null;
  }
}
function Mn(e) {
  const t = e;
  return typeof (t == null ? void 0 : t.name) == "string" && t.name ? t.name : typeof (t == null ? void 0 : t.text) == "string" && t.text ? t.text : typeof (t == null ? void 0 : t.id) == "string" && t.id ? t.id : "";
}
function ze(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
const we = "system.attributes.hp.value";
async function pt(e, t, n, r = {}) {
  return Me(e, t, [{ amount: n, type: r.type }], r);
}
async function Me(e, t, n, r = {}) {
  const a = A(e).find((g) => g.id === t);
  if (!a) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  let o = 0, i = 0;
  const s = It(a);
  for (const g of n) {
    const H = Math.max(0, Math.floor(Number(g == null ? void 0 : g.amount) || 0));
    H <= 0 || (o += H * Yt(a, g == null ? void 0 : g.type), s && typeof (g == null ? void 0 : g.type) == "string" && (a.severTypes ?? []).includes(g.type) && (i += H));
  }
  o = Math.floor(o);
  const c = a.state, u = Qe(a);
  let l = 0, d = 0;
  if (z(c) && (u.mode === "percent" ? l = Math.max(0, Math.min(200, u.value)) : u.mode === "flat" ? d = Math.max(0, Math.floor(u.value)) : u.mode !== "off" && (l = Math.max(0, Math.min(200, Number(h("brokenBonus") ?? 0))))), l > 0 || d > 0) {
    const g = 1 + l / 100;
    o = Math.floor(o * g) + d, i = Math.floor(i * g) + d;
  }
  const y = Math.max(0, a.hp.value - o);
  let T = c;
  y <= 0 && a.breakable ? T = "broken" : y < a.hp.max && c === "intact" && (T = "damaged"), await ce(e, t, { hp: { ...a.hp, value: y }, state: T });
  let M = A(e).find((g) => g.id === t);
  const f = await Tn(e, o);
  X(Q.PART_DAMAGE, e, M, o, r.attacker ?? null);
  const B = T === "broken" && c !== "broken";
  B && (await an(e, M, { amount: o, attacker: r.attacker }), await Ue(e, M, "break", { attackerUuid: r.attackerUuid }), X(Q.PART_BREAK, e, M, o, r.attacker ?? null));
  let $ = !1;
  const q = M.sever ?? { value: M.hp.max, max: M.hp.max };
  if (s && i > 0 && M.state !== "severed") {
    const g = Math.max(0, q.value - i);
    await ce(e, t, {
      sever: { value: g, max: q.max },
      ...g <= 0 ? { state: "severed" } : {}
    }), M = A(e).find((H) => H.id === t), g <= 0 && ($ = !0, await rn(e, M, { amount: i, attacker: r.attacker }), await Ue(e, M, "sever", { attackerUuid: r.attackerUuid }), X(Q.PART_SEVER, e, M, i, r.attacker ?? null));
  }
  return { part: M, broke: B, severed: $, globalApplied: f, applied: o, bonus: l, bonusFlat: d };
}
async function ht(e, t, n) {
  const r = Math.max(0, Math.floor(Number(n) || 0)), a = A(e).find((u) => u.id === t);
  if (!a) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = Math.min(a.hp.max, a.hp.value + r), i = o >= a.hp.max, s = i && (a.state === "damaged" || a.state === "broken") ? "intact" : a.state, c = a.sever ?? { value: a.hp.max, max: a.hp.max };
  return await ce(e, t, {
    hp: { ...a.hp, value: o },
    state: s,
    ...i ? { sever: { value: c.max, max: c.max } } : {}
  }), A(e).find((u) => u.id === t);
}
async function Tn(e, t) {
  if (t <= 0) return 0;
  const n = h("damageModel");
  if (n === "independent") return 0;
  const r = n === "percent" ? Math.max(0, Math.min(100, Number(h("damagePercent") ?? 50))) : 100, a = Math.floor(t * r / 100);
  if (a <= 0) return 0;
  const o = foundry.utils.getProperty(e, we);
  if (typeof o != "number")
    return console.warn(`monster-anatomy | HP global não encontrado em ${we}`), 0;
  const i = Math.max(0, o - a);
  return await e.update({
    [we]: i
  }), a;
}
const { ApplicationV2: Nn, HandlebarsApplicationMixin: wn } = foundry.applications.api;
function vn(e, t) {
  return {
    id: e.id,
    img: e.img ?? "",
    display: `${e.name} — CA ${t ? "??" : String(e.ac)} — ${e.hp.value}/${e.hp.max} • ${p(ae[e.state])}`
  };
}
var I, J, gt, At;
const Z = class Z extends wn(Nn) {
  constructor(n, r) {
    super(n);
    U(this, J);
    U(this, I, null);
    _(this, I, r);
  }
  /** Abre o seletor e resolve com o id da parte (null = normal/dispensado). */
  static pick(n) {
    return new Promise((r) => {
      new Z({ actor: n }, r).render(!0);
    });
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const r = await super._prepareContext(n), a = this.actor, o = le(a) && !W();
    return {
      ...r,
      actorName: a.name,
      canAdd: O(a),
      parts: A(a).map((i) => vn(i, o))
    };
  }
  async _onRender(n, r) {
    var o, i;
    await super._onRender(n, r);
    const a = (s) => {
      if (!S(this, I)) return;
      const c = S(this, I);
      _(this, I, null), c(s), this.close();
    };
    (o = this.element.querySelector("[data-parts]")) == null || o.addEventListener("click", (s) => {
      const c = s.target.closest("[data-part-id]"), u = c == null ? void 0 : c.dataset.partId;
      u && a(u);
    }), (i = this.element.querySelector("[data-normal]")) == null || i.addEventListener("click", () => a(null)), oe(this, J, gt).call(this);
  }
  async close(n) {
    if (S(this, I)) {
      const r = S(this, I);
      _(this, I, null), r(null);
    }
    return super.close(n);
  }
};
I = new WeakMap(), J = new WeakSet(), /** Quick-add: cria parte na hora (nome + imagem opcional) e atualiza a lista. */
gt = function() {
  var i, s;
  const n = this.element.querySelector('[data-qa="name"]'), r = this.element.querySelector('[data-qa="img"]'), a = this.element.querySelector('[data-qa="preview"]');
  if (!n || !r) return;
  const o = () => {
    if (!a) return;
    const c = r.value.trim();
    a.hidden = c === "", c !== "" && (a.src = c);
  };
  r.addEventListener("input", o), a == null || a.addEventListener("error", () => {
    a && (a.hidden = !0);
  }), (i = this.element.querySelector("[data-qa-browse]")) == null || i.addEventListener("click", () => {
    new foundry.applications.apps.FilePicker({
      type: "image",
      current: r.value,
      callback: (u) => {
        r.value = u, o();
      }
    }).render(!0);
  }), (s = this.element.querySelector("[data-qa-add]")) == null || s.addEventListener("click", () => {
    oe(this, J, At).call(this);
  });
}, At = async function() {
  const n = this.actor;
  if (!O(n)) return;
  const r = this.element.querySelector('[data-qa="name"]'), a = this.element.querySelector('[data-qa="img"]');
  if (!r || !a) return;
  const o = A(n).length, i = r.value.trim() || `${p("MONSTER_ANATOMY.Part.New")} ${o + 1}`, s = Number(h("defaultAc") ?? 10), c = Number(h("defaultHp") ?? 20), u = se(i, {
    ac: Number.isFinite(s) ? s : 10,
    hp: Number.isFinite(c) ? c : 20
  }), l = a.value.trim();
  l !== "" && (u.img = l), await tt(n, u), r.value = "", a.value = "", await this.render();
}, E(Z, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-target-map",
  classes: ["monster-anatomy", "monster-anatomy-target"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Target.Title",
    icon: "fa-solid fa-crosshairs",
    resizable: !1
  },
  position: { width: 340, height: "auto" },
  actions: {}
}), E(Z, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/target-map.hbs" }
});
let be = Z, ne = null;
function yt() {
  return ne;
}
function P() {
  ne = null;
}
async function Mt(e) {
  var l;
  const t = te(e), n = /* @__PURE__ */ new Set();
  t && n.add(t);
  let r;
  for (const d of ((l = game.user) == null ? void 0 : l.targets) ?? []) {
    const y = te(d);
    y && (n.add(y), (y === t || !t && n.size === 1) && (r = d));
  }
  if (n.size !== 1) {
    P();
    return;
  }
  const a = [...n][0], o = t === a ? e : r, i = o == null ? void 0 : o.actor;
  if (!(i instanceof Actor)) {
    P();
    return;
  }
  if (A(i).length === 0) {
    P();
    return;
  }
  const c = await be.pick(i);
  if (!c) {
    P();
    return;
  }
  const u = A(i).find((d) => d.id === c);
  if (!u) {
    P();
    return;
  }
  ne = {
    tokenUuid: a,
    actorUuid: i.uuid,
    partId: u.id
  };
}
function Sn() {
  Hooks.on("targetToken", (e, t, n) => {
    var r;
    if (e.id === ((r = game.user) == null ? void 0 : r.id)) {
      if (!n) {
        ne && te(t) === ne.tokenUuid && P();
        return;
      }
      if (!h("promptOnTarget")) {
        P();
        return;
      }
      Mt(t);
    }
  });
}
const { ApplicationV2: bn, HandlebarsApplicationMixin: kn } = foundry.applications.api;
var ge, Tt;
const F = class F extends kn(bn) {
  constructor() {
    super(...arguments);
    U(this, ge);
  }
  static async openFor(n, r, a) {
    await new F({ actor: n, partId: r, onSaved: a }).render(!0);
  }
  get editorOptions() {
    return this.options;
  }
  get editing() {
    const { actor: n, partId: r } = this.editorOptions;
    if (r) {
      const i = A(n).find((s) => s.id === r);
      if (i) return Oe(i);
    }
    const a = Number(h("defaultAc") ?? 10), o = Number(h("defaultHp") ?? 20);
    return se("", {
      ac: Number.isFinite(a) ? a : 10,
      hp: Number.isFinite(o) ? o : 20
    });
  }
  get isNew() {
    return !this.editorOptions.partId;
  }
  async _prepareContext(n) {
    const r = await super._prepareContext(n), a = this.editing, o = this.editorOptions.actor;
    return {
      ...r,
      part: a,
      isNew: this.isNew,
      actorName: o.name,
      link: V(a),
      sever: a.sever ?? { value: a.hp.max, max: a.hp.max },
      severTypes: a.severTypes ?? ["slashing"],
      rewards: Ae(a).map((i) => ({ ...i })),
      items: [...o.items].flatMap(
        (i) => typeof i.id == "string" ? [{ id: i.id, label: `${i.name} (${i.type})` }] : []
      ),
      damageTypes: ve(),
      physicalTypes: Rt.map((i) => ({
        key: i,
        label: Nt(i),
        checked: (a.severTypes ?? ["slashing"]).includes(i)
      })),
      hitzones: ve().map((i) => {
        var s;
        return {
          key: i.key,
          label: i.label,
          value: ((s = a.hitzone) == null ? void 0 : s[i.key]) ?? 1
        };
      }),
      statuses: (CONFIG.statusEffects ?? []).filter((i) => typeof (i == null ? void 0 : i.id) == "string").map((i) => ({ value: i.id, label: i.name ?? i.id })),
      states: Object.entries(ae).map(
        ([i, s]) => ({ value: i, label: p(s) })
      )
    };
  }
  async _onRender(n, r) {
    var i;
    await super._onRender(n, r), (i = this.element.querySelector("form.monster-anatomy-form")) == null || i.addEventListener("submit", (s) => void oe(this, ge, Tt).call(this, s));
    const a = this.element.querySelector("#ma-img"), o = this.element.querySelector(".ma-imgpreview");
    a == null || a.addEventListener("input", () => Ve(a, o)), o == null || o.addEventListener("error", () => {
      o && (o.hidden = !0);
    });
  }
  static onBrowseImage(n, r) {
    const a = this, o = a.element.querySelector("#ma-img"), i = a.element.querySelector(".ma-imgpreview");
    new foundry.applications.apps.FilePicker({
      type: "image",
      current: (o == null ? void 0 : o.value) ?? "",
      callback: (c) => {
        o && (o.value = c, o.dispatchEvent(new Event("input", { bubbles: !0 }))), Ve(o, i);
      }
    }).render(!0);
  }
  static onAddReward(n, r) {
    const o = this.element.querySelector("[data-rewards]");
    if (!o) return;
    const i = document.createElement("div");
    i.className = "ma-reward", i.setAttribute("data-reward", ""), i.setAttribute("data-reward-id", foundry.utils.randomID()), i.innerHTML = `<select name="rw_event" title="${p("MONSTER_ANATOMY.Editor.RewardEvent")}"><option value="break">${p("MONSTER_ANATOMY.Reward.Break")}</option><option value="sever">${p("MONSTER_ANATOMY.Reward.Sever")}</option></select><select name="rw_kind" title="${p("MONSTER_ANATOMY.Editor.RewardKind")}"><option value="table">${p("MONSTER_ANATOMY.Reward.TableKind")}</option><option value="item">${p("MONSTER_ANATOMY.Reward.ItemKind")}</option></select><input name="rw_table" type="text" placeholder="RollTable.xxx / Item.xxx" title="${p("MONSTER_ANATOMY.Editor.RewardTable")}" /><input name="rw_draws" type="number" min="1" max="20" step="1" value="1" title="${p("MONSTER_ANATOMY.Editor.RewardDraws")}" /><button type="button" data-action="remove-reward" title="${p("MONSTER_ANATOMY.Editor.RewardRemove")}"><i class="fa-solid fa-xmark"></i></button>`, o.appendChild(i);
  }
  static onRemoveReward(n, r) {
    var a;
    (a = r.closest("[data-reward]")) == null || a.remove();
  }
};
ge = new WeakSet(), Tt = async function(n) {
  var Pe, He, Be, $e;
  n.preventDefault();
  const r = n.target, a = new FormData(r), o = (N) => String(a.get(N) ?? "").trim(), i = (N, k) => {
    const R = Number(a.get(N));
    return Number.isFinite(R) ? R : k;
  }, { actor: s, partId: c, onSaved: u } = this.editorOptions, l = c ? A(s).find((N) => N.id === c) : void 0, d = Math.max(1, Math.floor(i("hpMax", (l == null ? void 0 : l.hp.max) ?? 10))), y = o("zone"), T = y === "head" || y === "torso" || y === "left" || y === "right" || y === "tail" ? y : (l == null ? void 0 : l.zone) ?? null, M = o("effectDuration"), f = o("disableItemId"), B = {
    disableItemId: f,
    disableItemName: ((Pe = s.items.get(f)) == null ? void 0 : Pe.name) ?? "",
    effectName: o("effectName"),
    effectIcon: o("effectIcon"),
    effectDuration: M === "" ? null : Math.max(0, Math.floor(i("effectDuration", 0))),
    condition: o("condition"),
    setAttrPath: o("setAttrPath"),
    setAttrValue: o("setAttrValue"),
    macroUuid: o("macroUuid")
  }, $ = {};
  for (const { key: N } of ve()) {
    const k = a.get(`hz_${N}`);
    if (k == null) continue;
    const R = Number(k);
    !Number.isFinite(R) || R < 0 || R === 1 || !N || ($[N] = Math.round(R * 100) / 100);
  }
  const q = a.getAll("severType").filter((N) => typeof N == "string" && N !== ""), g = Math.max(
    1,
    Math.floor(i("severMax", ((He = l == null ? void 0 : l.sever) == null ? void 0 : He.max) ?? d))
  ), H = ((Be = l == null ? void 0 : l.sever) == null ? void 0 : Be.value) ?? g, G = o("bonusMode"), Te = {
    mode: G === "off" || G === "percent" || G === "flat" ? G : "inherit",
    value: Math.max(0, i("bonusValue", 0))
  }, re = [];
  r.querySelectorAll("[data-reward]").forEach((N) => {
    const k = (Ot) => {
      var Fe, Ce;
      return ((Ce = (Fe = N.querySelector(Ot)) == null ? void 0 : Fe.value) == null ? void 0 : Ce.trim()) ?? "";
    }, R = k('input[name="rw_table"]');
    if (!R) return;
    const bt = k('select[name="rw_event"]'), kt = k('select[name="rw_kind"]');
    re.push({
      id: N.dataset.rewardId || foundry.utils.randomID(),
      kind: kt === "item" ? "item" : "table",
      uuid: R,
      draws: Math.max(1, Math.min(20, Math.floor(Number(k('input[name="rw_draws"]')) || 1))),
      onEvent: bt === "sever" ? "sever" : "break"
    });
  });
  const K = {
    id: (l == null ? void 0 : l.id) ?? "",
    name: o("name"),
    img: o("img"),
    zone: T,
    ac: Math.max(0, Math.floor(i("ac", (l == null ? void 0 : l.ac) ?? 10))),
    hp: {
      max: d,
      value: Math.max(0, Math.min(d, Math.floor(i("hpValue", (l == null ? void 0 : l.hp.value) ?? d))))
    },
    breakable: a.get("breakable") === "on",
    severable: a.get("severable") === "on",
    state: o("state") || (l == null ? void 0 : l.state) || "intact",
    notes: o("notes"),
    onBreak: B,
    hitzone: $,
    sever: { value: Math.min(g, H), max: g },
    severTypes: q,
    rewards: re,
    bonus: Te
  };
  if (Ct(K).length > 0) {
    ($e = ui.notifications) == null || $e.error(p("MONSTER_ANATOMY.Editor.Invalid"));
    return;
  }
  if (l) {
    const { id: N, ...k } = K;
    await ce(s, l.id, k);
  } else {
    const N = se(K.name || p("MONSTER_ANATOMY.Part.New"), {
      ac: K.ac,
      hp: K.hp.max
    });
    await tt(s, { ...N, ...K, id: N.id });
  }
  u == null || u(), await this.close();
}, E(F, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-part-editor",
  classes: ["monster-anatomy", "monster-anatomy-editor"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Editor.Title",
    icon: "fa-solid fa-pen-to-square",
    resizable: !1
  },
  position: { width: 460, height: "auto" },
  actions: {
    "add-reward": F.onAddReward,
    "remove-reward": F.onRemoveReward,
    "browse-image": F.onBrowseImage
  }
}), E(F, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/part-editor.hbs" }
});
let me = F;
function Ve(e, t) {
  var r;
  if (!t) return;
  const n = ((r = e == null ? void 0 : e.value) == null ? void 0 : r.trim()) ?? "";
  t.hidden = n === "", n !== "" && (t.src = n);
}
function ve() {
  var t;
  const e = (t = CONFIG == null ? void 0 : CONFIG.DND5E) == null ? void 0 : t.damageTypes;
  return e && typeof e == "object" ? Object.entries(e).map(([n, r]) => ({ key: n, label: Nt(r) })) : [..._t].map((n) => ({ key: n, label: n }));
}
function Nt(e) {
  try {
    return p(e);
  } catch {
    return e;
  }
}
const { ApplicationV2: On, HandlebarsApplicationMixin: En } = foundry.applications.api;
var C;
const ee = class ee extends En(On) {
  constructor() {
    super(...arguments);
    U(this, C, null);
  }
  static async openFor(n) {
    await new ee({ actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const r = await super._prepareContext(n), a = A(this.actor).map((o) => {
      const i = o.hp.max > 0 ? o.hp.value / o.hp.max * 100 : 0;
      return {
        ...o,
        hp: { ...o.hp },
        hpPct: Math.max(0, Math.min(100, Math.round(i))),
        stateLabel: p(ae[o.state])
      };
    });
    return {
      ...r,
      actorName: this.actor.name,
      parts: a,
      empty: a.length === 0
    };
  }
  async _onRender(n, r) {
    await super._onRender(n, r), S(this, C) === null && _(this, C, Hooks.on("updateActor", (a) => {
      a.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(n) {
    return S(this, C) !== null && (Hooks.off("updateActor", S(this, C)), _(this, C, null)), super.close(n);
  }
};
C = new WeakMap(), E(ee, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-tracker",
  classes: ["monster-anatomy", "monster-anatomy-tracker"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Tracker.Title",
    icon: "fa-solid fa-heart-pulse",
    resizable: !0
  },
  position: { width: 320, height: "auto" },
  actions: {}
}), E(ee, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-tracker.hbs" }
});
let de = ee;
const { ApplicationV2: xn, HandlebarsApplicationMixin: Rn } = foundry.applications.api;
var D;
const j = class j extends Rn(xn) {
  constructor() {
    super(...arguments);
    U(this, D, null);
  }
  static async openFor(n) {
    await new j({ actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const r = await super._prepareContext(n), a = this.actor, o = A(a).map((s) => ({
      name: s.name,
      stateLabel: p(ae[s.state]),
      hp: `${s.hp.value} / ${s.hp.max}`
    })), i = ft(a).map((s) => ({
      ...s,
      eventLabel: p(
        s.event === "sever" ? "MONSTER_ANATOMY.Reward.Sever" : "MONSTER_ANATOMY.Reward.Break"
      ),
      itemsText: s.items.join(", ")
    }));
    return {
      ...r,
      actorName: a.name,
      parts: o,
      loot: i,
      emptyParts: o.length === 0,
      emptyLoot: i.length === 0,
      canClear: O(a)
    };
  }
  async _onRender(n, r) {
    await super._onRender(n, r), S(this, D) === null && _(this, D, Hooks.on("updateActor", (a) => {
      a.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(n) {
    return S(this, D) !== null && (Hooks.off("updateActor", S(this, D)), _(this, D, null)), super.close(n);
  }
  static async onClearLoot(n, r) {
    const a = this;
    O(a.actor) && await gn(a.actor);
  }
};
D = new WeakMap(), E(j, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-summary",
  classes: ["monster-anatomy", "monster-anatomy-summary"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Summary.Title",
    icon: "fa-solid fa-scroll",
    resizable: !0
  },
  position: { width: 460, height: "auto" },
  actions: {
    "clear-loot": j.onClearLoot
  }
}), E(j, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/loot-summary.hbs" }
});
let fe = j;
const { ApplicationV2: _n, HandlebarsApplicationMixin: Yn } = foundry.applications.api;
function In(e, t, n) {
  const r = e.hp.max > 0 ? e.hp.value / e.hp.max * 100 : 0, a = V(e).disableItemId.trim(), o = a ? t.items.get(a) : void 0, i = e.sever ?? { value: e.hp.max, max: e.hp.max }, s = i.max > 0 ? i.value / i.max * 100 : 0;
  return {
    ...e,
    hp: { ...e.hp },
    sever: { value: i.value, max: i.max },
    hpPct: Math.max(0, Math.min(100, Math.round(r))),
    stateLabel: p(ae[e.state]),
    hpMismatch: Ft(e) !== e.state,
    linkedItemName: (o == null ? void 0 : o.name) ?? a,
    linkedDisabled: a !== "" && z(e.state),
    severPct: Math.max(0, Math.min(100, Math.round(s))),
    acDisplay: n ? "??" : String(e.ac)
  };
}
function Ge(e) {
  const t = e.closest(".ma-part"), n = t == null ? void 0 : t.querySelector("input.ma-amount"), r = Math.floor(Number(n == null ? void 0 : n.value));
  return Number.isFinite(r) && r > 0 ? r : null;
}
var L;
const w = class w extends Yn(_n) {
  constructor() {
    super(...arguments);
    U(this, L, null);
  }
  /** Abre o painel para um Actor. */
  static async openFor(n) {
    await new w({ actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const r = await super._prepareContext(n), a = this.actor, o = W(), i = le(a), s = i && !o, c = A(a).map((u) => In(u, a, s));
    return {
      ...r,
      actorName: a.name,
      actorImg: a.img ?? "icons/svg/mystery-man.svg",
      canEdit: O(a),
      isGM: o,
      hideAc: i,
      templates: xe().map((u) => ({ id: u.id, name: Xt(u) })),
      parts: c,
      empty: c.length === 0
    };
  }
  async _onRender(n, r) {
    await super._onRender(n, r), S(this, L) === null && (_(this, L, Hooks.on("updateActor", (a) => {
      a.uuid === this.actor.uuid && this.render();
    })), X(Q.PANEL_RENDER, this));
  }
  async close(n) {
    return S(this, L) !== null && (Hooks.off("updateActor", S(this, L)), _(this, L, null)), super.close(n);
  }
  // -- actions (this = instância, injetado pelo ApplicationV2) -----------------
  static async onAddPart(n, r) {
    const a = this;
    O(a.actor) && await me.openFor(a.actor, void 0, () => void a.render());
  }
  static async onEditPart(n, r) {
    const a = this;
    if (!O(a.actor)) return;
    const o = r.dataset.partId;
    o && await me.openFor(a.actor, o, () => void a.render());
  }
  static async onOpenTracker(n, r) {
    const a = this;
    await de.openFor(a.actor);
  }
  static async onOpenSummary(n, r) {
    const a = this;
    await fe.openFor(a.actor);
  }
  static async onDamagePart(n, r) {
    const a = this;
    if (!O(a.actor)) return;
    const o = r.dataset.partId, i = Ge(r);
    !o || i === null || await pt(a.actor, o, i);
  }
  static async onHealPart(n, r) {
    const a = this;
    if (!O(a.actor)) return;
    const o = r.dataset.partId, i = Ge(r);
    !o || i === null || await ht(a.actor, o, i);
  }
  static async onDeletePart(n, r) {
    const a = this;
    if (!O(a.actor)) return;
    const o = r.dataset.partId, i = A(a.actor).find((c) => c.id === o);
    !o || !i || !await foundry.applications.api.DialogV2.confirm({
      window: { title: p("MONSTER_ANATOMY.Delete.Title") },
      content: `<p>${v("MONSTER_ANATOMY.Delete.Prompt", { name: i.name })}</p>`,
      modal: !0
    }) || await Qt(a.actor, o);
  }
  static async onApplyTemplate(n, r) {
    var s;
    const a = this;
    if (!O(a.actor)) return;
    const o = a.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (i)
      try {
        const c = await at(a.actor, i);
        (s = ui.notifications) == null || s.info(v("MONSTER_ANATOMY.Template.Applied", { count: String(c) }));
      } catch (c) {
        console.warn("monster-anatomy | falha ao aplicar modelo", c);
      }
  }
  static async onSaveTemplate(n, r) {
    var s, c;
    const a = this;
    if (!W()) return;
    const o = A(a.actor);
    if (o.length === 0) {
      (s = ui.notifications) == null || s.warn(p("MONSTER_ANATOMY.Template.Empty"));
      return;
    }
    const i = await Pn(a.actor.name);
    i && (await Zt(i, o), (c = ui.notifications) == null || c.info(v("MONSTER_ANATOMY.Template.Saved", { name: i })), a.render());
  }
  static async onDeleteTemplate(n, r) {
    var c, u;
    const a = this;
    if (!W()) return;
    const o = a.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (!i) return;
    if (!await en(i)) {
      (c = ui.notifications) == null || c.warn(p("MONSTER_ANATOMY.Template.Protected"));
      return;
    }
    (u = ui.notifications) == null || u.info(p("MONSTER_ANATOMY.Template.Deleted")), a.render();
  }
  static async onToggleHideAc(n, r) {
    const a = this;
    W() && await tn(a.actor, !le(a.actor));
  }
};
L = new WeakMap(), E(w, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-panel",
  classes: ["monster-anatomy", "monster-anatomy-panel"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Panel.Title",
    icon: "fa-solid fa-dragon",
    resizable: !0
  },
  position: { width: 500, height: "auto" },
  actions: {
    "add-part": w.onAddPart,
    "edit-part": w.onEditPart,
    "delete-part": w.onDeletePart,
    "open-tracker": w.onOpenTracker,
    "open-summary": w.onOpenSummary,
    "damage-part": w.onDamagePart,
    "heal-part": w.onHealPart,
    "apply-template": w.onApplyTemplate,
    "save-template": w.onSaveTemplate,
    "delete-template": w.onDeleteTemplate,
    "toggle-hide-ac": w.onToggleHideAc
  }
}), E(w, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-panel.hbs" }
});
let ke = w;
async function Pn(e) {
  const t = await foundry.applications.api.DialogV2.wait({
    window: { title: p("MONSTER_ANATOMY.Template.NameTitle") },
    content: `<div class="form-group"><label>${p("MONSTER_ANATOMY.Template.NamePrompt")}</label><input name="templateName" type="text" value="${e}" maxlength="80" /></div>`,
    buttons: [
      {
        action: "save",
        label: p("MONSTER_ANATOMY.Editor.Save"),
        default: !0,
        callback: (n, r) => {
          var o, i;
          const a = (o = r.form) == null ? void 0 : o.querySelector(
            'input[name="templateName"]'
          );
          return ((i = a == null ? void 0 : a.value) == null ? void 0 : i.trim()) ?? "";
        }
      }
    ],
    modal: !0
  });
  return typeof t != "string" || t.trim() === "" ? null : t.trim();
}
function Hn() {
  var t, n;
  return {
    version: ((n = (t = game.modules) == null ? void 0 : t.get(m)) == null ? void 0 : n.version) ?? "0.0.0",
    async openAnatomy(r) {
      await ke.openFor(r);
    },
    getParts(r) {
      return A(r);
    },
    canEdit(r) {
      return O(r);
    },
    damagePart(r, a, o, i) {
      return pt(r, a, o, i);
    },
    healPart(r, a, o) {
      return ht(r, a, o);
    },
    damagePartDetailed(r, a, o, i) {
      return Me(r, a, o, i);
    },
    getSelection() {
      return yt();
    },
    clearSelection() {
      P();
    },
    promptTargetSelection(r) {
      return Mt(r);
    },
    openTracker(r) {
      return de.openFor(r);
    },
    openSummary(r) {
      return fe.openFor(r);
    },
    on(r, a) {
      const o = r.startsWith("monsterAnatomy.") ? r : `monsterAnatomy.${r}`, i = ie(o, a);
      return () => Dt(o, i);
    },
    getTemplates() {
      return xe();
    },
    applyTemplate(r, a) {
      return at(r, a);
    }
  };
}
function Bn(e) {
  globalThis.MonsterAnatomy = e;
}
function Y(e) {
  return typeof e == "string" ? e : "";
}
function $n(e) {
  if (!Array.isArray(e)) return [];
  const t = [];
  for (const n of e) {
    if (!n || typeof n != "object") continue;
    const r = Math.max(0, Math.floor(Number(n.amount) || 0));
    if (r <= 0) continue;
    const a = n.type;
    t.push(typeof a == "string" && a ? { amount: r, type: a } : { amount: r });
  }
  return t;
}
function Fn() {
  var e;
  return ((e = game.users) == null ? void 0 : e.some((t) => t.isGM && t.active)) ?? !1;
}
function Cn(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function Dn() {
  var e;
  (e = game.socket) == null || e.on(`module.${m}`, (t) => {
    Ln(t);
  });
}
async function Ln(e) {
  var n, r, a;
  if (!e || typeof e != "object") return;
  const t = e;
  if (t.t === "apply") {
    if (!((n = game.user) != null && n.isGM)) return;
    const o = await fromUuid(
      Y(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = typeof t.attacker == "string" ? t.attacker : void 0, s = typeof t.attackerUuid == "string" ? t.attackerUuid : void 0, c = await Me(
      o,
      Y(t.partId),
      $n(t.components),
      { attacker: i, attackerUuid: s }
    );
    await dt(
      o,
      ((r = A(o).find((u) => u.id === Y(t.partId))) == null ? void 0 : r.name) ?? Y(t.partId),
      c.applied,
      c.globalApplied,
      c.bonus,
      c.bonusFlat
    ), c.broke && pe(Y(t.actorUuid), Y(t.partId), "break"), c.severed && pe(Y(t.actorUuid), Y(t.partId), "sever");
  } else if (t.t === "present") {
    if (typeof t.by == "string" && t.by === ((a = game.user) == null ? void 0 : a.id)) return;
    const o = await fromUuid(
      Y(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = A(o).find((s) => s.id === Y(t.partId));
    if (!i) return;
    t.kind === "sever" ? ct(o, i) : st(o, i);
  }
}
function wt(e) {
  var t;
  try {
    (t = game.socket) == null || t.emit(`module.${m}`, e);
  } catch (n) {
    console.warn("monster-anatomy | falha no socket", n);
  }
}
function qn(e, t, n, r, a) {
  var i;
  const o = { t: "apply", actorUuid: e, partId: t, components: n, attacker: r, attackerUuid: a, by: (i = game.user) == null ? void 0 : i.id };
  wt(o);
}
function pe(e, t, n = "break") {
  var a;
  const r = { t: "present", actorUuid: e, partId: t, kind: n, by: (a = game.user) == null ? void 0 : a.id };
  wt(r);
}
let he = null;
function Un() {
  ie("dnd5e.rollAttackV2", (...e) => void Vn(e)), ie("dnd5e.rollDamageV2", (...e) => void Gn(e)), ie("dnd5e.preUseActivity", (...e) => zn(e)), Hooks.on("targetToken", (e, t, n) => {
    var r;
    e.id === ((r = game.user) == null ? void 0 : r.id) && (he = null);
  });
}
function zn(e) {
  var i;
  const [t] = e, n = t == null ? void 0 : t.item, r = t == null ? void 0 : t.actor, a = r instanceof Actor ? r : (n == null ? void 0 : n.parent) instanceof Actor ? n.parent : void 0;
  if (!a || typeof (n == null ? void 0 : n.id) != "string" || !Lt(a).has(n.id)) return;
  const o = qt(a, n.id);
  return (i = ui.notifications) == null || i.warn(
    v("MONSTER_ANATOMY.Usage.Blocked", {
      item: typeof n.name == "string" ? n.name : n.id,
      part: (o == null ? void 0 : o.name) ?? "",
      actor: a.name
    })
  ), !1;
}
async function Vn(e) {
  var $, q;
  const t = yt();
  if (!t) return;
  const n = [...(($ = game.user) == null ? void 0 : $.targets) ?? []], r = n.length === 1 ? n[0] : void 0, a = te(r), o = r == null ? void 0 : r.actor;
  if (!r || !a || !o || a !== t.tokenUuid || o.uuid !== t.actorUuid) {
    P();
    return;
  }
  const [i, s] = e, c = i == null ? void 0 : i[0], u = Number((c == null ? void 0 : c.total) ?? NaN);
  if (!Number.isFinite(u)) return;
  const l = jn(c), d = l === 20, y = l === 1, T = A(o).find((g) => g.id === t.partId);
  if (!T) {
    P();
    return;
  }
  const M = d || !y && u >= T.ac, f = Jn(s == null ? void 0 : s.subject), B = (f == null ? void 0 : f.name) ?? ((q = game.user) == null ? void 0 : q.name) ?? "?";
  if (he = {
    tokenUuid: a,
    actorUuid: o.uuid,
    partId: T.id,
    hit: M,
    crit: d,
    attacker: B,
    attackerUuid: f == null ? void 0 : f.uuid
  }, h("attackNotes")) {
    const g = M ? "MONSTER_ANATOMY.Attack.Hit" : "MONSTER_ANATOMY.Attack.Miss", H = d && M ? ` ${p("MONSTER_ANATOMY.Attack.CritSuffix")}` : "", G = le(o) ? "??" : String(T.ac), Te = `<div class="monster-anatomy-chat ma-attack"><p>${v(g, {
      attacker: B,
      part: T.name,
      actor: o.name,
      total: String(u),
      ac: G
    })}${H}</p></div>`, re = f ? ChatMessage.getSpeaker({ actor: f }) : ChatMessage.getSpeaker({ alias: B });
    await ChatMessage.create({ speaker: re, content: Te });
  }
}
async function Gn(e) {
  var s, c, u, l;
  const t = he;
  if (he = null, !(t != null && t.hit)) return;
  const [n] = e, r = (n ?? []).map((d) => ({ amount: Number(d == null ? void 0 : d.total) || 0, type: Kn(d) })).filter((d) => d.amount > 0);
  if (r.length === 0) return;
  const a = [...((s = game.user) == null ? void 0 : s.targets) ?? []].find((d) => te(d) === t.tokenUuid), o = a == null ? void 0 : a.actor;
  if (!o || o.uuid !== t.actorUuid) return;
  const i = ((c = A(o).find((d) => d.id === t.partId)) == null ? void 0 : c.name) ?? t.partId;
  if (Cn(o)) {
    const d = await Me(o, t.partId, r, {
      attacker: t.attacker,
      attackerUuid: t.attackerUuid
    });
    await dt(o, i, d.applied, d.globalApplied, d.bonus, d.bonusFlat), d.broke && pe(o.uuid, t.partId, "break"), d.severed && pe(o.uuid, t.partId, "sever");
  } else Fn() ? (qn(o.uuid, t.partId, r, t.attacker, t.attackerUuid), (u = ui.notifications) == null || u.info(v("MONSTER_ANATOMY.Target.SentToGM", { part: i }))) : (l = ui.notifications) == null || l.warn(p("MONSTER_ANATOMY.Target.NoGM"));
}
function Kn(e) {
  var r, a;
  const t = e;
  if (typeof ((r = t.options) == null ? void 0 : r.type) == "string" && t.options.type) return t.options.type;
  const n = (a = t.options) == null ? void 0 : a.types;
  if (Array.isArray(n) && typeof n[0] == "string" && n[0]) return n[0];
}
function jn(e) {
  var n;
  const t = e == null ? void 0 : e.dice;
  if (Array.isArray(t))
    for (const r of t) {
      if ((r == null ? void 0 : r.faces) !== 20) continue;
      const a = r == null ? void 0 : r.results;
      if (!Array.isArray(a)) continue;
      const o = (n = a[0]) == null ? void 0 : n.result;
      if (typeof o == "number") return o;
    }
}
function Jn(e) {
  const t = e == null ? void 0 : e.actor;
  return t instanceof Actor ? t : void 0;
}
function Wn() {
  Sn(), Un();
}
function Qn() {
  game.settings.register(m, "showHeaderButton", {
    name: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "defaultAc", {
    name: "MONSTER_ANATOMY.Settings.DefaultAc.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultAc.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 10
  }), game.settings.register(m, "defaultHp", {
    name: "MONSTER_ANATOMY.Settings.DefaultHp.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultHp.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 20
  }), game.settings.register(m, "damageModel", {
    name: "MONSTER_ANATOMY.Settings.DamageModel.Name",
    hint: "MONSTER_ANATOMY.Settings.DamageModel.Hint",
    scope: "world",
    config: !0,
    type: String,
    choices: {
      independent: "MONSTER_ANATOMY.Settings.DamageModel.Independent",
      shared: "MONSTER_ANATOMY.Settings.DamageModel.Shared",
      percent: "MONSTER_ANATOMY.Settings.DamageModel.Percent"
    },
    default: "shared"
  }), game.settings.register(m, "damagePercent", {
    name: "MONSTER_ANATOMY.Settings.DamagePercent.Name",
    hint: "MONSTER_ANATOMY.Settings.DamagePercent.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 100, step: 5 },
    default: 50
  }), game.settings.register(m, "brokenBonus", {
    name: "MONSTER_ANATOMY.Settings.BrokenBonus.Name",
    hint: "MONSTER_ANATOMY.Settings.BrokenBonus.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 200, step: 5 },
    default: 50
  }), game.settings.register(m, "showAnnouncement", {
    name: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "announceDuration", {
    name: "MONSTER_ANATOMY.Settings.AnnounceDuration.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceDuration.Hint",
    scope: "client",
    config: !0,
    type: Number,
    range: { min: 0.5, max: 10, step: 0.5 },
    default: 2.5
  }), game.settings.register(m, "chatMessage", {
    name: "MONSTER_ANATOMY.Settings.ChatMessage.Name",
    hint: "MONSTER_ANATOMY.Settings.ChatMessage.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "tokenEffect", {
    name: "MONSTER_ANATOMY.Settings.TokenEffect.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenEffect.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "breakSound", {
    name: "MONSTER_ANATOMY.Settings.BreakSound.Name",
    hint: "MONSTER_ANATOMY.Settings.BreakSound.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "promptOnTarget", {
    name: "MONSTER_ANATOMY.Settings.PromptOnTarget.Name",
    hint: "MONSTER_ANATOMY.Settings.PromptOnTarget.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "attackNotes", {
    name: "MONSTER_ANATOMY.Settings.AttackNotes.Name",
    hint: "MONSTER_ANATOMY.Settings.AttackNotes.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "announceTheme", {
    name: "MONSTER_ANATOMY.Settings.AnnounceTheme.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceTheme.Hint",
    scope: "client",
    config: !0,
    type: String,
    choices: {
      persona: "MONSTER_ANATOMY.Settings.AnnounceTheme.Persona",
      monsterhunter: "MONSTER_ANATOMY.Settings.AnnounceTheme.MonsterHunter",
      jrpg: "MONSTER_ANATOMY.Settings.AnnounceTheme.Jrpg",
      minimal: "MONSTER_ANATOMY.Settings.AnnounceTheme.Minimal",
      impact: "MONSTER_ANATOMY.Settings.AnnounceTheme.Impact",
      arcade: "MONSTER_ANATOMY.Settings.AnnounceTheme.Arcade",
      carved: "MONSTER_ANATOMY.Settings.AnnounceTheme.Carved"
    },
    default: "persona"
  }), game.settings.register(m, "customKickerBreak", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "customKickerSever", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerSever.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerSever.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "tokenShake", {
    name: "MONSTER_ANATOMY.Settings.TokenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "screenFlash", {
    name: "MONSTER_ANATOMY.Settings.ScreenFlash.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenFlash.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "reducedMotion", {
    name: "MONSTER_ANATOMY.Settings.ReducedMotion.Name",
    hint: "MONSTER_ANATOMY.Settings.ReducedMotion.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !1
  }), game.settings.register(m, "particles", {
    name: "MONSTER_ANATOMY.Settings.Particles.Name",
    hint: "MONSTER_ANATOMY.Settings.Particles.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "screenShake", {
    name: "MONSTER_ANATOMY.Settings.ScreenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "templatesJson", {
    name: "MONSTER_ANATOMY.Settings.TemplatesJson.Name",
    hint: "MONSTER_ANATOMY.Settings.TemplatesJson.Hint",
    scope: "world",
    config: !1,
    type: String,
    default: "[]"
  });
}
function vt(e) {
  const t = e == null ? void 0 : e.document;
  return t instanceof Actor ? t : void 0;
}
function St() {
  try {
    return h("showHeaderButton");
  } catch {
    return !0;
  }
}
function Ke(e, t) {
  const n = vt(e);
  !n || !Array.isArray(t) || !St() || t.some((r) => (r == null ? void 0 : r.action) === "monster-anatomy") || t.unshift({
    action: "monster-anatomy",
    label: "MONSTER_ANATOMY.Panel.OpenButton",
    icon: "fa-solid fa-dragon",
    onClick: () => {
      var r;
      (r = Xe()) == null || r.openAnatomy(n);
    }
  });
}
function Xn() {
  Hooks.on("getHeaderControlsActorSheetV2", (...e) => {
    Ke(e[0], e[1]);
  }), Hooks.on("getHeaderControlsApplicationV2", (...e) => {
    Ke(e[0], e[1]);
  }), Hooks.on("getActorSheetHeaderButtons", (...e) => {
    const [t, n] = e, r = vt(t) ?? (t == null ? void 0 : t.actor);
    if (!(r instanceof Actor) || !Array.isArray(n) || !St()) return;
    const a = r;
    n.unshift({
      class: "monster-anatomy-open",
      icon: "fas fa-dragon",
      label: "MONSTER_ANATOMY.Panel.OpenButton",
      onclick: () => {
        var o;
        (o = Xe()) == null || o.openAnatomy(a);
      }
    });
  });
}
async function Zn() {
  await foundry.applications.handlebars.loadTemplates([
    "modules/monster-anatomy/templates/anatomy-panel.hbs",
    "modules/monster-anatomy/templates/anatomy-tracker.hbs",
    "modules/monster-anatomy/templates/loot-summary.hbs",
    "modules/monster-anatomy/templates/part-editor.hbs",
    "modules/monster-anatomy/templates/target-map.hbs"
  ]);
}
function Se(e, t) {
  try {
    t();
  } catch (n) {
    console.error(`${m} | falha no init (${e})`, n);
  }
}
Hooks.once("init", () => {
  var n;
  console.log(`${m} | init`), Se("settings", Qn), Se("header", Xn), Se("combat", Wn);
  const e = Hn(), t = (n = game.modules) == null ? void 0 : n.get(m);
  t && (t.api = e), Bn(e), Zn();
});
Hooks.once("setup", () => {
  console.log(`${m} | setup`);
});
Hooks.once("ready", () => {
  var e, t;
  console.log(`${m} | ready (v${((t = (e = game.modules) == null ? void 0 : e.get(m)) == null ? void 0 : t.version) ?? "?"})`), Dn();
});
//# sourceMappingURL=main.js.map
