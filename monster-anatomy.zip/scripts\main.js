var oe = Object.defineProperty;
var St = (t) => {
  throw TypeError(t);
};
var ie = (t, e, n) => e in t ? oe(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var _ = (t, e, n) => ie(t, typeof e != "symbol" ? e + "" : e, n), ct = (t, e, n) => e.has(t) || St("Cannot " + n);
var E = (t, e, n) => (ct(t, e, "read from private field"), n ? n.call(t) : e.get(t)), z = (t, e, n) => e.has(t) ? St("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, n), F = (t, e, n, a) => (ct(t, e, "write to private field"), a ? a.call(t, n) : e.set(t, n), n), Ot = (t, e, n) => (ct(t, e, "access private method"), n);
const d = "monster-anatomy", Yt = d, Pt = "parts", V = {
  /** Disparado quando o painel de anatomia termina de renderizar. */
  PANEL_RENDER: "monsterAnatomy.panelRender",
  /** Disparado após criar/atualizar/remover uma parte. */
  PARTS_CHANGED: "monsterAnatomy.partsChanged",
  /** Disparado após aplicar dano a uma parte (sempre, mesmo sem quebra). */
  PART_DAMAGE: "monsterAnatomy.partDamage",
  /** Disparado na transição para quebrado (uma vez por transição). */
  PART_BREAK: "monsterAnatomy.partBreak",
  /** Disparado na transição para cortado (uma vez por transição). */
  PART_SEVER: "monsterAnatomy.partSever"
};
function ft(t) {
  if (!Array.isArray(t.rewards)) return [];
  const e = [];
  for (const n of t.rewards) {
    if (!n || typeof n != "object") continue;
    const a = n, r = typeof a.uuid == "string" && a.uuid.trim() !== "" ? a.uuid.trim() : typeof a.tableUuid == "string" ? a.tableUuid.trim() : "";
    r !== "" && e.push({
      id: typeof a.id == "string" && a.id !== "" ? a.id : foundry.utils.randomID(),
      kind: a.kind === "item" ? "item" : "table",
      uuid: r,
      draws: Math.max(1, Math.min(20, Math.floor(Number(a.draws) || 1))),
      onEvent: a.onEvent === "sever" ? "sever" : "break"
    });
  }
  return e;
}
const se = ["slashing", "piercing", "bludgeoning"], ce = [
  "slashing",
  "piercing",
  "bludgeoning",
  "fire",
  "cold",
  "lightning",
  "thunder",
  "acid",
  "poison",
  "psychic",
  "necrotic",
  "radiant",
  "force"
];
function ue(t, e) {
  var a;
  if (!e) return 1;
  const n = (a = t.hitzone) == null ? void 0 : a[e];
  return typeof n == "number" && Number.isFinite(n) && n >= 0 ? n : 1;
}
function de(t) {
  return t.severable && (t.severTypes ?? []).length > 0;
}
function B(t) {
  return t === "broken" || t === "severed";
}
const Ht = {
  disableItemId: "",
  effectName: "",
  effectIcon: "",
  effectDuration: null,
  condition: "",
  setAttrPath: "",
  setAttrValue: "",
  macroUuid: ""
};
function U(t) {
  return { ...Ht, ...t.onBreak ?? {} };
}
const W = {
  intact: "MONSTER_ANATOMY.State.Intact",
  damaged: "MONSTER_ANATOMY.State.Damaged",
  broken: "MONSTER_ANATOMY.State.Broken",
  severed: "MONSTER_ANATOMY.State.Severed",
  destroyed: "MONSTER_ANATOMY.State.Destroyed"
};
let vt = 0;
function le() {
  vt += 1;
  const t = Math.random().toString(36).slice(2, 8);
  return `part-${Date.now().toString(36)}-${t}-${vt}`;
}
function kt(t, e) {
  const n = Math.max(1, Math.floor(e.hp));
  return {
    id: le(),
    name: t.trim(),
    ac: Math.max(0, Math.floor(e.ac)),
    hp: { value: n, max: n },
    breakable: !0,
    severable: !1,
    state: "intact",
    notes: "",
    onBreak: { ...Ht },
    hitzone: {},
    sever: { value: n, max: n },
    severTypes: ["slashing"]
  };
}
function me(t) {
  return t.hp.value <= 0 && t.breakable ? "broken" : t.hp.value < t.hp.max ? "damaged" : "intact";
}
function fe(t) {
  var n;
  const e = [];
  return (n = t.name) != null && n.trim() || e.push("name"), (t.ac === void 0 || !Number.isFinite(t.ac) || t.ac < 0) && e.push("ac"), (t.hp === void 0 || !Number.isFinite(t.hp.max) || t.hp.max < 1) && e.push("hp.max"), t.hp !== void 0 && (!Number.isFinite(t.hp.value) || t.hp.value < 0) && e.push("hp.value"), e;
}
function pt(t) {
  return {
    ...t,
    hp: { ...t.hp },
    onBreak: U(t),
    hitzone: { ...t.hitzone ?? {} },
    sever: t.sever ? { ...t.sever } : { value: t.hp.max, max: t.hp.max },
    severTypes: [...t.severTypes ?? ["slashing"]],
    rewards: ft(t).map((e) => ({ ...e }))
  };
}
function h(t) {
  var e;
  return ((e = game.i18n) == null ? void 0 : e.localize(t)) ?? t;
}
function w(t, e) {
  var n;
  return ((n = game.i18n) == null ? void 0 : n.format(t, e)) ?? t;
}
function A(t) {
  return game.settings.get(d, t);
}
function K(t) {
  if (!t || typeof t != "object") return;
  const e = t;
  if (typeof e.uuid == "string" && e.uuid) return e.uuid;
  if (e.document && typeof e.document == "object") {
    const n = e.document.uuid;
    if (typeof n == "string" && n) return n;
  }
}
function It() {
  var t, e;
  return (e = (t = game.modules) == null ? void 0 : t.get(d)) == null ? void 0 : e.api;
}
function G(t, ...e) {
  Hooks.callAll.call(Hooks, t, ...e);
}
function Z(t, e) {
  return Hooks.on.call(Hooks, t, e);
}
function pe(t, e) {
  Hooks.off.call(Hooks, t, e);
}
const ht = "attrBackup";
function he(t) {
  const e = /* @__PURE__ */ new Set();
  for (const n of $t(t)) {
    if (!B(n.state)) continue;
    const a = U(n).disableItemId.trim();
    a && e.add(a);
  }
  return e;
}
function ge(t, e) {
  return $t(t).find(
    (n) => B(n.state) && U(n).disableItemId.trim() === e
  );
}
function $t(t) {
  const e = t.getFlag(d, "parts");
  return Array.isArray(e) ? e : [];
}
async function Ae(t, e) {
  const n = U(e);
  n.effectName.trim() && await ye(t, e, n.effectName.trim(), n), n.condition.trim() && await Me(t, e, n.condition.trim()), n.setAttrPath.trim() && await Te(t, e, n), n.macroUuid.trim() && await we(n.macroUuid.trim());
}
async function bt(t, e) {
  for (const n of [...t.effects])
    try {
      if (n.getFlag(d, "partId") !== e.id) continue;
      const a = n.getFlag(d, "kind");
      (a === "break-effect" || a === "break-condition" || a === "part-broken" || a === "part-severed") && await n.delete();
    } catch (a) {
      console.warn("monster-anatomy | falha ao remover efeito da parte", a);
    }
  await Ne(t, e.id);
}
async function ye(t, e, n, a) {
  if (t.effects.some((i) => {
    try {
      return i.getFlag(d, "partId") === e.id && i.getFlag(d, "kind") === "break-effect";
    } catch {
      return !1;
    }
  })) return;
  const o = {};
  o[d] = { partId: e.id, kind: "break-effect" }, await ActiveEffect.create(
    {
      name: n,
      img: a.effectIcon.trim() || "icons/svg/skull.svg",
      origin: t.uuid,
      disabled: !1,
      duration: typeof a.effectDuration == "number" ? { rounds: a.effectDuration } : void 0,
      flags: o
    },
    { parent: t }
  );
}
async function Me(t, e, n) {
  if (t.effects.some((i) => {
    try {
      return i.getFlag(d, "partId") === e.id && i.getFlag(d, "kind") === "break-condition";
    } catch {
      return !1;
    }
  })) return;
  const r = CONFIG.statusEffects.find(
    (i) => (i == null ? void 0 : i.id) === n
  ), o = {};
  o[d] = { partId: e.id, kind: "break-condition" }, await ActiveEffect.create(
    {
      name: w("MONSTER_ANATOMY.Effect.ConditionName", {
        status: (r == null ? void 0 : r.name) ?? n,
        part: e.name
      }),
      img: (r == null ? void 0 : r.img) || "icons/svg/skull.svg",
      origin: t.uuid,
      disabled: !1,
      statuses: [n],
      flags: o
    },
    { parent: t }
  );
}
async function Te(t, e, n) {
  const a = n.setAttrPath.trim(), r = Ft(t);
  e.id in r || (r[e.id] = { [a]: foundry.utils.getProperty(t, a) }, await t.setFlag(d, ht, r)), await t.update({
    [a]: Se(n.setAttrValue)
  });
}
async function Ne(t, e) {
  const n = Ft(t), a = n[e];
  if (!a) return;
  const r = {};
  for (const [o, i] of Object.entries(a)) r[o] = i;
  delete n[e];
  try {
    await t.update(r);
  } catch (o) {
    console.warn("monster-anatomy | falha ao restaurar atributo", o);
  }
  await t.setFlag(d, ht, n);
}
function Ft(t) {
  try {
    const e = t.getFlag(d, ht);
    if (e && typeof e == "object" && !Array.isArray(e))
      return JSON.parse(JSON.stringify(e));
  } catch {
  }
  return {};
}
async function we(t) {
  try {
    const n = await fromUuid(t);
    typeof (n == null ? void 0 : n.execute) == "function" ? await n.execute() : console.warn(`monster-anatomy | macro não encontrada (${t})`);
  } catch (e) {
    console.warn(`monster-anatomy | falha ao executar macro (${t})`, e);
  }
}
function Se(t) {
  const e = t.trim();
  return e === "true" ? !0 : e === "false" ? !1 : e !== "" && Number.isFinite(Number(e)) ? Number(e) : t;
}
function y(t) {
  const e = t.getFlag(Yt, Pt);
  return Array.isArray(e) ? e.map((n) => ({ ...n, hp: { ...n.hp } })) : [];
}
async function gt(t, e) {
  var a;
  if (!t.isOwner)
    throw (a = ui.notifications) == null || a.warn(h("MONSTER_ANATOMY.Errors.NoPermission")), new Error("monster-anatomy: actor não editável pelo usuário atual");
  const n = y(t);
  await t.setFlag(Yt, Pt, e.map(pt)), await Oe(t, n, e), G(V.PARTS_CHANGED, t, y(t));
}
async function Oe(t, e, n) {
  var o;
  const a = new Map(e.map((i) => [i.id, i])), r = new Set(n.map((i) => i.id));
  for (const i of n) {
    const s = B(((o = a.get(i.id)) == null ? void 0 : o.state) ?? "intact"), l = B(i.state);
    if (l !== s)
      try {
        l ? await Ae(t, i) : await bt(t, i);
      } catch (f) {
        console.warn("monster-anatomy | falha na vinculação de ruptura", f);
      }
  }
  for (const i of e)
    if (!(r.has(i.id) || !B(i.state)))
      try {
        await bt(t, i);
      } catch (s) {
        console.warn("monster-anatomy | falha na limpeza de ruptura", s);
      }
}
async function ve(t, e) {
  const n = y(t);
  if (n.some((a) => a.id === e.id))
    throw new Error(`monster-anatomy: id de parte duplicado (${e.id})`);
  n.push(pt(e)), await gt(t, n);
}
async function tt(t, e, n) {
  const a = y(t), r = a.findIndex((i) => i.id === e);
  if (r < 0) throw new Error(`monster-anatomy: parte não encontrada (${e})`);
  const o = a[r];
  a[r] = {
    ...o,
    ...n,
    id: o.id,
    // id é imutável (§5.1 do design)
    hp: { ...o.hp, ...n.hp ?? {} }
  }, await gt(t, a);
}
async function ke(t, e) {
  const n = y(t).filter((a) => a.id !== e);
  await gt(t, n);
}
function x(t) {
  var e;
  return ((e = game.user) == null ? void 0 : e.isGM) === !0 || t.isOwner;
}
function At() {
  var t;
  try {
    if (A("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((t = window.matchMedia) == null ? void 0 : t.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function be(t) {
  if (At()) return;
  const e = t.textContent ?? "";
  if (e.length === 0 || e.length > 24) return;
  t.textContent = "";
  let n = 0;
  for (const a of Array.from(e)) {
    if (a === " ") {
      t.appendChild(document.createTextNode(" "));
      continue;
    }
    const r = document.createElement("span");
    r.className = "ma-letter", r.textContent = a, r.style.setProperty("--i", String(n)), t.appendChild(r), n++;
  }
}
function Dt(t) {
  try {
    if (A("particles") !== !0 || At() || document.hidden) return;
  } catch {
    return;
  }
  const e = document.createElement("canvas");
  e.className = "monster-anatomy-particles";
  const n = Math.min(2, window.devicePixelRatio || 1);
  e.width = Math.floor(window.innerWidth * n), e.height = Math.floor(window.innerHeight * n), document.body.appendChild(e);
  const a = e.getContext("2d");
  if (!a) {
    e.remove();
    return;
  }
  a.scale(n, n);
  const r = window.innerWidth / 2, o = window.innerHeight / 2 - window.innerHeight * 0.06, i = t ? ["#9adcff", "#e8f7ff", "#4da6d8", "#0e4d64", "#ffffff"] : ["#ff3b3b", "#ffb454", "#fff3d6", "#7a1a00", "#1a1a1a"], s = [], l = 90;
  for (let N = 0; N < l; N++) {
    const p = Math.random() * Math.PI * 2, M = 180 + Math.random() * 560, m = 0.7 + Math.random() * 0.6;
    s.push({
      x: r + (Math.random() - 0.5) * 60,
      y: o + (Math.random() - 0.5) * 30,
      vx: Math.cos(p) * M,
      vy: Math.sin(p) * M - 160,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 14,
      size: 3 + Math.random() * 8,
      life: m,
      maxLife: m,
      color: i[Math.floor(Math.random() * i.length)],
      circle: Math.random() < 0.3
    });
  }
  const f = 900;
  let c = performance.now();
  const u = (N) => {
    const p = Math.min(0.05, (N - c) / 1e3);
    c = N, a.clearRect(0, 0, window.innerWidth, window.innerHeight);
    let M = !1;
    for (const m of s)
      m.life -= p, !(m.life <= 0) && (M = !0, m.vy += f * p, m.x += m.vx * p, m.y += m.vy * p, m.rot += m.vr * p, a.save(), a.globalAlpha = Math.max(0, m.life / m.maxLife), a.translate(m.x, m.y), a.rotate(m.rot), a.fillStyle = m.color, m.circle ? (a.beginPath(), a.arc(0, 0, m.size / 2, 0, Math.PI * 2), a.fill()) : a.fillRect(-m.size / 2, -m.size / 4, m.size, m.size / 2), a.restore());
    M ? requestAnimationFrame(u) : e.remove();
  };
  requestAnimationFrame(u);
}
function Ct() {
  try {
    if (A("screenShake") !== !0 || At()) return;
  } catch {
    return;
  }
  const t = document.getElementById("board");
  if (!t) return;
  const e = 11, n = 380, a = performance.now(), r = (o) => {
    const i = o - a;
    if (i >= n) {
      t.style.transform = "";
      return;
    }
    const s = 1 - i / n, l = Math.sin(o / 17) * e * s, f = Math.cos(o / 23) * e * 0.7 * s;
    t.style.transform = `translate(${l.toFixed(1)}px, ${f.toFixed(1)}px)`, requestAnimationFrame(r);
  };
  requestAnimationFrame(r);
}
async function Ee(t, e, n) {
  A("showAnnouncement") && Ut(t, e), A("chatMessage") && await Pe(t, e, n), A("tokenEffect") && await Ie(t, e), await Bt();
}
async function Re(t, e, n) {
  A("showAnnouncement") && Lt(t, e), A("chatMessage") && await He(t, e, n), A("tokenEffect") && await $e(t, e), await Bt();
}
async function Bt() {
  const t = String(A("breakSound") ?? "").trim();
  if (t)
    try {
      await foundry.audio.AudioHelper.play({ src: t, volume: 0.8 });
    } catch (e) {
      console.warn(`monster-anatomy | falha ao tocar som (${t})`, e);
    }
}
function Y(t) {
  return t.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function Ut(t, e) {
  const n = Math.max(0.5, Math.min(10, Number(A("announceDuration") ?? 2.5)));
  zt(t, e, n, !1), Vt(!1), Gt(t), Dt(!1), Ct();
}
function Lt(t, e) {
  const n = Math.max(0.5, Math.min(10, Number(A("announceDuration") ?? 2.5)));
  zt(t, e, n, !0), Vt(!0), Gt(t), Dt(!0), Ct();
}
function yt() {
  var t;
  try {
    if (A("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((t = window.matchMedia) == null ? void 0 : t.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function _e() {
  const t = String(A("announceTheme") ?? "persona");
  return t === "monsterhunter" || t === "jrpg" || t === "minimal" || t === "impact" || t === "arcade" || t === "carved" ? t : "persona";
}
function xe(t) {
  const e = String(
    A(t ? "customKickerSever" : "customKickerBreak") ?? ""
  ).trim();
  return e !== "" ? e : h(t ? "MONSTER_ANATOMY.Announce.Severed" : "MONSTER_ANATOMY.Announce.Break");
}
function zt(t, e, n, a) {
  document.querySelectorAll(".monster-anatomy-announce").forEach((s) => s.remove());
  const r = document.createElement("div");
  r.className = `monster-anatomy-announce theme-${_e()}` + (a ? " is-sever" : ""), r.style.setProperty("--ma-duration", `${n}s`), yt() && r.classList.add("is-reduced");
  const o = xe(a);
  r.innerHTML = `<div class="ma-announce-kicker">${Y(o)}</div><div class="ma-announce-part">${Y(e.name)}</div><div class="ma-announce-actor">${Y(t.name)}</div>`, document.body.appendChild(r);
  const i = r.querySelector(".ma-announce-kicker");
  i && be(i), requestAnimationFrame(() => r.classList.add("is-showing")), window.setTimeout(() => {
    r.classList.remove("is-showing"), window.setTimeout(() => r.remove(), 450);
  }, Math.max(400, Math.round(n * 1e3)));
}
function Vt(t) {
  try {
    if (A("screenFlash") !== !0 || yt()) return;
  } catch {
    return;
  }
  const e = document.createElement("div");
  e.className = "monster-anatomy-flash" + (t ? " is-sever" : ""), document.body.appendChild(e), requestAnimationFrame(() => e.classList.add("is-showing")), window.setTimeout(() => e.classList.remove("is-showing"), 120), window.setTimeout(() => e.remove(), 450);
}
function Gt(t) {
  try {
    if (A("tokenShake") !== !0 || yt()) return;
  } catch {
    return;
  }
  try {
    const e = t.getActiveTokens();
    for (const n of e) {
      const a = n == null ? void 0 : n.mesh;
      Ye(a);
    }
  } catch {
  }
}
function Ye(t) {
  const e = t == null ? void 0 : t.position;
  if (!e || typeof e.x != "number" || typeof e.y != "number") return;
  const n = e.x, a = e.y, r = 9, o = 420, i = performance.now(), s = typeof e.set == "function" ? e.set.bind(e) : null, l = (c, u) => {
    s ? s(c, u) : (e.x = c, e.y = u);
  }, f = (c) => {
    const u = c - i;
    if (u >= o) {
      l(n, a);
      return;
    }
    const N = 1 - u / o;
    l(n + Math.sin(c / 16) * r * N, a), requestAnimationFrame(f);
  };
  requestAnimationFrame(f);
}
async function Pe(t, e, n) {
  const a = n.attacker ? `<p class="ma-chat-attacker">${Y(
    w("MONSTER_ANATOMY.Chat.BreakBy", {
      attacker: n.attacker,
      part: e.name,
      actor: t.name
    })
  )}</p>` : "", r = `<div class="monster-anatomy-chat ma-break"><h3>💥 ${Y(h("MONSTER_ANATOMY.Announce.Break"))}</h3><p>${Y(
    w("MONSTER_ANATOMY.Chat.BreakText", {
      part: e.name,
      actor: t.name,
      amount: String(n.amount)
    })
  )}</p>${a}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: t }),
    content: r
  });
}
async function He(t, e, n) {
  const a = n.attacker ? `<p class="ma-chat-attacker">${Y(
    w("MONSTER_ANATOMY.Chat.SeverBy", {
      attacker: n.attacker,
      part: e.name,
      actor: t.name
    })
  )}</p>` : "", r = `<div class="monster-anatomy-chat ma-break ma-sever"><h3>🗡️ ${Y(h("MONSTER_ANATOMY.Announce.Severed"))}</h3><p>${Y(
    w("MONSTER_ANATOMY.Chat.SeverText", {
      part: e.name,
      actor: t.name,
      amount: String(n.amount)
    })
  )}</p>${a}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: t }),
    content: r
  });
}
async function Ie(t, e) {
  if (t.effects.some((r) => {
    try {
      return r.getFlag(d, "partId") === e.id;
    } catch {
      return !1;
    }
  })) return;
  const a = {};
  a[d] = { partId: e.id, kind: "part-broken" }, await ActiveEffect.create(
    {
      name: w("MONSTER_ANATOMY.Effect.BrokenName", { part: e.name }),
      img: "icons/svg/skull.svg",
      origin: t.uuid,
      disabled: !1,
      flags: a
    },
    { parent: t }
  );
}
async function $e(t, e) {
  if (t.effects.some((r) => {
    try {
      return r.getFlag(d, "partId") === e.id && r.getFlag(d, "kind") === "part-severed";
    } catch {
      return !1;
    }
  })) return;
  const a = {};
  a[d] = { partId: e.id, kind: "part-severed" }, await ActiveEffect.create(
    {
      name: w("MONSTER_ANATOMY.Effect.SeveredName", { part: e.name }),
      img: "systems/dnd5e/icons/svg/damage/slashing.svg",
      origin: t.uuid,
      disabled: !1,
      flags: a
    },
    { parent: t }
  );
}
const Mt = "loot", Fe = 20;
async function Et(t, e, n, a = {}) {
  const r = ft(e).filter((l) => l.onEvent === n);
  if (r.length === 0) return;
  const o = await De(t, a.attackerUuid), i = [];
  let s;
  for (const l of r) {
    if (l.kind === "item") {
      const c = await Ce(t, o, l.uuid, l.draws);
      c && (i.push(l.draws > 1 ? `${c} ×${l.draws}` : c), o && (s = o.name));
      continue;
    }
    const f = await Le(l.uuid);
    if (!f) {
      console.warn(`monster-anatomy | tabela não encontrada (${l.uuid})`);
      continue;
    }
    for (let c = 0; c < Math.min(Math.floor(l.draws), Fe); c++)
      try {
        const u = await f.draw({ displayChat: !1 });
        for (const N of u.results ?? []) {
          const p = ze(N);
          p && i.push(p);
        }
      } catch (u) {
        console.warn("monster-anatomy | falha no sorteio", u);
        break;
      }
  }
  i.length !== 0 && (await Ue(t, {
    partId: e.id,
    partName: e.name,
    event: n,
    items: i,
    ...s ? { grantedTo: s } : {},
    at: Date.now()
  }), A("chatMessage") && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: t }),
    content: `<div class="monster-anatomy-chat ma-loot"><h3>🎁 ${Rt(h("MONSTER_ANATOMY.Loot.Title"))}</h3><p>${Rt(
      w("MONSTER_ANATOMY.Loot.Text", {
        part: e.name,
        actor: t.name,
        items: i.join(", ")
      })
    )}</p></div>`
  }));
}
async function De(t, e) {
  const n = e && e !== t.uuid ? e : void 0;
  if (n) {
    const r = await Tt(n);
    if (r instanceof Actor && r.uuid !== t.uuid) return r;
  }
  const a = game.user;
  if (a && !a.isGM) {
    const r = a.character;
    if (r instanceof Actor && r.uuid !== t.uuid) return r;
  }
  return null;
}
async function Ce(t, e, n, a) {
  var i, s, l;
  const r = await Tt(n);
  if (!(r instanceof Item))
    return console.warn(`monster-anatomy | item não encontrado (${n})`), null;
  const o = typeof r.name == "string" ? r.name : n;
  if (!e)
    return console.warn("monster-anatomy | sem atacante para entregar o item; registrado no pool"), o;
  try {
    const f = r.toObject() ?? {};
    delete f._id;
    const u = await e.createEmbeddedDocuments.call(e, "Item", [f]);
    if (a > 1 && ((i = u[0]) != null && i.update))
      try {
        await ((l = (s = u[0]).update) == null ? void 0 : l.call(s, { "system.quantity": a }));
      } catch {
      }
    return o;
  } catch (f) {
    return console.warn("monster-anatomy | falha ao criar item no recebedor", f), o;
  }
}
function qt(t) {
  try {
    const e = t.getFlag(d, Mt);
    return Array.isArray(e) ? e.filter((n) => n && Array.isArray(n.items)) : [];
  } catch {
    return [];
  }
}
async function Be(t) {
  await t.setFlag(d, Mt, []);
}
async function Ue(t, e) {
  const n = [...qt(t), e].slice(-200);
  await t.setFlag(d, Mt, n);
}
async function Le(t) {
  const e = await Tt(t);
  return e instanceof RollTable ? e : null;
}
async function Tt(t) {
  try {
    return await fromUuid(t);
  } catch {
    return null;
  }
}
function ze(t) {
  const e = t;
  return typeof (e == null ? void 0 : e.name) == "string" && e.name ? e.name : typeof (e == null ? void 0 : e.text) == "string" && e.text ? e.text : typeof (e == null ? void 0 : e.id) == "string" && e.id ? e.id : "";
}
function Rt(t) {
  return t.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
const ut = "system.attributes.hp.value";
async function Kt(t, e, n, a = {}) {
  return st(t, e, [{ amount: n, type: a.type }], a);
}
async function st(t, e, n, a = {}) {
  const r = y(t).find((g) => g.id === e);
  if (!r) throw new Error(`monster-anatomy: parte não encontrada (${e})`);
  let o = 0, i = 0;
  const s = de(r);
  for (const g of n) {
    const v = Math.max(0, Math.floor(Number(g == null ? void 0 : g.amount) || 0));
    v <= 0 || (o += v * ue(r, g == null ? void 0 : g.type), s && typeof (g == null ? void 0 : g.type) == "string" && (r.severTypes ?? []).includes(g.type) && (i += v));
  }
  o = Math.floor(o);
  const l = r.state, f = Math.max(0, r.hp.value - o);
  let c = l;
  f <= 0 && r.breakable ? c = "broken" : f < r.hp.max && l === "intact" && (c = "damaged"), await tt(t, e, { hp: { ...r.hp, value: f }, state: c });
  let u = y(t).find((g) => g.id === e);
  const N = await Ve(t, o);
  G(V.PART_DAMAGE, t, u, o, a.attacker ?? null);
  const p = c === "broken" && l !== "broken";
  p && (await Ee(t, u, { amount: o, attacker: a.attacker }), await Et(t, u, "break", { attackerUuid: a.attackerUuid }), G(V.PART_BREAK, t, u, o, a.attacker ?? null));
  let M = !1;
  const m = u.sever ?? { value: u.hp.max, max: u.hp.max };
  if (s && i > 0 && u.state !== "severed") {
    const g = Math.max(0, m.value - i);
    await tt(t, e, {
      sever: { value: g, max: m.max },
      ...g <= 0 ? { state: "severed" } : {}
    }), u = y(t).find((v) => v.id === e), g <= 0 && (M = !0, await Re(t, u, { amount: i, attacker: a.attacker }), await Et(t, u, "sever", { attackerUuid: a.attackerUuid }), G(V.PART_SEVER, t, u, i, a.attacker ?? null));
  }
  return { part: u, broke: p, severed: M, globalApplied: N };
}
async function jt(t, e, n) {
  const a = Math.max(0, Math.floor(Number(n) || 0)), r = y(t).find((f) => f.id === e);
  if (!r) throw new Error(`monster-anatomy: parte não encontrada (${e})`);
  const o = Math.min(r.hp.max, r.hp.value + a), i = o >= r.hp.max, s = i && (r.state === "damaged" || r.state === "broken") ? "intact" : r.state, l = r.sever ?? { value: r.hp.max, max: r.hp.max };
  return await tt(t, e, {
    hp: { ...r.hp, value: o },
    state: s,
    ...i ? { sever: { value: l.max, max: l.max } } : {}
  }), y(t).find((f) => f.id === e);
}
async function Ve(t, e) {
  if (e <= 0) return 0;
  const n = A("damageModel");
  if (n === "independent") return 0;
  const a = n === "percent" ? Math.max(0, Math.min(100, Number(A("damagePercent") ?? 50))) : 100, r = Math.floor(e * a / 100);
  if (r <= 0) return 0;
  const o = foundry.utils.getProperty(t, ut);
  if (typeof o != "number")
    return console.warn(`monster-anatomy | HP global não encontrado em ${ut}`), 0;
  const i = Math.max(0, o - r);
  return await t.update({
    [ut]: i
  }), r;
}
let j = null;
function Wt() {
  return j;
}
function R() {
  j = null;
}
async function Jt(t) {
  var N;
  const e = K(t), n = /* @__PURE__ */ new Set();
  e && n.add(e);
  let a;
  for (const p of ((N = game.user) == null ? void 0 : N.targets) ?? []) {
    const M = K(p);
    M && (n.add(M), (M === e || !e && n.size === 1) && (a = p));
  }
  if (n.size !== 1) {
    R();
    return;
  }
  const r = [...n][0], o = e === r ? t : a, i = o == null ? void 0 : o.actor;
  if (!(i instanceof Actor)) {
    R();
    return;
  }
  const s = y(i);
  if (s.length === 0) {
    R();
    return;
  }
  const l = s.map((p) => ({
    action: p.id,
    label: `${p.name} — CA ${p.ac} — ${p.hp.value}/${p.hp.max} • ${h(W[p.state])}`,
    icon: p.state === "intact" ? "fa-solid fa-crosshairs" : "fa-solid fa-burst"
  }));
  l.push({
    action: "__normal",
    label: h("MONSTER_ANATOMY.Target.Normal"),
    icon: "fa-solid fa-xmark"
  });
  const f = `<p>${w("MONSTER_ANATOMY.Target.Prompt", { actor: i.name })}</p>`, c = await foundry.applications.api.DialogV2.wait({
    window: { title: h("MONSTER_ANATOMY.Target.Title") },
    content: f,
    buttons: l,
    modal: !0
  });
  if (typeof c != "string" || c === "__normal") {
    R();
    return;
  }
  const u = y(i).find((p) => p.id === c);
  if (!u) {
    R();
    return;
  }
  j = {
    tokenUuid: r,
    actorUuid: i.uuid,
    partId: u.id
  };
}
function Ge() {
  Hooks.on("targetToken", (t, e, n) => {
    var a;
    if (t.id === ((a = game.user) == null ? void 0 : a.id)) {
      if (!n) {
        j && K(e) === j.tokenUuid && R();
        return;
      }
      if (!A("promptOnTarget")) {
        R();
        return;
      }
      Jt(e);
    }
  });
}
const { ApplicationV2: qe, HandlebarsApplicationMixin: Ke } = foundry.applications.api;
var it, Xt;
const D = class D extends Ke(qe) {
  constructor() {
    super(...arguments);
    z(this, it);
  }
  static async openFor(n, a, r) {
    await new D({ actor: n, partId: a, onSaved: r }).render(!0);
  }
  get editorOptions() {
    return this.options;
  }
  get editing() {
    const { actor: n, partId: a } = this.editorOptions;
    if (a) {
      const i = y(n).find((s) => s.id === a);
      if (i) return pt(i);
    }
    const r = Number(A("defaultAc") ?? 10), o = Number(A("defaultHp") ?? 20);
    return kt("", {
      ac: Number.isFinite(r) ? r : 10,
      hp: Number.isFinite(o) ? o : 20
    });
  }
  get isNew() {
    return !this.editorOptions.partId;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.editing, o = this.editorOptions.actor;
    return {
      ...a,
      part: r,
      isNew: this.isNew,
      actorName: o.name,
      link: U(r),
      sever: r.sever ?? { value: r.hp.max, max: r.hp.max },
      severTypes: r.severTypes ?? ["slashing"],
      rewards: ft(r).map((i) => ({ ...i })),
      items: [...o.items].flatMap(
        (i) => typeof i.id == "string" ? [{ id: i.id, label: `${i.name} (${i.type})` }] : []
      ),
      damageTypes: dt(),
      physicalTypes: se.map((i) => ({
        key: i,
        label: Qt(i),
        checked: (r.severTypes ?? ["slashing"]).includes(i)
      })),
      hitzones: dt().map((i) => {
        var s;
        return {
          key: i.key,
          label: i.label,
          value: ((s = r.hitzone) == null ? void 0 : s[i.key]) ?? 1
        };
      }),
      statuses: (CONFIG.statusEffects ?? []).filter((i) => typeof (i == null ? void 0 : i.id) == "string").map((i) => ({ value: i.id, label: i.name ?? i.id })),
      states: Object.entries(W).map(
        ([i, s]) => ({ value: i, label: h(s) })
      )
    };
  }
  async _onRender(n, a) {
    var r;
    await super._onRender(n, a), (r = this.element.querySelector("form.monster-anatomy-form")) == null || r.addEventListener("submit", (o) => void Ot(this, it, Xt).call(this, o));
  }
  static onAddReward(n, a) {
    const o = this.element.querySelector("[data-rewards]");
    if (!o) return;
    const i = document.createElement("div");
    i.className = "ma-reward", i.setAttribute("data-reward", ""), i.setAttribute("data-reward-id", foundry.utils.randomID()), i.innerHTML = `<select name="rw_event" title="${h("MONSTER_ANATOMY.Editor.RewardEvent")}"><option value="break">${h("MONSTER_ANATOMY.Reward.Break")}</option><option value="sever">${h("MONSTER_ANATOMY.Reward.Sever")}</option></select><select name="rw_kind" title="${h("MONSTER_ANATOMY.Editor.RewardKind")}"><option value="table">${h("MONSTER_ANATOMY.Reward.TableKind")}</option><option value="item">${h("MONSTER_ANATOMY.Reward.ItemKind")}</option></select><input name="rw_table" type="text" placeholder="RollTable.xxx / Item.xxx" title="${h("MONSTER_ANATOMY.Editor.RewardTable")}" /><input name="rw_draws" type="number" min="1" max="20" step="1" value="1" title="${h("MONSTER_ANATOMY.Editor.RewardDraws")}" /><button type="button" data-action="remove-reward" title="${h("MONSTER_ANATOMY.Editor.RewardRemove")}"><i class="fa-solid fa-xmark"></i></button>`, o.appendChild(i);
  }
  static onRemoveReward(n, a) {
    var r;
    (r = a.closest("[data-reward]")) == null || r.remove();
  }
};
it = new WeakSet(), Xt = async function(n) {
  var J, X, Q;
  n.preventDefault();
  const a = n.target, r = new FormData(a), o = (T) => String(r.get(T) ?? "").trim(), i = (T, S) => {
    const b = Number(r.get(T));
    return Number.isFinite(b) ? b : S;
  }, { actor: s, partId: l, onSaved: f } = this.editorOptions, c = l ? y(s).find((T) => T.id === l) : void 0, u = Math.max(1, Math.floor(i("hpMax", (c == null ? void 0 : c.hp.max) ?? 10))), N = o("effectDuration"), p = {
    disableItemId: o("disableItemId"),
    effectName: o("effectName"),
    effectIcon: o("effectIcon"),
    effectDuration: N === "" ? null : Math.max(0, Math.floor(i("effectDuration", 0))),
    condition: o("condition"),
    setAttrPath: o("setAttrPath"),
    setAttrValue: o("setAttrValue"),
    macroUuid: o("macroUuid")
  }, M = {};
  for (const { key: T } of dt()) {
    const S = r.get(`hz_${T}`);
    if (S == null) continue;
    const b = Number(S);
    !Number.isFinite(b) || b < 0 || b === 1 || !T || (M[T] = Math.round(b * 100) / 100);
  }
  const m = r.getAll("severType").filter((T) => typeof T == "string" && T !== ""), g = Math.max(
    1,
    Math.floor(i("severMax", ((J = c == null ? void 0 : c.sever) == null ? void 0 : J.max) ?? u))
  ), v = ((X = c == null ? void 0 : c.sever) == null ? void 0 : X.value) ?? g, L = [];
  a.querySelectorAll("[data-reward]").forEach((T) => {
    const S = (re) => {
      var Nt, wt;
      return ((wt = (Nt = T.querySelector(re)) == null ? void 0 : Nt.value) == null ? void 0 : wt.trim()) ?? "";
    }, b = S('input[name="rw_table"]');
    if (!b) return;
    const ne = S('select[name="rw_event"]'), ae = S('select[name="rw_kind"]');
    L.push({
      id: T.dataset.rewardId || foundry.utils.randomID(),
      kind: ae === "item" ? "item" : "table",
      uuid: b,
      draws: Math.max(1, Math.min(20, Math.floor(Number(S('input[name="rw_draws"]')) || 1))),
      onEvent: ne === "sever" ? "sever" : "break"
    });
  });
  const k = {
    id: (c == null ? void 0 : c.id) ?? "",
    name: o("name"),
    ac: Math.max(0, Math.floor(i("ac", (c == null ? void 0 : c.ac) ?? 10))),
    hp: {
      max: u,
      value: Math.max(0, Math.min(u, Math.floor(i("hpValue", (c == null ? void 0 : c.hp.value) ?? u))))
    },
    breakable: r.get("breakable") === "on",
    severable: r.get("severable") === "on",
    state: o("state") || (c == null ? void 0 : c.state) || "intact",
    notes: o("notes"),
    onBreak: p,
    hitzone: M,
    sever: { value: Math.min(g, v), max: g },
    severTypes: m,
    rewards: L
  };
  if (fe(k).length > 0) {
    (Q = ui.notifications) == null || Q.error(h("MONSTER_ANATOMY.Editor.Invalid"));
    return;
  }
  if (c) {
    const { id: T, ...S } = k;
    await tt(s, c.id, S);
  } else {
    const T = kt(k.name || h("MONSTER_ANATOMY.Part.New"), {
      ac: k.ac,
      hp: k.hp.max
    });
    await ve(s, { ...T, ...k, id: T.id });
  }
  f == null || f(), await this.close();
}, _(D, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-part-editor",
  classes: ["monster-anatomy", "monster-anatomy-editor"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Editor.Title",
    icon: "fa-solid fa-pen-to-square",
    resizable: !1
  },
  position: { width: 460, height: "auto" },
  actions: {
    "add-reward": D.onAddReward,
    "remove-reward": D.onRemoveReward
  }
}), _(D, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/part-editor.hbs" }
});
let et = D;
function dt() {
  var e;
  const t = (e = CONFIG == null ? void 0 : CONFIG.DND5E) == null ? void 0 : e.damageTypes;
  return t && typeof t == "object" ? Object.entries(t).map(([n, a]) => ({ key: n, label: Qt(a) })) : [...ce].map((n) => ({ key: n, label: n }));
}
function Qt(t) {
  try {
    return h(t);
  } catch {
    return t;
  }
}
const { ApplicationV2: je, HandlebarsApplicationMixin: We } = foundry.applications.api;
var H;
const q = class q extends We(je) {
  constructor() {
    super(...arguments);
    z(this, H, null);
  }
  static async openFor(n) {
    await new q({ actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = y(this.actor).map((o) => {
      const i = o.hp.max > 0 ? o.hp.value / o.hp.max * 100 : 0;
      return {
        ...o,
        hp: { ...o.hp },
        hpPct: Math.max(0, Math.min(100, Math.round(i))),
        stateLabel: h(W[o.state])
      };
    });
    return {
      ...a,
      actorName: this.actor.name,
      parts: r,
      empty: r.length === 0
    };
  }
  async _onRender(n, a) {
    await super._onRender(n, a), E(this, H) === null && F(this, H, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(n) {
    return E(this, H) !== null && (Hooks.off("updateActor", E(this, H)), F(this, H, null)), super.close(n);
  }
};
H = new WeakMap(), _(q, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-tracker",
  classes: ["monster-anatomy", "monster-anatomy-tracker"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Tracker.Title",
    icon: "fa-solid fa-heart-pulse",
    resizable: !0
  },
  position: { width: 320, height: "auto" },
  actions: {}
}), _(q, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-tracker.hbs" }
});
let nt = q;
const { ApplicationV2: Je, HandlebarsApplicationMixin: Xe } = foundry.applications.api;
var I;
const C = class C extends Xe(Je) {
  constructor() {
    super(...arguments);
    z(this, I, null);
  }
  static async openFor(n) {
    await new C({ actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.actor, o = y(r).map((s) => ({
      name: s.name,
      stateLabel: h(W[s.state]),
      hp: `${s.hp.value} / ${s.hp.max}`
    })), i = qt(r).map((s) => ({
      ...s,
      eventLabel: h(
        s.event === "sever" ? "MONSTER_ANATOMY.Reward.Sever" : "MONSTER_ANATOMY.Reward.Break"
      ),
      itemsText: s.items.join(", ")
    }));
    return {
      ...a,
      actorName: r.name,
      parts: o,
      loot: i,
      emptyParts: o.length === 0,
      emptyLoot: i.length === 0,
      canClear: x(r)
    };
  }
  async _onRender(n, a) {
    await super._onRender(n, a), E(this, I) === null && F(this, I, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(n) {
    return E(this, I) !== null && (Hooks.off("updateActor", E(this, I)), F(this, I, null)), super.close(n);
  }
  static async onClearLoot(n, a) {
    const r = this;
    x(r.actor) && await Be(r.actor);
  }
};
I = new WeakMap(), _(C, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-summary",
  classes: ["monster-anatomy", "monster-anatomy-summary"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Summary.Title",
    icon: "fa-solid fa-scroll",
    resizable: !0
  },
  position: { width: 460, height: "auto" },
  actions: {
    "clear-loot": C.onClearLoot
  }
}), _(C, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/loot-summary.hbs" }
});
let at = C;
const { ApplicationV2: Qe, HandlebarsApplicationMixin: Ze } = foundry.applications.api;
function tn(t, e) {
  const n = t.hp.max > 0 ? t.hp.value / t.hp.max * 100 : 0, a = U(t).disableItemId.trim(), r = a ? e.items.get(a) : void 0, o = t.sever ?? { value: t.hp.max, max: t.hp.max }, i = o.max > 0 ? o.value / o.max * 100 : 0;
  return {
    ...t,
    hp: { ...t.hp },
    sever: { value: o.value, max: o.max },
    hpPct: Math.max(0, Math.min(100, Math.round(n))),
    stateLabel: h(W[t.state]),
    hpMismatch: me(t) !== t.state,
    linkedItemName: (r == null ? void 0 : r.name) ?? a,
    linkedDisabled: a !== "" && B(t.state),
    severPct: Math.max(0, Math.min(100, Math.round(i)))
  };
}
function _t(t) {
  const e = t.closest(".ma-part"), n = e == null ? void 0 : e.querySelector("input.ma-amount"), a = Math.floor(Number(n == null ? void 0 : n.value));
  return Number.isFinite(a) && a > 0 ? a : null;
}
var $;
const O = class O extends Ze(Qe) {
  constructor() {
    super(...arguments);
    z(this, $, null);
  }
  /** Abre o painel para um Actor. */
  static async openFor(n) {
    await new O({ actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.actor, o = y(r).map((i) => tn(i, r));
    return {
      ...a,
      actorName: r.name,
      actorImg: r.img ?? "icons/svg/mystery-man.svg",
      canEdit: x(r),
      parts: o,
      empty: o.length === 0
    };
  }
  async _onRender(n, a) {
    await super._onRender(n, a), E(this, $) === null && (F(this, $, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    })), G(V.PANEL_RENDER, this));
  }
  async close(n) {
    return E(this, $) !== null && (Hooks.off("updateActor", E(this, $)), F(this, $, null)), super.close(n);
  }
  // -- actions (this = instância, injetado pelo ApplicationV2) -----------------
  static async onAddPart(n, a) {
    const r = this;
    x(r.actor) && await et.openFor(r.actor, void 0, () => void r.render());
  }
  static async onEditPart(n, a) {
    const r = this;
    if (!x(r.actor)) return;
    const o = a.dataset.partId;
    o && await et.openFor(r.actor, o, () => void r.render());
  }
  static async onOpenTracker(n, a) {
    const r = this;
    await nt.openFor(r.actor);
  }
  static async onOpenSummary(n, a) {
    const r = this;
    await at.openFor(r.actor);
  }
  static async onDamagePart(n, a) {
    const r = this;
    if (!x(r.actor)) return;
    const o = a.dataset.partId, i = _t(a);
    !o || i === null || await Kt(r.actor, o, i);
  }
  static async onHealPart(n, a) {
    const r = this;
    if (!x(r.actor)) return;
    const o = a.dataset.partId, i = _t(a);
    !o || i === null || await jt(r.actor, o, i);
  }
  static async onDeletePart(n, a) {
    const r = this;
    if (!x(r.actor)) return;
    const o = a.dataset.partId, i = y(r.actor).find((l) => l.id === o);
    !o || !i || !await foundry.applications.api.DialogV2.confirm({
      window: { title: h("MONSTER_ANATOMY.Delete.Title") },
      content: `<p>${w("MONSTER_ANATOMY.Delete.Prompt", { name: i.name })}</p>`,
      modal: !0
    }) || await ke(r.actor, o);
  }
};
$ = new WeakMap(), _(O, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-panel",
  classes: ["monster-anatomy", "monster-anatomy-panel"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Panel.Title",
    icon: "fa-solid fa-dragon",
    resizable: !0
  },
  position: { width: 500, height: "auto" },
  actions: {
    "add-part": O.onAddPart,
    "edit-part": O.onEditPart,
    "delete-part": O.onDeletePart,
    "open-tracker": O.onOpenTracker,
    "open-summary": O.onOpenSummary,
    "damage-part": O.onDamagePart,
    "heal-part": O.onHealPart
  }
}), _(O, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-panel.hbs" }
});
let mt = O;
function en() {
  var e, n;
  return {
    version: ((n = (e = game.modules) == null ? void 0 : e.get(d)) == null ? void 0 : n.version) ?? "0.0.0",
    async openAnatomy(a) {
      await mt.openFor(a);
    },
    getParts(a) {
      return y(a);
    },
    canEdit(a) {
      return x(a);
    },
    damagePart(a, r, o, i) {
      return Kt(a, r, o, i);
    },
    healPart(a, r, o) {
      return jt(a, r, o);
    },
    damagePartDetailed(a, r, o, i) {
      return st(a, r, o, i);
    },
    getSelection() {
      return Wt();
    },
    clearSelection() {
      R();
    },
    promptTargetSelection(a) {
      return Jt(a);
    },
    openTracker(a) {
      return nt.openFor(a);
    },
    openSummary(a) {
      return at.openFor(a);
    },
    on(a, r) {
      const o = a.startsWith("monsterAnatomy.") ? a : `monsterAnatomy.${a}`, i = Z(o, r);
      return () => pe(o, i);
    }
  };
}
function nn(t) {
  globalThis.MonsterAnatomy = t;
}
function P(t) {
  return typeof t == "string" ? t : "";
}
function an(t) {
  if (!Array.isArray(t)) return [];
  const e = [];
  for (const n of t) {
    if (!n || typeof n != "object") continue;
    const a = Math.max(0, Math.floor(Number(n.amount) || 0));
    if (a <= 0) continue;
    const r = n.type;
    e.push(typeof r == "string" && r ? { amount: a, type: r } : { amount: a });
  }
  return e;
}
function rn() {
  var t;
  return ((t = game.users) == null ? void 0 : t.some((e) => e.isGM && e.active)) ?? !1;
}
function on(t) {
  var e;
  return ((e = game.user) == null ? void 0 : e.isGM) === !0 || t.isOwner;
}
function sn() {
  var t;
  (t = game.socket) == null || t.on(`module.${d}`, (e) => {
    cn(e);
  });
}
async function cn(t) {
  var n, a;
  if (!t || typeof t != "object") return;
  const e = t;
  if (e.t === "apply") {
    if (!((n = game.user) != null && n.isGM)) return;
    const r = await fromUuid(
      P(e.actorUuid)
    );
    if (!(r instanceof Actor)) return;
    const o = typeof e.attacker == "string" ? e.attacker : void 0, i = typeof e.attackerUuid == "string" ? e.attackerUuid : void 0, s = await st(
      r,
      P(e.partId),
      an(e.components),
      { attacker: o, attackerUuid: i }
    );
    s.broke && rt(P(e.actorUuid), P(e.partId), "break"), s.severed && rt(P(e.actorUuid), P(e.partId), "sever");
  } else if (e.t === "present") {
    if (typeof e.by == "string" && e.by === ((a = game.user) == null ? void 0 : a.id)) return;
    const r = await fromUuid(
      P(e.actorUuid)
    );
    if (!(r instanceof Actor)) return;
    const o = y(r).find((i) => i.id === P(e.partId));
    if (!o) return;
    e.kind === "sever" ? Lt(r, o) : Ut(r, o);
  }
}
function Zt(t) {
  var e;
  try {
    (e = game.socket) == null || e.emit(`module.${d}`, t);
  } catch (n) {
    console.warn("monster-anatomy | falha no socket", n);
  }
}
function un(t, e, n, a, r) {
  var i;
  const o = { t: "apply", actorUuid: t, partId: e, components: n, attacker: a, attackerUuid: r, by: (i = game.user) == null ? void 0 : i.id };
  Zt(o);
}
function rt(t, e, n = "break") {
  var r;
  const a = { t: "present", actorUuid: t, partId: e, kind: n, by: (r = game.user) == null ? void 0 : r.id };
  Zt(a);
}
let ot = null;
function dn() {
  Z("dnd5e.rollAttackV2", (...t) => void mn(t)), Z("dnd5e.rollDamageV2", (...t) => void fn(t)), Z("dnd5e.preUseActivity", (...t) => ln(t)), Hooks.on("targetToken", (t, e, n) => {
    var a;
    t.id === ((a = game.user) == null ? void 0 : a.id) && (ot = null);
  });
}
function ln(t) {
  var i;
  const [e] = t, n = e == null ? void 0 : e.item, a = e == null ? void 0 : e.actor, r = a instanceof Actor ? a : (n == null ? void 0 : n.parent) instanceof Actor ? n.parent : void 0;
  if (!r || typeof (n == null ? void 0 : n.id) != "string" || !he(r).has(n.id)) return;
  const o = ge(r, n.id);
  return (i = ui.notifications) == null || i.warn(
    w("MONSTER_ANATOMY.Usage.Blocked", {
      item: typeof n.name == "string" ? n.name : n.id,
      part: (o == null ? void 0 : o.name) ?? "",
      actor: r.name
    })
  ), !1;
}
async function mn(t) {
  var v, L;
  const e = Wt();
  if (!e) return;
  const n = [...((v = game.user) == null ? void 0 : v.targets) ?? []], a = n.length === 1 ? n[0] : void 0, r = K(a), o = a == null ? void 0 : a.actor;
  if (!a || !r || !o || r !== e.tokenUuid || o.uuid !== e.actorUuid) {
    R();
    return;
  }
  const [i, s] = t, l = i == null ? void 0 : i[0], f = Number((l == null ? void 0 : l.total) ?? NaN);
  if (!Number.isFinite(f)) return;
  const c = hn(l), u = c === 20, N = c === 1, p = y(o).find((k) => k.id === e.partId);
  if (!p) {
    R();
    return;
  }
  const M = u || !N && f >= p.ac, m = gn(s == null ? void 0 : s.subject), g = (m == null ? void 0 : m.name) ?? ((L = game.user) == null ? void 0 : L.name) ?? "?";
  if (ot = {
    tokenUuid: r,
    actorUuid: o.uuid,
    partId: p.id,
    hit: M,
    crit: u,
    attacker: g,
    attackerUuid: m == null ? void 0 : m.uuid
  }, A("attackNotes")) {
    const k = M ? "MONSTER_ANATOMY.Attack.Hit" : "MONSTER_ANATOMY.Attack.Miss", J = u && M ? ` ${h("MONSTER_ANATOMY.Attack.CritSuffix")}` : "", X = `<div class="monster-anatomy-chat ma-attack"><p>${w(k, {
      attacker: g,
      part: p.name,
      actor: o.name,
      total: String(f),
      ac: String(p.ac)
    })}${J}</p></div>`, Q = m ? ChatMessage.getSpeaker({ actor: m }) : ChatMessage.getSpeaker({ alias: g });
    await ChatMessage.create({ speaker: Q, content: X });
  }
}
async function fn(t) {
  var s, l, f, c;
  const e = ot;
  if (ot = null, !(e != null && e.hit)) return;
  const [n] = t, a = (n ?? []).map((u) => ({ amount: Number(u == null ? void 0 : u.total) || 0, type: pn(u) })).filter((u) => u.amount > 0);
  if (a.length === 0) return;
  const r = [...((s = game.user) == null ? void 0 : s.targets) ?? []].find((u) => K(u) === e.tokenUuid), o = r == null ? void 0 : r.actor;
  if (!o || o.uuid !== e.actorUuid) return;
  const i = ((l = y(o).find((u) => u.id === e.partId)) == null ? void 0 : l.name) ?? e.partId;
  if (on(o)) {
    const u = await st(o, e.partId, a, {
      attacker: e.attacker,
      attackerUuid: e.attackerUuid
    });
    u.broke && rt(o.uuid, e.partId, "break"), u.severed && rt(o.uuid, e.partId, "sever");
  } else rn() ? (un(o.uuid, e.partId, a, e.attacker, e.attackerUuid), (f = ui.notifications) == null || f.info(w("MONSTER_ANATOMY.Target.SentToGM", { part: i }))) : (c = ui.notifications) == null || c.warn(h("MONSTER_ANATOMY.Target.NoGM"));
}
function pn(t) {
  var a, r;
  const e = t;
  if (typeof ((a = e.options) == null ? void 0 : a.type) == "string" && e.options.type) return e.options.type;
  const n = (r = e.options) == null ? void 0 : r.types;
  if (Array.isArray(n) && typeof n[0] == "string" && n[0]) return n[0];
}
function hn(t) {
  var n;
  const e = t == null ? void 0 : t.dice;
  if (Array.isArray(e))
    for (const a of e) {
      if ((a == null ? void 0 : a.faces) !== 20) continue;
      const r = a == null ? void 0 : a.results;
      if (!Array.isArray(r)) continue;
      const o = (n = r[0]) == null ? void 0 : n.result;
      if (typeof o == "number") return o;
    }
}
function gn(t) {
  const e = t == null ? void 0 : t.actor;
  return e instanceof Actor ? e : void 0;
}
function An() {
  Ge(), dn();
}
function yn() {
  game.settings.register(d, "showHeaderButton", {
    name: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "defaultAc", {
    name: "MONSTER_ANATOMY.Settings.DefaultAc.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultAc.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 10
  }), game.settings.register(d, "defaultHp", {
    name: "MONSTER_ANATOMY.Settings.DefaultHp.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultHp.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 20
  }), game.settings.register(d, "damageModel", {
    name: "MONSTER_ANATOMY.Settings.DamageModel.Name",
    hint: "MONSTER_ANATOMY.Settings.DamageModel.Hint",
    scope: "world",
    config: !0,
    type: String,
    choices: {
      independent: "MONSTER_ANATOMY.Settings.DamageModel.Independent",
      shared: "MONSTER_ANATOMY.Settings.DamageModel.Shared",
      percent: "MONSTER_ANATOMY.Settings.DamageModel.Percent"
    },
    default: "shared"
  }), game.settings.register(d, "damagePercent", {
    name: "MONSTER_ANATOMY.Settings.DamagePercent.Name",
    hint: "MONSTER_ANATOMY.Settings.DamagePercent.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 100, step: 5 },
    default: 50
  }), game.settings.register(d, "showAnnouncement", {
    name: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "announceDuration", {
    name: "MONSTER_ANATOMY.Settings.AnnounceDuration.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceDuration.Hint",
    scope: "client",
    config: !0,
    type: Number,
    range: { min: 0.5, max: 10, step: 0.5 },
    default: 2.5
  }), game.settings.register(d, "chatMessage", {
    name: "MONSTER_ANATOMY.Settings.ChatMessage.Name",
    hint: "MONSTER_ANATOMY.Settings.ChatMessage.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "tokenEffect", {
    name: "MONSTER_ANATOMY.Settings.TokenEffect.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenEffect.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "breakSound", {
    name: "MONSTER_ANATOMY.Settings.BreakSound.Name",
    hint: "MONSTER_ANATOMY.Settings.BreakSound.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(d, "promptOnTarget", {
    name: "MONSTER_ANATOMY.Settings.PromptOnTarget.Name",
    hint: "MONSTER_ANATOMY.Settings.PromptOnTarget.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "attackNotes", {
    name: "MONSTER_ANATOMY.Settings.AttackNotes.Name",
    hint: "MONSTER_ANATOMY.Settings.AttackNotes.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "announceTheme", {
    name: "MONSTER_ANATOMY.Settings.AnnounceTheme.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceTheme.Hint",
    scope: "client",
    config: !0,
    type: String,
    choices: {
      persona: "MONSTER_ANATOMY.Settings.AnnounceTheme.Persona",
      monsterhunter: "MONSTER_ANATOMY.Settings.AnnounceTheme.MonsterHunter",
      jrpg: "MONSTER_ANATOMY.Settings.AnnounceTheme.Jrpg",
      minimal: "MONSTER_ANATOMY.Settings.AnnounceTheme.Minimal",
      impact: "MONSTER_ANATOMY.Settings.AnnounceTheme.Impact",
      arcade: "MONSTER_ANATOMY.Settings.AnnounceTheme.Arcade",
      carved: "MONSTER_ANATOMY.Settings.AnnounceTheme.Carved"
    },
    default: "persona"
  }), game.settings.register(d, "customKickerBreak", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(d, "customKickerSever", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerSever.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerSever.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(d, "tokenShake", {
    name: "MONSTER_ANATOMY.Settings.TokenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "screenFlash", {
    name: "MONSTER_ANATOMY.Settings.ScreenFlash.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenFlash.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "reducedMotion", {
    name: "MONSTER_ANATOMY.Settings.ReducedMotion.Name",
    hint: "MONSTER_ANATOMY.Settings.ReducedMotion.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !1
  }), game.settings.register(d, "particles", {
    name: "MONSTER_ANATOMY.Settings.Particles.Name",
    hint: "MONSTER_ANATOMY.Settings.Particles.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "screenShake", {
    name: "MONSTER_ANATOMY.Settings.ScreenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  });
}
function te(t) {
  const e = t == null ? void 0 : t.document;
  return e instanceof Actor ? e : void 0;
}
function ee() {
  try {
    return A("showHeaderButton");
  } catch {
    return !0;
  }
}
function xt(t, e) {
  const n = te(t);
  !n || !Array.isArray(e) || !ee() || e.some((a) => (a == null ? void 0 : a.action) === "monster-anatomy") || e.unshift({
    action: "monster-anatomy",
    label: "MONSTER_ANATOMY.Panel.OpenButton",
    icon: "fa-solid fa-dragon",
    onClick: () => {
      var a;
      (a = It()) == null || a.openAnatomy(n);
    }
  });
}
function Mn() {
  Hooks.on("getHeaderControlsActorSheetV2", (...t) => {
    xt(t[0], t[1]);
  }), Hooks.on("getHeaderControlsApplicationV2", (...t) => {
    xt(t[0], t[1]);
  }), Hooks.on("getActorSheetHeaderButtons", (...t) => {
    const [e, n] = t, a = te(e) ?? (e == null ? void 0 : e.actor);
    if (!(a instanceof Actor) || !Array.isArray(n) || !ee()) return;
    const r = a;
    n.unshift({
      class: "monster-anatomy-open",
      icon: "fas fa-dragon",
      label: "MONSTER_ANATOMY.Panel.OpenButton",
      onclick: () => {
        var o;
        (o = It()) == null || o.openAnatomy(r);
      }
    });
  });
}
async function Tn() {
  await foundry.applications.handlebars.loadTemplates([
    "modules/monster-anatomy/templates/anatomy-panel.hbs",
    "modules/monster-anatomy/templates/anatomy-tracker.hbs",
    "modules/monster-anatomy/templates/loot-summary.hbs",
    "modules/monster-anatomy/templates/part-editor.hbs"
  ]);
}
function lt(t, e) {
  try {
    e();
  } catch (n) {
    console.error(`${d} | falha no init (${t})`, n);
  }
}
Hooks.once("init", () => {
  var n;
  console.log(`${d} | init`), lt("settings", yn), lt("header", Mn), lt("combat", An);
  const t = en(), e = (n = game.modules) == null ? void 0 : n.get(d);
  e && (e.api = t), nn(t), Tn();
});
Hooks.once("setup", () => {
  console.log(`${d} | setup`);
});
Hooks.once("ready", () => {
  var t, e;
  console.log(`${d} | ready (v${((e = (t = game.modules) == null ? void 0 : t.get(d)) == null ? void 0 : e.version) ?? "?"})`), sn();
});
//# sourceMappingURL=main.js.map
