var Pt = Object.defineProperty;
var Je = (e) => {
  throw TypeError(e);
};
var It = (e, t, a) => t in e ? Pt(e, t, { enumerable: !0, configurable: !0, writable: !0, value: a }) : e[t] = a;
var R = (e, t, a) => It(e, typeof t != "symbol" ? t + "" : t, a), we = (e, t, a) => t.has(e) || Je("Cannot " + a);
var b = (e, t, a) => (we(e, t, "read from private field"), a ? a.call(e) : t.get(e)), z = (e, t, a) => t.has(e) ? Je("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, a), P = (e, t, a, r) => (we(e, t, "write to private field"), r ? r.call(e, a) : t.set(e, a), a), se = (e, t, a) => (we(e, t, "access private method"), a);
const m = "monster-anatomy", nt = m, rt = "parts", J = {
  /** Disparado quando o painel de anatomia termina de renderizar. */
  PANEL_RENDER: "monsterAnatomy.panelRender",
  /** Disparado após criar/atualizar/remover uma parte. */
  PARTS_CHANGED: "monsterAnatomy.partsChanged",
  /** Disparado após aplicar dano a uma parte (sempre, mesmo sem quebra). */
  PART_DAMAGE: "monsterAnatomy.partDamage",
  /** Disparado na transição para quebrado (uma vez por transição). */
  PART_BREAK: "monsterAnatomy.partBreak",
  /** Disparado na transição para cortado (uma vez por transição). */
  PART_SEVER: "monsterAnatomy.partSever",
  /** Disparado ao entrar em fase (nome da fase). */
  PART_PHASE: "monsterAnatomy.phaseChange"
}, Ee = { mode: "inherit", value: 0 };
function xe(e) {
  const t = e.bonus;
  if (!t || typeof t != "object") return { ...Ee };
  const a = t.mode === "off" || t.mode === "percent" || t.mode === "flat" ? t.mode : "inherit", r = Number.isFinite(Number(t.value)) ? Math.max(0, Number(t.value)) : 0;
  return { mode: a, value: r };
}
function ye(e) {
  if (!Array.isArray(e.rewards)) return [];
  const t = [];
  for (const a of e.rewards) {
    if (!a || typeof a != "object") continue;
    const r = a, n = typeof r.uuid == "string" && r.uuid.trim() !== "" ? r.uuid.trim() : typeof r.tableUuid == "string" ? r.tableUuid.trim() : "";
    n !== "" && t.push({
      id: typeof r.id == "string" && r.id !== "" ? r.id : foundry.utils.randomID(),
      kind: r.kind === "item" ? "item" : "table",
      uuid: n,
      draws: Math.max(1, Math.min(20, Math.floor(Number(r.draws) || 1))),
      onEvent: r.onEvent === "sever" ? "sever" : "break"
    });
  }
  return t;
}
const Ht = ["slashing", "piercing", "bludgeoning"], $t = [
  "slashing",
  "piercing",
  "bludgeoning",
  "fire",
  "cold",
  "lightning",
  "thunder",
  "acid",
  "poison",
  "psychic",
  "necrotic",
  "radiant",
  "force"
];
function Bt(e, t) {
  var r;
  if (!t) return 1;
  const a = (r = e.hitzone) == null ? void 0 : r[t];
  return typeof a == "number" && Number.isFinite(a) && a >= 0 ? a : 1;
}
function Ft(e) {
  return e.severable && (e.severTypes ?? []).length > 0;
}
function G(e) {
  return e === "broken" || e === "severed";
}
const S = {
  disableItemId: "",
  disableItemName: "",
  effectName: "",
  effectIcon: "",
  effectDuration: null,
  condition: "",
  setAttrPath: "",
  setAttrValue: "",
  macroUuid: ""
};
function V(e) {
  return { ...S, ...e.onBreak ?? {} };
}
function Ct(e, t, a, r) {
  return {
    id: foundry.utils.randomID(),
    name: e,
    parts: t.map((n) => {
      var o;
      return {
        name: n.name,
        img: n.img ?? "",
        ac: n.ac,
        hpMax: n.hp.max,
        breakable: n.breakable,
        severable: n.severable,
        regen: Math.max(0, Math.floor(n.regen ?? 0)),
        phaseName: typeof n.phaseName == "string" ? n.phaseName : "",
        hitzone: { ...n.hitzone ?? {} },
        severMax: ((o = n.sever) == null ? void 0 : o.max) ?? n.hp.max,
        severTypes: [...n.severTypes ?? ["slashing"]],
        onBreak: V(n),
        rewards: ye(n).map((i) => ({ ...i })),
        bonus: xe(n)
      };
    })
  };
}
function Dt(e, t) {
  return e.parts.map((a) => {
    const r = Math.max(1, Math.floor(a.hpMax)), n = ue(a.name || "Nova parte", {
      ac: Math.max(0, Math.floor(a.ac)),
      hp: r
    });
    n.img = typeof a.img == "string" ? a.img : "", n.regen = Math.max(0, Math.floor(a.regen || 0)), n.phaseName = typeof a.phaseName == "string" ? a.phaseName : "", n.breakable = a.breakable !== !1, n.severable = a.severable === !0, n.hitzone = { ...a.hitzone ?? {} };
    const o = Math.max(1, Math.floor(a.severMax || r));
    n.sever = { value: o, max: o }, n.severTypes = [...a.severTypes ?? ["slashing"]], n.onBreak = { ...S, ...a.onBreak ?? {} }, n.rewards = (a.rewards ?? []).map((l) => ({ ...l })), n.bonus = { ...Ee, ...a.bonus ?? {} };
    const i = n.onBreak.disableItemName.trim(), c = i ? [...t.items].find((l) => l.name === i) : void 0, s = !c && n.onBreak.disableItemId.trim() ? t.items.get(n.onBreak.disableItemId.trim()) : void 0, u = c ?? s;
    return n.onBreak.disableItemId = typeof (u == null ? void 0 : u.id) == "string" ? u.id : "", n.onBreak.disableItemName = typeof (u == null ? void 0 : u.name) == "string" ? u.name : i, n;
  });
}
const Lt = [
  {
    id: "builtin-dragonoid",
    name: "MONSTER_ANATOMY.Template.Dragonoid",
    builtin: !0,
    map: "dragonoid",
    parts: [
      { name: "Cabeça", ac: 21, hpMax: 80, breakable: !0, severable: !1, hitzone: { bludgeoning: 1.5, piercing: 0.8 }, severMax: 80, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Corpo", ac: 19, hpMax: 100, breakable: !0, severable: !1, hitzone: {}, severMax: 100, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Asa Esquerda", ac: 20, hpMax: 60, breakable: !0, severable: !1, hitzone: {}, severMax: 60, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Asa Direita", ac: 20, hpMax: 60, breakable: !0, severable: !1, hitzone: {}, severMax: 60, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Cauda", ac: 22, hpMax: 70, breakable: !0, severable: !0, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...S, disableItemName: "Tail Swipe" }, rewards: [] }
    ]
  },
  {
    id: "builtin-humanoid",
    name: "MONSTER_ANATOMY.Template.Humanoid",
    builtin: !0,
    map: "humanoid",
    parts: [
      { name: "Cabeça", ac: 20, hpMax: 50, breakable: !0, severable: !1, hitzone: { bludgeoning: 1.5 }, severMax: 50, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Corpo", ac: 18, hpMax: 80, breakable: !0, severable: !1, hitzone: {}, severMax: 80, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Braço Esquerdo", ac: 18, hpMax: 40, breakable: !0, severable: !1, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Braço Direito", ac: 18, hpMax: 40, breakable: !0, severable: !1, hitzone: {}, severMax: 40, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Perna Esquerda", ac: 18, hpMax: 50, breakable: !0, severable: !1, hitzone: {}, severMax: 50, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] },
      { name: "Perna Direita", ac: 18, hpMax: 50, breakable: !0, severable: !1, hitzone: {}, severMax: 50, severTypes: ["slashing"], onBreak: { ...S }, rewards: [] }
    ]
  }
], oe = {
  intact: "MONSTER_ANATOMY.State.Intact",
  damaged: "MONSTER_ANATOMY.State.Damaged",
  broken: "MONSTER_ANATOMY.State.Broken",
  severed: "MONSTER_ANATOMY.State.Severed",
  destroyed: "MONSTER_ANATOMY.State.Destroyed"
};
let We = 0;
function ot() {
  We += 1;
  const e = Math.random().toString(36).slice(2, 8);
  return `part-${Date.now().toString(36)}-${e}-${We}`;
}
function ue(e, t) {
  const a = Math.max(1, Math.floor(t.hp));
  return {
    id: ot(),
    name: e.trim(),
    ac: Math.max(0, Math.floor(t.ac)),
    hp: { value: a, max: a },
    breakable: !0,
    severable: !1,
    state: "intact",
    notes: "",
    img: "",
    zone: null,
    regen: 0,
    phaseName: "",
    onBreak: { ...S },
    hitzone: {},
    sever: { value: a, max: a },
    severTypes: ["slashing"],
    rewards: [],
    bonus: { ...Ee }
  };
}
function Ut(e) {
  return e.hp.value <= 0 && e.breakable ? "broken" : e.hp.value < e.hp.max ? "damaged" : "intact";
}
function qt(e) {
  var a;
  const t = [];
  return (a = e.name) != null && a.trim() || t.push("name"), (e.ac === void 0 || !Number.isFinite(e.ac) || e.ac < 0) && t.push("ac"), (e.hp === void 0 || !Number.isFinite(e.hp.max) || e.hp.max < 1) && t.push("hp.max"), e.hp !== void 0 && (!Number.isFinite(e.hp.value) || e.hp.value < 0) && t.push("hp.value"), t;
}
function Me(e) {
  return {
    ...e,
    hp: { ...e.hp },
    onBreak: V(e),
    hitzone: { ...e.hitzone ?? {} },
    sever: e.sever ? { ...e.sever } : { value: e.hp.max, max: e.hp.max },
    severTypes: [...e.severTypes ?? ["slashing"]],
    rewards: ye(e).map((t) => ({ ...t })),
    bonus: xe(e)
  };
}
function p(e) {
  var t;
  return ((t = game.i18n) == null ? void 0 : t.localize(e)) ?? e;
}
function v(e, t) {
  var a;
  return ((a = game.i18n) == null ? void 0 : a.format(e, t)) ?? e;
}
function g(e) {
  return game.settings.get(m, e);
}
function ne(e) {
  if (!e || typeof e != "object") return;
  const t = e;
  if (typeof t.uuid == "string" && t.uuid) return t.uuid;
  if (t.document && typeof t.document == "object") {
    const a = t.document.uuid;
    if (typeof a == "string" && a) return a;
  }
}
function it() {
  var e, t;
  return (t = (e = game.modules) == null ? void 0 : e.get(m)) == null ? void 0 : t.api;
}
function W(e, ...t) {
  Hooks.callAll.call(Hooks, e, ...t);
}
function ce(e, t) {
  return Hooks.on.call(Hooks, e, t);
}
function zt(e, t) {
  Hooks.off.call(Hooks, e, t);
}
const Re = "attrBackup";
function Gt(e) {
  const t = /* @__PURE__ */ new Set();
  for (const a of st(e)) {
    if (!G(a.state)) continue;
    const r = V(a).disableItemId.trim();
    r && t.add(r);
  }
  return t;
}
function Vt(e, t) {
  return st(e).find(
    (a) => G(a.state) && V(a).disableItemId.trim() === t
  );
}
function st(e) {
  const t = e.getFlag(m, "parts");
  return Array.isArray(t) ? t : [];
}
async function Kt(e, t) {
  const a = V(t);
  a.effectName.trim() && await jt(e, t, a.effectName.trim(), a), a.condition.trim() && await Jt(e, t, a.condition.trim()), a.setAttrPath.trim() && await Wt(e, t, a), a.macroUuid.trim() && await Xt(a.macroUuid.trim());
}
async function Qe(e, t) {
  for (const a of [...e.effects])
    try {
      if (a.getFlag(m, "partId") !== t.id) continue;
      const r = a.getFlag(m, "kind");
      (r === "break-effect" || r === "break-condition" || r === "part-broken" || r === "part-severed") && await a.delete();
    } catch (r) {
      console.warn("monster-anatomy | falha ao remover efeito da parte", r);
    }
  await Qt(e, t.id);
}
async function jt(e, t, a, r) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(m, "partId") === t.id && i.getFlag(m, "kind") === "break-effect";
    } catch {
      return !1;
    }
  })) return;
  const o = {};
  o[m] = { partId: t.id, kind: "break-effect" }, await ActiveEffect.create(
    {
      name: a,
      img: r.effectIcon.trim() || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      duration: typeof r.effectDuration == "number" ? { rounds: r.effectDuration } : void 0,
      flags: o
    },
    { parent: e }
  );
}
async function Jt(e, t, a) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(m, "partId") === t.id && i.getFlag(m, "kind") === "break-condition";
    } catch {
      return !1;
    }
  })) return;
  const n = CONFIG.statusEffects.find(
    (i) => (i == null ? void 0 : i.id) === a
  ), o = {};
  o[m] = { partId: t.id, kind: "break-condition" }, await ActiveEffect.create(
    {
      name: v("MONSTER_ANATOMY.Effect.ConditionName", {
        status: (n == null ? void 0 : n.name) ?? a,
        part: t.name
      }),
      img: (n == null ? void 0 : n.img) || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      statuses: [a],
      flags: o
    },
    { parent: e }
  );
}
async function Wt(e, t, a) {
  const r = a.setAttrPath.trim(), n = ct(e);
  t.id in n || (n[t.id] = { [r]: foundry.utils.getProperty(e, r) }, await e.setFlag(m, Re, n)), await e.update({
    [r]: Zt(a.setAttrValue)
  });
}
async function Qt(e, t) {
  const a = ct(e), r = a[t];
  if (!r) return;
  const n = {};
  for (const [o, i] of Object.entries(r)) n[o] = i;
  delete a[t];
  try {
    await e.update(n);
  } catch (o) {
    console.warn("monster-anatomy | falha ao restaurar atributo", o);
  }
  await e.setFlag(m, Re, a);
}
function ct(e) {
  try {
    const t = e.getFlag(m, Re);
    if (t && typeof t == "object" && !Array.isArray(t))
      return JSON.parse(JSON.stringify(t));
  } catch {
  }
  return {};
}
async function Xt(e) {
  try {
    const a = await fromUuid(e);
    typeof (a == null ? void 0 : a.execute) == "function" ? await a.execute() : console.warn(`monster-anatomy | macro não encontrada (${e})`);
  } catch (t) {
    console.warn(`monster-anatomy | falha ao executar macro (${e})`, t);
  }
}
function Zt(e) {
  const t = e.trim();
  return t === "true" ? !0 : t === "false" ? !1 : t !== "" && Number.isFinite(Number(t)) ? Number(t) : e;
}
function y(e) {
  const t = e.getFlag(nt, rt);
  return Array.isArray(t) ? t.map((a) => ({ ...a, hp: { ...a.hp } })) : [];
}
async function ie(e, t) {
  var r;
  if (!e.isOwner)
    throw (r = ui.notifications) == null || r.warn(p("MONSTER_ANATOMY.Errors.NoPermission")), new Error("monster-anatomy: actor não editável pelo usuário atual");
  const a = y(e);
  await e.setFlag(nt, rt, t.map(Me)), await ea(e, a, t), W(J.PARTS_CHANGED, e, y(e));
}
async function ea(e, t, a) {
  var o;
  const r = new Map(t.map((i) => [i.id, i])), n = new Set(a.map((i) => i.id));
  for (const i of a) {
    const c = G(((o = r.get(i.id)) == null ? void 0 : o.state) ?? "intact"), s = G(i.state);
    if (s !== c)
      try {
        s ? await Kt(e, i) : await Qe(e, i);
      } catch (u) {
        console.warn("monster-anatomy | falha na vinculação de ruptura", u);
      }
  }
  for (const i of t)
    if (!(n.has(i.id) || !G(i.state)))
      try {
        await Qe(e, i);
      } catch (c) {
        console.warn("monster-anatomy | falha na limpeza de ruptura", c);
      }
}
async function ut(e, t) {
  const a = y(e);
  if (a.some((r) => r.id === t.id))
    throw new Error(`monster-anatomy: id de parte duplicado (${t.id})`);
  a.push(Me(t)), await ie(e, a);
}
async function le(e, t, a) {
  const r = y(e), n = r.findIndex((i) => i.id === t);
  if (n < 0) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = r[n];
  r[n] = {
    ...o,
    ...a,
    id: o.id,
    // id é imutável (§5.1 do design)
    hp: { ...o.hp, ...a.hp ?? {} }
  }, await ie(e, r);
}
async function ta(e, t) {
  const a = y(e).filter((r) => r.id !== t);
  await ie(e, a);
}
async function lt(e, t) {
  const a = y(e), r = a.find((o) => o.id === t);
  if (!r) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const n = {
    ...Me(r),
    id: ot(),
    name: `${r.name}${p("MONSTER_ANATOMY.Panel.CopySuffix")}`
  };
  return a.push(n), await ie(e, a), n;
}
function k(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function ee() {
  var e;
  return ((e = game.user) == null ? void 0 : e.isGM) === !0;
}
function aa(e) {
  const t = e.name.startsWith("MONSTER_ANATOMY.") ? p(e.name) : e.name;
  return e.builtin ? `${t} ${p("MONSTER_ANATOMY.Template.BuiltinTag")}` : t;
}
function _e() {
  return [...Lt, ...me()];
}
function me() {
  try {
    const e = g("templatesJson");
    if (typeof e != "string" || e.trim() === "") return [];
    const t = JSON.parse(e);
    return Array.isArray(t) ? t.filter(
      (a) => !!a && typeof a == "object" && typeof a.id == "string"
    ) : [];
  } catch {
    return [];
  }
}
async function mt(e) {
  await game.settings.set(m, "templatesJson", JSON.stringify(e));
}
async function na(e, t, a, r) {
  const n = Ct(e, t);
  return await mt([...me(), n]), n;
}
async function ra(e) {
  if (e.startsWith("builtin-")) return !1;
  const t = me().filter((a) => a.id !== e);
  return t.length === me().length ? !1 : (await mt(t), !0);
}
async function dt(e, t) {
  const a = _e().find((n) => n.id === t);
  if (!a) throw new Error(`monster-anatomy: modelo não encontrado (${t})`);
  const r = Dt(a, e);
  return await ie(e, [...y(e), ...r]), a.map && await e.setFlag(m, "mapLayout", a.map), typeof a.mapImage == "string" && a.mapImage !== "" && await e.setFlag(m, "mapImage", a.mapImage), r.length;
}
function ft(e) {
  try {
    const t = e.getFlag(m, "phase");
    return typeof t == "string" ? t : "";
  } catch {
    return "";
  }
}
async function oa(e, t) {
  await e.setFlag(m, "phase", t);
}
function de(e) {
  try {
    return e.getFlag(m, "hideAc") === !0;
  } catch {
    return !1;
  }
}
async function ia(e, t) {
  await e.setFlag(m, "hideAc", t);
}
function Ye() {
  var e;
  try {
    if (g("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function sa(e) {
  if (Ye()) return;
  const t = e.textContent ?? "";
  if (t.length === 0 || t.length > 24) return;
  e.textContent = "";
  let a = 0;
  for (const r of Array.from(t)) {
    if (r === " ") {
      e.appendChild(document.createTextNode(" "));
      continue;
    }
    const n = document.createElement("span");
    n.className = "ma-letter", n.textContent = r, n.style.setProperty("--i", String(a)), e.appendChild(n), a++;
  }
}
function Pe(e) {
  try {
    if (g("particles") !== !0 || Ye() || document.hidden) return;
  } catch {
    return;
  }
  const t = document.createElement("canvas");
  t.className = "monster-anatomy-particles";
  const a = Math.min(2, window.devicePixelRatio || 1);
  t.width = Math.floor(window.innerWidth * a), t.height = Math.floor(window.innerHeight * a), document.body.appendChild(t);
  const r = t.getContext("2d");
  if (!r) {
    t.remove();
    return;
  }
  r.scale(a, a);
  const n = window.innerWidth / 2, o = window.innerHeight / 2 - window.innerHeight * 0.06, i = e ? ["#9adcff", "#e8f7ff", "#4da6d8", "#0e4d64", "#ffffff"] : ["#ff3b3b", "#ffb454", "#fff3d6", "#7a1a00", "#1a1a1a"], c = [], s = 90;
  for (let T = 0; T < s; T++) {
    const M = Math.random() * Math.PI * 2, h = 180 + Math.random() * 560, f = 0.7 + Math.random() * 0.6;
    c.push({
      x: n + (Math.random() - 0.5) * 60,
      y: o + (Math.random() - 0.5) * 30,
      vx: Math.cos(M) * h,
      vy: Math.sin(M) * h - 160,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 14,
      size: 3 + Math.random() * 8,
      life: f,
      maxLife: f,
      color: i[Math.floor(Math.random() * i.length)],
      circle: Math.random() < 0.3
    });
  }
  const u = 900;
  let l = performance.now();
  const d = (T) => {
    const M = Math.min(0.05, (T - l) / 1e3);
    l = T, r.clearRect(0, 0, window.innerWidth, window.innerHeight);
    let h = !1;
    for (const f of c)
      f.life -= M, !(f.life <= 0) && (h = !0, f.vy += u * M, f.x += f.vx * M, f.y += f.vy * M, f.rot += f.vr * M, r.save(), r.globalAlpha = Math.max(0, f.life / f.maxLife), r.translate(f.x, f.y), r.rotate(f.rot), r.fillStyle = f.color, f.circle ? (r.beginPath(), r.arc(0, 0, f.size / 2, 0, Math.PI * 2), r.fill()) : r.fillRect(-f.size / 2, -f.size / 4, f.size, f.size / 2), r.restore());
    h ? requestAnimationFrame(d) : t.remove();
  };
  requestAnimationFrame(d);
}
function Ie() {
  try {
    if (g("screenShake") !== !0 || Ye()) return;
  } catch {
    return;
  }
  const e = document.getElementById("board");
  if (!e) return;
  const t = 11, a = 380, r = performance.now(), n = (o) => {
    const i = o - r;
    if (i >= a) {
      e.style.transform = "";
      return;
    }
    const c = 1 - i / a, s = Math.sin(o / 17) * t * c, u = Math.cos(o / 23) * t * 0.7 * c;
    e.style.transform = `translate(${s.toFixed(1)}px, ${u.toFixed(1)}px)`, requestAnimationFrame(n);
  };
  requestAnimationFrame(n);
}
async function ca(e, t, a) {
  g("showAnnouncement") && ht(e, t), g("chatMessage") && await fa(e, t, a), g("tokenEffect") && await ha(e, t), await pt();
}
async function ua(e, t, a) {
  g("showAnnouncement") && gt(e, t), g("chatMessage") && await pa(e, t, a), g("tokenEffect") && await ga(e, t), await pt();
}
async function pt() {
  const e = String(g("breakSound") ?? "").trim();
  if (e)
    try {
      await foundry.audio.AudioHelper.play({ src: e, volume: 0.8 });
    } catch (t) {
      console.warn(`monster-anatomy | falha ao tocar som (${e})`, t);
    }
}
function _(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function ht(e, t) {
  const a = Math.max(0.5, Math.min(10, Number(g("announceDuration") ?? 2.5)));
  $e(e, t, a, !1), Be(!1), Fe(e), Pe(!1), Ie();
}
function gt(e, t) {
  const a = Math.max(0.5, Math.min(10, Number(g("announceDuration") ?? 2.5)));
  $e(e, t, a, !0), Be(!0), Fe(e), Pe(!0), Ie();
}
function At(e, t, a) {
  const r = Math.max(0.5, Math.min(10, Number(g("announceDuration") ?? 2.5)));
  $e(e, t, r, !1, a, "is-phase"), Be(!1), Fe(e), Pe(!1), Ie();
}
function He() {
  var e;
  try {
    if (g("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function la() {
  const e = String(g("announceTheme") ?? "persona");
  return e === "monsterhunter" || e === "jrpg" || e === "minimal" || e === "impact" || e === "arcade" || e === "carved" ? e : "persona";
}
function ma(e) {
  const t = String(
    g(e ? "customKickerSever" : "customKickerBreak") ?? ""
  ).trim();
  return t !== "" ? t : p(e ? "MONSTER_ANATOMY.Announce.Severed" : "MONSTER_ANATOMY.Announce.Break");
}
function $e(e, t, a, r, n, o) {
  document.querySelectorAll(".monster-anatomy-announce").forEach((u) => u.remove());
  const i = document.createElement("div");
  i.className = `monster-anatomy-announce theme-${la()}` + (r ? " is-sever" : "") + (o ? ` ${o}` : ""), i.style.setProperty("--ma-duration", `${a}s`), He() && i.classList.add("is-reduced");
  const c = (n ?? "") !== "" ? n : ma(r);
  i.innerHTML = `<div class="ma-announce-kicker">${_(c)}</div><div class="ma-announce-part">${_(t.name)}</div><div class="ma-announce-actor">${_(e.name)}</div>`, document.body.appendChild(i);
  const s = i.querySelector(".ma-announce-kicker");
  s && sa(s), requestAnimationFrame(() => i.classList.add("is-showing")), window.setTimeout(() => {
    i.classList.remove("is-showing"), window.setTimeout(() => i.remove(), 450);
  }, Math.max(400, Math.round(a * 1e3)));
}
function Be(e) {
  try {
    if (g("screenFlash") !== !0 || He()) return;
  } catch {
    return;
  }
  const t = document.createElement("div");
  t.className = "monster-anatomy-flash" + (e ? " is-sever" : ""), document.body.appendChild(t), requestAnimationFrame(() => t.classList.add("is-showing")), window.setTimeout(() => t.classList.remove("is-showing"), 120), window.setTimeout(() => t.remove(), 450);
}
function Fe(e) {
  try {
    if (g("tokenShake") !== !0 || He()) return;
  } catch {
    return;
  }
  try {
    const t = e.getActiveTokens();
    for (const a of t) {
      const r = a == null ? void 0 : a.mesh;
      da(r);
    }
  } catch {
  }
}
function da(e) {
  const t = e == null ? void 0 : e.position;
  if (!t || typeof t.x != "number" || typeof t.y != "number") return;
  const a = t.x, r = t.y, n = 9, o = 420, i = performance.now(), c = typeof t.set == "function" ? t.set.bind(t) : null, s = (l, d) => {
    c ? c(l, d) : (t.x = l, t.y = d);
  }, u = (l) => {
    const d = l - i;
    if (d >= o) {
      s(a, r);
      return;
    }
    const T = 1 - d / o;
    s(a + Math.sin(l / 16) * n * T, r), requestAnimationFrame(u);
  };
  requestAnimationFrame(u);
}
async function fa(e, t, a) {
  const r = a.attacker ? `<p class="ma-chat-attacker">${_(
    v("MONSTER_ANATOMY.Chat.BreakBy", {
      attacker: a.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", n = `<div class="monster-anatomy-chat ma-break"><h3>💥 ${_(p("MONSTER_ANATOMY.Announce.Break"))}</h3><p>${_(
    v("MONSTER_ANATOMY.Chat.BreakText", {
      part: t.name,
      actor: e.name,
      amount: String(a.amount)
    })
  )}</p>${r}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: n
  });
}
async function yt(e, t, a, r, n = 0, o = 0) {
  let i = !1;
  try {
    i = g("attackNotes") === !0;
  } catch {
    return;
  }
  if (!i) return;
  const c = [];
  n > 0 && c.push(`+${n}%`), o > 0 && c.push(`+${o}`);
  const s = c.length > 0 ? ` ${v("MONSTER_ANATOMY.Routed.Bonus", { mark: c.join(" ") })}` : "";
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-routed"><p>${_(
      v("MONSTER_ANATOMY.Routed.Text", {
        amount: String(a),
        part: t,
        actor: e.name,
        global: String(r)
      })
    )}${_(s)}</p></div>`
  });
}
async function pa(e, t, a) {
  const r = a.attacker ? `<p class="ma-chat-attacker">${_(
    v("MONSTER_ANATOMY.Chat.SeverBy", {
      attacker: a.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", n = `<div class="monster-anatomy-chat ma-break ma-sever"><h3>🗡️ ${_(p("MONSTER_ANATOMY.Announce.Severed"))}</h3><p>${_(
    v("MONSTER_ANATOMY.Chat.SeverText", {
      part: t.name,
      actor: e.name,
      amount: String(a.amount)
    })
  )}</p>${r}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: n
  });
}
async function ha(e, t) {
  if (e.effects.some((n) => {
    try {
      return n.getFlag(m, "partId") === t.id;
    } catch {
      return !1;
    }
  })) return;
  const r = {};
  r[m] = { partId: t.id, kind: "part-broken" }, await ActiveEffect.create(
    {
      name: v("MONSTER_ANATOMY.Effect.BrokenName", { part: t.name }),
      img: "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      flags: r
    },
    { parent: e }
  );
}
async function ga(e, t) {
  if (e.effects.some((n) => {
    try {
      return n.getFlag(m, "partId") === t.id && n.getFlag(m, "kind") === "part-severed";
    } catch {
      return !1;
    }
  })) return;
  const r = {};
  r[m] = { partId: t.id, kind: "part-severed" }, await ActiveEffect.create(
    {
      name: v("MONSTER_ANATOMY.Effect.SeveredName", { part: t.name }),
      img: "systems/dnd5e/icons/svg/damage/slashing.svg",
      origin: e.uuid,
      disabled: !1,
      flags: r
    },
    { parent: e }
  );
}
const Ce = "loot", Aa = 20;
async function Xe(e, t, a, r = {}) {
  const n = ye(t).filter((s) => s.onEvent === a);
  if (n.length === 0) return;
  const o = await ya(e, r.attackerUuid), i = [];
  let c;
  for (const s of n) {
    if (s.kind === "item") {
      const l = await Ma(e, o, s.uuid, s.draws);
      l && (i.push(s.draws > 1 ? `${l} ×${s.draws}` : l), o && (c = o.name));
      continue;
    }
    const u = await wa(s.uuid);
    if (!u) {
      console.warn(`monster-anatomy | tabela não encontrada (${s.uuid})`);
      continue;
    }
    for (let l = 0; l < Math.min(Math.floor(s.draws), Aa); l++)
      try {
        const d = await u.draw({ displayChat: !1 });
        for (const T of d.results ?? []) {
          const M = va(T);
          M && i.push(M);
        }
      } catch (d) {
        console.warn("monster-anatomy | falha no sorteio", d);
        break;
      }
  }
  i.length !== 0 && (await Na(e, {
    partId: t.id,
    partName: t.name,
    event: a,
    items: i,
    ...c ? { grantedTo: c } : {},
    at: Date.now()
  }), g("chatMessage") && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-loot"><h3>🎁 ${Ze(p("MONSTER_ANATOMY.Loot.Title"))}</h3><p>${Ze(
      v("MONSTER_ANATOMY.Loot.Text", {
        part: t.name,
        actor: e.name,
        items: i.join(", ")
      })
    )}</p></div>`
  }));
}
async function ya(e, t) {
  const a = t && t !== e.uuid ? t : void 0;
  if (a) {
    const n = await De(a);
    if (n instanceof Actor && n.uuid !== e.uuid) return n;
  }
  const r = game.user;
  if (r && !r.isGM) {
    const n = r.character;
    if (n instanceof Actor && n.uuid !== e.uuid) return n;
  }
  return null;
}
async function Ma(e, t, a, r) {
  var i, c, s;
  const n = await De(a);
  if (!(n instanceof Item))
    return console.warn(`monster-anatomy | item não encontrado (${a})`), null;
  const o = typeof n.name == "string" ? n.name : a;
  if (!t)
    return console.warn("monster-anatomy | sem atacante para entregar o item; registrado no pool"), o;
  try {
    const u = n.toObject() ?? {};
    delete u._id;
    const d = await t.createEmbeddedDocuments.call(t, "Item", [u]);
    if (r > 1 && ((i = d[0]) != null && i.update))
      try {
        await ((s = (c = d[0]).update) == null ? void 0 : s.call(c, { "system.quantity": r }));
      } catch {
      }
    return o;
  } catch (u) {
    return console.warn("monster-anatomy | falha ao criar item no recebedor", u), o;
  }
}
function Mt(e) {
  try {
    const t = e.getFlag(m, Ce);
    return Array.isArray(t) ? t.filter((a) => a && Array.isArray(a.items)) : [];
  } catch {
    return [];
  }
}
async function Ta(e) {
  await e.setFlag(m, Ce, []);
}
async function Na(e, t) {
  const a = [...Mt(e), t].slice(-200);
  await e.setFlag(m, Ce, a);
}
async function wa(e) {
  const t = await De(e);
  return t instanceof RollTable ? t : null;
}
async function De(e) {
  try {
    return await fromUuid(e);
  } catch {
    return null;
  }
}
function va(e) {
  const t = e;
  return typeof (t == null ? void 0 : t.name) == "string" && t.name ? t.name : typeof (t == null ? void 0 : t.text) == "string" && t.text ? t.text : typeof (t == null ? void 0 : t.id) == "string" && t.id ? t.id : "";
}
function Ze(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
const ve = "system.attributes.hp.value";
async function Tt(e, t, a, r = {}) {
  return Te(e, t, [{ amount: a, type: r.type }], r);
}
async function Te(e, t, a, r = {}) {
  const n = y(e).find((A) => A.id === t);
  if (!n) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  let o = 0, i = 0;
  const c = Ft(n);
  for (const A of a) {
    const x = Math.max(0, Math.floor(Number(A == null ? void 0 : A.amount) || 0));
    x <= 0 || (o += x * Bt(n, A == null ? void 0 : A.type), c && typeof (A == null ? void 0 : A.type) == "string" && (n.severTypes ?? []).includes(A.type) && (i += x));
  }
  o = Math.floor(o);
  const s = n.state, u = xe(n);
  let l = 0, d = 0;
  if (G(s) && (u.mode === "percent" ? l = Math.max(0, Math.min(200, u.value)) : u.mode === "flat" ? d = Math.max(0, Math.floor(u.value)) : u.mode !== "off" && (l = Math.max(0, Math.min(200, Number(g("brokenBonus") ?? 0))))), l > 0 || d > 0) {
    const A = 1 + l / 100;
    o = Math.floor(o * A) + d, i = Math.floor(i * A) + d;
  }
  const T = Math.max(0, n.hp.value - o);
  let M = s;
  T <= 0 && n.breakable ? M = s === "severed" ? "severed" : "broken" : T < n.hp.max && s === "intact" && (M = "damaged"), await le(e, t, { hp: { ...n.hp, value: T }, state: M });
  let h = y(e).find((A) => A.id === t);
  const f = await ba(e, o);
  W(J.PART_DAMAGE, e, h, o, r.attacker ?? null);
  const B = M === "broken" && s !== "broken";
  let F = "";
  if (B) {
    await ca(e, h, { amount: o, attacker: r.attacker }), await Xe(e, h, "break", { attackerUuid: r.attackerUuid }), W(J.PART_BREAK, e, h, o, r.attacker ?? null);
    const A = (h.phaseName ?? "").trim();
    A !== "" && (F = A, await oa(e, A), At(e, h, A), W(J.PART_PHASE, e, h, A));
  }
  let q = !1;
  const $ = h.sever ?? { value: h.hp.max, max: h.hp.max };
  if (c && i > 0 && h.state !== "severed") {
    const A = Math.max(0, $.value - i);
    await le(e, t, {
      sever: { value: A, max: $.max },
      ...A <= 0 ? { state: "severed" } : {}
    }), h = y(e).find((x) => x.id === t), A <= 0 && (q = !0, await ua(e, h, { amount: i, attacker: r.attacker }), await Xe(e, h, "sever", { attackerUuid: r.attackerUuid }), W(J.PART_SEVER, e, h, i, r.attacker ?? null));
  }
  return { part: h, broke: B, severed: q, globalApplied: f, applied: o, bonus: l, bonusFlat: d, phased: F };
}
async function Le(e, t, a) {
  const r = Math.max(0, Math.floor(Number(a) || 0)), n = y(e).find((u) => u.id === t);
  if (!n) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = Math.min(n.hp.max, n.hp.value + r), i = o >= n.hp.max, c = i && (n.state === "damaged" || n.state === "broken") ? "intact" : n.state, s = n.sever ?? { value: n.hp.max, max: n.hp.max };
  return await le(e, t, {
    hp: { ...n.hp, value: o },
    state: c,
    ...i ? { sever: { value: s.max, max: s.max } } : {}
  }), y(e).find((u) => u.id === t);
}
async function ba(e, t) {
  if (t <= 0) return 0;
  const a = g("damageModel");
  if (a === "independent") return 0;
  const r = a === "percent" ? Math.max(0, Math.min(100, Number(g("damagePercent") ?? 50))) : 100, n = Math.floor(t * r / 100);
  if (n <= 0) return 0;
  const o = foundry.utils.getProperty(e, ve);
  if (typeof o != "number")
    return console.warn(`monster-anatomy | HP global não encontrado em ${ve}`), 0;
  const i = Math.max(0, o - n);
  return await e.update({
    [ve]: i
  }), n;
}
const { ApplicationV2: Sa, HandlebarsApplicationMixin: ka } = foundry.applications.api;
function Oa(e, t) {
  return {
    id: e.id,
    img: e.img ?? "",
    display: `${e.name} — CA ${t ? "??" : String(e.ac)} — ${e.hp.value}/${e.hp.max} • ${p(oe[e.state])}`
  };
}
var I, Z, Nt, wt;
const te = class te extends ka(Sa) {
  constructor(a, r) {
    super(a);
    z(this, Z);
    z(this, I, null);
    P(this, I, r);
  }
  /** Abre o seletor e resolve com o id da parte (null = normal/dispensado). */
  static pick(a) {
    return new Promise((r) => {
      new te({ actor: a }, r).render(!0);
    });
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(a) {
    const r = await super._prepareContext(a), n = this.actor, o = de(n) && !ee();
    return {
      ...r,
      actorName: n.name,
      canAdd: k(n),
      parts: y(n).map((i) => Oa(i, o))
    };
  }
  async _onRender(a, r) {
    var o, i;
    await super._onRender(a, r);
    const n = (c) => {
      if (!b(this, I)) return;
      const s = b(this, I);
      P(this, I, null), s(c), this.close();
    };
    (o = this.element.querySelector("[data-parts]")) == null || o.addEventListener("click", (c) => {
      const s = c.target.closest("[data-part-id]"), u = s == null ? void 0 : s.dataset.partId;
      u && n(u);
    }), (i = this.element.querySelector("[data-normal]")) == null || i.addEventListener("click", () => n(null)), se(this, Z, Nt).call(this);
  }
  async close(a) {
    if (b(this, I)) {
      const r = b(this, I);
      P(this, I, null), r(null);
    }
    return super.close(a);
  }
};
I = new WeakMap(), Z = new WeakSet(), /** Quick-add: cria parte na hora (nome + imagem opcional) e atualiza a lista. */
Nt = function() {
  var i, c;
  const a = this.element.querySelector('[data-qa="name"]'), r = this.element.querySelector('[data-qa="img"]'), n = this.element.querySelector('[data-qa="preview"]');
  if (!a || !r) return;
  const o = () => {
    if (!n) return;
    const s = r.value.trim();
    n.hidden = s === "", s !== "" && (n.src = s);
  };
  r.addEventListener("input", o), n == null || n.addEventListener("error", () => {
    n && (n.hidden = !0);
  }), (i = this.element.querySelector("[data-qa-browse]")) == null || i.addEventListener("click", () => {
    new foundry.applications.apps.FilePicker({
      type: "image",
      current: r.value,
      callback: (u) => {
        r.value = u, o();
      }
    }).render(!0);
  }), (c = this.element.querySelector("[data-qa-add]")) == null || c.addEventListener("click", () => {
    se(this, Z, wt).call(this);
  });
}, wt = async function() {
  const a = this.actor;
  if (!k(a)) return;
  const r = this.element.querySelector('[data-qa="name"]'), n = this.element.querySelector('[data-qa="img"]');
  if (!r || !n) return;
  const o = y(a).length, i = r.value.trim() || `${p("MONSTER_ANATOMY.Part.New")} ${o + 1}`, c = Number(g("defaultAc") ?? 10), s = Number(g("defaultHp") ?? 20), u = ue(i, {
    ac: Number.isFinite(c) ? c : 10,
    hp: Number.isFinite(s) ? s : 20
  }), l = n.value.trim();
  l !== "" && (u.img = l), await ut(a, u), r.value = "", n.value = "", await this.render();
}, R(te, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-target-map",
  classes: ["monster-anatomy", "monster-anatomy-target"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Target.Title",
    icon: "fa-solid fa-crosshairs",
    resizable: !1
  },
  position: { width: 340, height: "auto" },
  actions: {}
}), R(te, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/target-map.hbs" }
});
let ke = te, re = null;
function vt() {
  return re;
}
function H() {
  re = null;
}
async function bt(e) {
  var l;
  const t = ne(e), a = /* @__PURE__ */ new Set();
  t && a.add(t);
  let r;
  for (const d of ((l = game.user) == null ? void 0 : l.targets) ?? []) {
    const T = ne(d);
    T && (a.add(T), (T === t || !t && a.size === 1) && (r = d));
  }
  if (a.size !== 1) {
    H();
    return;
  }
  const n = [...a][0], o = t === n ? e : r, i = o == null ? void 0 : o.actor;
  if (!(i instanceof Actor)) {
    H();
    return;
  }
  if (y(i).length === 0) {
    H();
    return;
  }
  const s = await ke.pick(i);
  if (!s) {
    H();
    return;
  }
  const u = y(i).find((d) => d.id === s);
  if (!u) {
    H();
    return;
  }
  re = {
    tokenUuid: n,
    actorUuid: i.uuid,
    partId: u.id
  };
}
function Ea() {
  Hooks.on("targetToken", (e, t, a) => {
    var r;
    if (e.id === ((r = game.user) == null ? void 0 : r.id)) {
      if (!a) {
        re && ne(t) === re.tokenUuid && H();
        return;
      }
      if (!g("promptOnTarget")) {
        H();
        return;
      }
      bt(t);
    }
  });
}
const { ApplicationV2: xa, HandlebarsApplicationMixin: Ra } = foundry.applications.api;
var Ae, St;
const C = class C extends Ra(xa) {
  constructor() {
    super(...arguments);
    z(this, Ae);
  }
  static async openFor(a, r, n) {
    await new C({ actor: a, partId: r, onSaved: n }).render(!0);
  }
  get editorOptions() {
    return this.options;
  }
  get editing() {
    const { actor: a, partId: r } = this.editorOptions;
    if (r) {
      const i = y(a).find((c) => c.id === r);
      if (i) return Me(i);
    }
    const n = Number(g("defaultAc") ?? 10), o = Number(g("defaultHp") ?? 20);
    return ue("", {
      ac: Number.isFinite(n) ? n : 10,
      hp: Number.isFinite(o) ? o : 20
    });
  }
  get isNew() {
    return !this.editorOptions.partId;
  }
  async _prepareContext(a) {
    const r = await super._prepareContext(a), n = this.editing, o = this.editorOptions.actor, i = be(), c = (s) => {
      var u;
      return ((u = i.find((l) => l.key === s)) == null ? void 0 : u.label) ?? s;
    };
    return {
      ...r,
      part: n,
      isNew: this.isNew,
      actorName: o.name,
      link: V(n),
      sever: n.sever ?? { value: n.hp.max, max: n.hp.max },
      severTypes: n.severTypes ?? ["slashing"],
      rewards: ye(n).map((s) => ({ ...s })),
      items: [...o.items].flatMap(
        (s) => typeof s.id == "string" ? [{ id: s.id, label: `${s.name} (${s.type})` }] : []
      ),
      damageTypes: be(),
      physicalTypes: Ht.map((s) => ({
        key: s,
        label: c(s),
        checked: (n.severTypes ?? ["slashing"]).includes(s)
      })),
      hitzones: i.map((s) => {
        var u;
        return {
          key: s.key,
          label: s.label,
          value: ((u = n.hitzone) == null ? void 0 : u[s.key]) ?? 1
        };
      }),
      statuses: (CONFIG.statusEffects ?? []).filter((s) => typeof (s == null ? void 0 : s.id) == "string").map((s) => ({ value: s.id, label: s.name ?? s.id })),
      states: Object.entries(oe).map(
        ([s, u]) => ({ value: s, label: p(u) })
      )
    };
  }
  async _onRender(a, r) {
    var i;
    await super._onRender(a, r), (i = this.element.querySelector("form.monster-anatomy-form")) == null || i.addEventListener("submit", (c) => void se(this, Ae, St).call(this, c));
    const n = this.element.querySelector("#ma-img"), o = this.element.querySelector(".ma-imgpreview");
    n == null || n.addEventListener("input", () => et(n, o)), o == null || o.addEventListener("error", () => {
      o && (o.hidden = !0);
    });
  }
  static onBrowseImage(a, r) {
    const n = this, o = n.element.querySelector("#ma-img"), i = n.element.querySelector(".ma-imgpreview");
    new foundry.applications.apps.FilePicker({
      type: "image",
      current: (o == null ? void 0 : o.value) ?? "",
      callback: (s) => {
        o && (o.value = s, o.dispatchEvent(new Event("input", { bubbles: !0 }))), et(o, i);
      }
    }).render(!0);
  }
  static onAddReward(a, r) {
    const o = this.element.querySelector("[data-rewards]");
    if (!o) return;
    const i = document.createElement("div");
    i.className = "ma-reward", i.setAttribute("data-reward", ""), i.setAttribute("data-reward-id", foundry.utils.randomID()), i.innerHTML = `<select name="rw_event" title="${p("MONSTER_ANATOMY.Editor.RewardEvent")}"><option value="break">${p("MONSTER_ANATOMY.Reward.Break")}</option><option value="sever">${p("MONSTER_ANATOMY.Reward.Sever")}</option></select><select name="rw_kind" title="${p("MONSTER_ANATOMY.Editor.RewardKind")}"><option value="table">${p("MONSTER_ANATOMY.Reward.TableKind")}</option><option value="item">${p("MONSTER_ANATOMY.Reward.ItemKind")}</option></select><input name="rw_table" type="text" placeholder="RollTable.xxx / Item.xxx" title="${p("MONSTER_ANATOMY.Editor.RewardTable")}" /><input name="rw_draws" type="number" min="1" max="20" step="1" value="1" title="${p("MONSTER_ANATOMY.Editor.RewardDraws")}" /><button type="button" data-action="remove-reward" title="${p("MONSTER_ANATOMY.Editor.RewardRemove")}"><i class="fa-solid fa-xmark"></i></button>`, o.appendChild(i);
  }
  static onRemoveReward(a, r) {
    var n;
    (n = r.closest("[data-reward]")) == null || n.remove();
  }
};
Ae = new WeakSet(), St = async function(a) {
  var qe, ze, Ge, Ve;
  a.preventDefault();
  const r = a.target, n = new FormData(r), o = (N) => String(n.get(N) ?? "").trim(), i = (N, O) => {
    const Y = Number(n.get(N));
    return Number.isFinite(Y) ? Y : O;
  }, { actor: c, partId: s, onSaved: u } = this.editorOptions, l = s ? y(c).find((N) => N.id === s) : void 0, d = Math.max(1, Math.floor(i("hpMax", (l == null ? void 0 : l.hp.max) ?? 10))), T = Math.max(0, Math.floor(i("regen", (l == null ? void 0 : l.regen) ?? 0))), M = o("phaseName"), h = o("zone"), f = h === "head" || h === "torso" || h === "left" || h === "right" || h === "tail" ? h : (l == null ? void 0 : l.zone) ?? null, B = o("effectDuration"), F = o("disableItemId"), q = {
    disableItemId: F,
    disableItemName: ((qe = c.items.get(F)) == null ? void 0 : qe.name) ?? "",
    effectName: o("effectName"),
    effectIcon: o("effectIcon"),
    effectDuration: B === "" ? null : Math.max(0, Math.floor(i("effectDuration", 0))),
    condition: o("condition"),
    setAttrPath: o("setAttrPath"),
    setAttrValue: o("setAttrValue"),
    macroUuid: o("macroUuid")
  }, $ = {};
  for (const { key: N } of be()) {
    const O = n.get(`hz_${N}`);
    if (O == null) continue;
    const Y = Number(O);
    !Number.isFinite(Y) || Y < 0 || Y === 1 || !N || ($[N] = Math.round(Y * 100) / 100);
  }
  const A = n.getAll("severType").filter((N) => typeof N == "string" && N !== ""), x = Math.max(
    1,
    Math.floor(i("severMax", ((ze = l == null ? void 0 : l.sever) == null ? void 0 : ze.max) ?? d))
  ), Ne = ((Ge = l == null ? void 0 : l.sever) == null ? void 0 : Ge.value) ?? x, K = o("bonusMode"), xt = {
    mode: K === "off" || K === "percent" || K === "flat" ? K : "inherit",
    value: Math.max(0, i("bonusValue", 0))
  }, Ue = [];
  r.querySelectorAll("[data-reward]").forEach((N) => {
    const O = (Yt) => {
      var Ke, je;
      return ((je = (Ke = N.querySelector(Yt)) == null ? void 0 : Ke.value) == null ? void 0 : je.trim()) ?? "";
    }, Y = O('input[name="rw_table"]');
    if (!Y) return;
    const Rt = O('select[name="rw_event"]'), _t = O('select[name="rw_kind"]');
    Ue.push({
      id: N.dataset.rewardId || foundry.utils.randomID(),
      kind: _t === "item" ? "item" : "table",
      uuid: Y,
      draws: Math.max(1, Math.min(20, Math.floor(Number(O('input[name="rw_draws"]')) || 1))),
      onEvent: Rt === "sever" ? "sever" : "break"
    });
  });
  const j = {
    id: (l == null ? void 0 : l.id) ?? "",
    name: o("name"),
    img: o("img"),
    zone: f,
    ac: Math.max(0, Math.floor(i("ac", (l == null ? void 0 : l.ac) ?? 10))),
    hp: {
      max: d,
      value: Math.max(0, Math.min(d, Math.floor(i("hpValue", (l == null ? void 0 : l.hp.value) ?? d))))
    },
    breakable: n.get("breakable") === "on",
    severable: n.get("severable") === "on",
    state: o("state") || (l == null ? void 0 : l.state) || "intact",
    notes: o("notes"),
    regen: T,
    phaseName: M,
    onBreak: q,
    hitzone: $,
    sever: { value: Math.min(x, Ne), max: x },
    severTypes: A,
    rewards: Ue,
    bonus: xt
  };
  if (qt(j).length > 0) {
    (Ve = ui.notifications) == null || Ve.error(p("MONSTER_ANATOMY.Editor.Invalid"));
    return;
  }
  if (l) {
    const { id: N, ...O } = j;
    await le(c, l.id, O);
  } else {
    const N = ue(j.name || p("MONSTER_ANATOMY.Part.New"), {
      ac: j.ac,
      hp: j.hp.max
    });
    await ut(c, { ...N, ...j, id: N.id });
  }
  u == null || u(), await this.close();
}, R(C, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-part-editor",
  classes: ["monster-anatomy", "monster-anatomy-editor"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Editor.Title",
    icon: "fa-solid fa-pen-to-square",
    resizable: !1
  },
  position: { width: 460, height: "auto" },
  actions: {
    "add-reward": C.onAddReward,
    "remove-reward": C.onRemoveReward,
    "browse-image": C.onBrowseImage
  }
}), R(C, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/part-editor.hbs" }
});
let fe = C;
function et(e, t) {
  var r;
  if (!t) return;
  const a = ((r = e == null ? void 0 : e.value) == null ? void 0 : r.trim()) ?? "";
  t.hidden = a === "", a !== "" && (t.src = a);
}
function be() {
  var t;
  const e = (t = CONFIG == null ? void 0 : CONFIG.DND5E) == null ? void 0 : t.damageTypes;
  return e && typeof e == "object" ? Object.entries(e).map(([a, r]) => ({
    key: a,
    label: _a(
      typeof r == "string" ? r : typeof (r == null ? void 0 : r.label) == "string" ? r.label : a
    )
  })) : [...$t].map((a) => ({ key: a, label: a }));
}
function _a(e) {
  try {
    return p(e);
  } catch {
    return e;
  }
}
const { ApplicationV2: Ya, HandlebarsApplicationMixin: Pa } = foundry.applications.api;
var D;
const ae = class ae extends Pa(Ya) {
  constructor() {
    super(...arguments);
    z(this, D, null);
  }
  static async openFor(a) {
    await new ae({ actor: a }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(a) {
    const r = await super._prepareContext(a), n = y(this.actor).map((o) => {
      const i = o.hp.max > 0 ? o.hp.value / o.hp.max * 100 : 0;
      return {
        ...o,
        hp: { ...o.hp },
        hpPct: Math.max(0, Math.min(100, Math.round(i))),
        stateLabel: p(oe[o.state])
      };
    });
    return {
      ...r,
      actorName: this.actor.name,
      parts: n,
      empty: n.length === 0
    };
  }
  async _onRender(a, r) {
    await super._onRender(a, r), b(this, D) === null && P(this, D, Hooks.on("updateActor", (n) => {
      n.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(a) {
    return b(this, D) !== null && (Hooks.off("updateActor", b(this, D)), P(this, D, null)), super.close(a);
  }
};
D = new WeakMap(), R(ae, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-tracker",
  classes: ["monster-anatomy", "monster-anatomy-tracker"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Tracker.Title",
    icon: "fa-solid fa-heart-pulse",
    resizable: !0
  },
  position: { width: 320, height: "auto" },
  actions: {}
}), R(ae, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-tracker.hbs" }
});
let pe = ae;
const { ApplicationV2: Ia, HandlebarsApplicationMixin: Ha } = foundry.applications.api;
var L;
const Q = class Q extends Ha(Ia) {
  constructor() {
    super(...arguments);
    z(this, L, null);
  }
  static async openFor(a) {
    await new Q({ actor: a }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(a) {
    const r = await super._prepareContext(a), n = this.actor, o = y(n).map((c) => ({
      name: c.name,
      stateLabel: p(oe[c.state]),
      hp: `${c.hp.value} / ${c.hp.max}`
    })), i = Mt(n).map((c) => ({
      ...c,
      eventLabel: p(
        c.event === "sever" ? "MONSTER_ANATOMY.Reward.Sever" : "MONSTER_ANATOMY.Reward.Break"
      ),
      itemsText: c.items.join(", ")
    }));
    return {
      ...r,
      actorName: n.name,
      parts: o,
      loot: i,
      emptyParts: o.length === 0,
      emptyLoot: i.length === 0,
      canClear: k(n)
    };
  }
  async _onRender(a, r) {
    await super._onRender(a, r), b(this, L) === null && P(this, L, Hooks.on("updateActor", (n) => {
      n.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(a) {
    return b(this, L) !== null && (Hooks.off("updateActor", b(this, L)), P(this, L, null)), super.close(a);
  }
  static async onClearLoot(a, r) {
    const n = this;
    k(n.actor) && await Ta(n.actor);
  }
};
L = new WeakMap(), R(Q, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-summary",
  classes: ["monster-anatomy", "monster-anatomy-summary"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Summary.Title",
    icon: "fa-solid fa-scroll",
    resizable: !0
  },
  position: { width: 460, height: "auto" },
  actions: {
    "clear-loot": Q.onClearLoot
  }
}), R(Q, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/loot-summary.hbs" }
});
let he = Q;
const { ApplicationV2: $a, HandlebarsApplicationMixin: Ba } = foundry.applications.api;
function Fa(e, t, a) {
  const r = e.hp.max > 0 ? e.hp.value / e.hp.max * 100 : 0, n = V(e).disableItemId.trim(), o = n ? t.items.get(n) : void 0, i = e.sever ?? { value: e.hp.max, max: e.hp.max }, c = i.max > 0 ? i.value / i.max * 100 : 0;
  return {
    ...e,
    hp: { ...e.hp },
    sever: { value: i.value, max: i.max },
    hpPct: Math.max(0, Math.min(100, Math.round(r))),
    stateLabel: p(oe[e.state]),
    hpMismatch: Ut(e) !== e.state,
    linkedItemName: (o == null ? void 0 : o.name) ?? n,
    linkedDisabled: n !== "" && G(e.state),
    severPct: Math.max(0, Math.min(100, Math.round(c))),
    acDisplay: a ? "??" : String(e.ac)
  };
}
function tt(e) {
  const t = e.closest(".ma-part"), a = t == null ? void 0 : t.querySelector("input.ma-amount"), r = Math.floor(Number(a == null ? void 0 : a.value));
  return Number.isFinite(r) && r > 0 ? r : null;
}
var U;
const w = class w extends Ba($a) {
  constructor() {
    super(...arguments);
    z(this, U, null);
  }
  /** Abre o painel para um Actor. */
  static async openFor(a) {
    await new w({ actor: a }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(a) {
    const r = await super._prepareContext(a), n = this.actor, o = ee(), i = de(n), c = i && !o, s = y(n).map((u) => Fa(u, n, c));
    return {
      ...r,
      actorName: n.name,
      actorImg: n.img ?? "icons/svg/mystery-man.svg",
      canEdit: k(n),
      isGM: o,
      hideAc: i,
      phase: ft(n),
      templates: _e().map((u) => ({ id: u.id, name: aa(u) })),
      parts: s,
      empty: s.length === 0
    };
  }
  async _onRender(a, r) {
    await super._onRender(a, r), b(this, U) === null && (P(this, U, Hooks.on("updateActor", (n) => {
      n.uuid === this.actor.uuid && this.render();
    })), W(J.PANEL_RENDER, this));
  }
  async close(a) {
    return b(this, U) !== null && (Hooks.off("updateActor", b(this, U)), P(this, U, null)), super.close(a);
  }
  // -- actions (this = instância, injetado pelo ApplicationV2) -----------------
  static async onAddPart(a, r) {
    const n = this;
    k(n.actor) && await fe.openFor(n.actor, void 0, () => void n.render());
  }
  static async onDuplicatePart(a, r) {
    const n = this;
    if (!k(n.actor)) return;
    const o = r.dataset.partId;
    o && await lt(n.actor, o);
  }
  static async onEditPart(a, r) {
    const n = this;
    if (!k(n.actor)) return;
    const o = r.dataset.partId;
    o && await fe.openFor(n.actor, o, () => void n.render());
  }
  static async onOpenTracker(a, r) {
    const n = this;
    await pe.openFor(n.actor);
  }
  static async onOpenSummary(a, r) {
    const n = this;
    await he.openFor(n.actor);
  }
  static async onDamagePart(a, r) {
    const n = this;
    if (!k(n.actor)) return;
    const o = r.dataset.partId, i = tt(r);
    !o || i === null || await Tt(n.actor, o, i);
  }
  static async onHealPart(a, r) {
    const n = this;
    if (!k(n.actor)) return;
    const o = r.dataset.partId, i = tt(r);
    !o || i === null || await Le(n.actor, o, i);
  }
  static async onDeletePart(a, r) {
    const n = this;
    if (!k(n.actor)) return;
    const o = r.dataset.partId, i = y(n.actor).find((s) => s.id === o);
    !o || !i || !await foundry.applications.api.DialogV2.confirm({
      window: { title: p("MONSTER_ANATOMY.Delete.Title") },
      content: `<p>${v("MONSTER_ANATOMY.Delete.Prompt", { name: i.name })}</p>`,
      modal: !0
    }) || await ta(n.actor, o);
  }
  static async onApplyTemplate(a, r) {
    var c;
    const n = this;
    if (!k(n.actor)) return;
    const o = n.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (i)
      try {
        const s = await dt(n.actor, i);
        (c = ui.notifications) == null || c.info(v("MONSTER_ANATOMY.Template.Applied", { count: String(s) }));
      } catch (s) {
        console.warn("monster-anatomy | falha ao aplicar modelo", s);
      }
  }
  static async onSaveTemplate(a, r) {
    var c, s;
    const n = this;
    if (!ee()) return;
    const o = y(n.actor);
    if (o.length === 0) {
      (c = ui.notifications) == null || c.warn(p("MONSTER_ANATOMY.Template.Empty"));
      return;
    }
    const i = await Ca(n.actor.name);
    i && (await na(i, o), (s = ui.notifications) == null || s.info(v("MONSTER_ANATOMY.Template.Saved", { name: i })), n.render());
  }
  static async onDeleteTemplate(a, r) {
    var s, u;
    const n = this;
    if (!ee()) return;
    const o = n.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (!i) return;
    if (!await ra(i)) {
      (s = ui.notifications) == null || s.warn(p("MONSTER_ANATOMY.Template.Protected"));
      return;
    }
    (u = ui.notifications) == null || u.info(p("MONSTER_ANATOMY.Template.Deleted")), n.render();
  }
  static async onToggleHideAc(a, r) {
    const n = this;
    ee() && await ia(n.actor, !de(n.actor));
  }
};
U = new WeakMap(), R(w, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-panel",
  classes: ["monster-anatomy", "monster-anatomy-panel"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Panel.Title",
    icon: "fa-solid fa-dragon",
    resizable: !0
  },
  position: { width: 500, height: "auto" },
  actions: {
    "add-part": w.onAddPart,
    "edit-part": w.onEditPart,
    "delete-part": w.onDeletePart,
    "duplicate-part": w.onDuplicatePart,
    "open-tracker": w.onOpenTracker,
    "open-summary": w.onOpenSummary,
    "damage-part": w.onDamagePart,
    "heal-part": w.onHealPart,
    "apply-template": w.onApplyTemplate,
    "save-template": w.onSaveTemplate,
    "delete-template": w.onDeleteTemplate,
    "toggle-hide-ac": w.onToggleHideAc
  }
}), R(w, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-panel.hbs" }
});
let Oe = w;
async function Ca(e) {
  const t = await foundry.applications.api.DialogV2.wait({
    window: { title: p("MONSTER_ANATOMY.Template.NameTitle") },
    content: `<div class="form-group"><label>${p("MONSTER_ANATOMY.Template.NamePrompt")}</label><input name="templateName" type="text" value="${e}" maxlength="80" /></div>`,
    buttons: [
      {
        action: "save",
        label: p("MONSTER_ANATOMY.Editor.Save"),
        default: !0,
        callback: (a, r) => {
          var o, i;
          const n = (o = r.form) == null ? void 0 : o.querySelector(
            'input[name="templateName"]'
          );
          return ((i = n == null ? void 0 : n.value) == null ? void 0 : i.trim()) ?? "";
        }
      }
    ],
    modal: !0
  });
  return typeof t != "string" || t.trim() === "" ? null : t.trim();
}
function Da() {
  var t, a;
  return {
    version: ((a = (t = game.modules) == null ? void 0 : t.get(m)) == null ? void 0 : a.version) ?? "0.0.0",
    async openAnatomy(r) {
      await Oe.openFor(r);
    },
    getParts(r) {
      return y(r);
    },
    canEdit(r) {
      return k(r);
    },
    damagePart(r, n, o, i) {
      return Tt(r, n, o, i);
    },
    healPart(r, n, o) {
      return Le(r, n, o);
    },
    damagePartDetailed(r, n, o, i) {
      return Te(r, n, o, i);
    },
    getSelection() {
      return vt();
    },
    clearSelection() {
      H();
    },
    promptTargetSelection(r) {
      return bt(r);
    },
    openTracker(r) {
      return pe.openFor(r);
    },
    openSummary(r) {
      return he.openFor(r);
    },
    on(r, n) {
      const o = r.startsWith("monsterAnatomy.") ? r : `monsterAnatomy.${r}`, i = ce(o, n);
      return () => zt(o, i);
    },
    getTemplates() {
      return _e();
    },
    applyTemplate(r, n) {
      return dt(r, n);
    },
    duplicatePart(r, n) {
      return lt(r, n);
    }
  };
}
function La(e) {
  globalThis.MonsterAnatomy = e;
}
function E(e) {
  return typeof e == "string" ? e : "";
}
function Ua(e) {
  if (!Array.isArray(e)) return [];
  const t = [];
  for (const a of e) {
    if (!a || typeof a != "object") continue;
    const r = Math.max(0, Math.floor(Number(a.amount) || 0));
    if (r <= 0) continue;
    const n = a.type;
    t.push(typeof n == "string" && n ? { amount: r, type: n } : { amount: r });
  }
  return t;
}
function qa() {
  var e;
  return ((e = game.users) == null ? void 0 : e.some((t) => t.isGM && t.active)) ?? !1;
}
function za(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function Ga() {
  var e;
  (e = game.socket) == null || e.on(`module.${m}`, (t) => {
    Va(t);
  });
}
async function Va(e) {
  var a, r, n;
  if (!e || typeof e != "object") return;
  const t = e;
  if (t.t === "apply") {
    if (!((a = game.user) != null && a.isActiveGM)) return;
    const o = await fromUuid(
      E(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = typeof t.attacker == "string" ? t.attacker : void 0, c = typeof t.attackerUuid == "string" ? t.attackerUuid : void 0, s = await Te(
      o,
      E(t.partId),
      Ua(t.components),
      { attacker: i, attackerUuid: c }
    );
    await yt(
      o,
      ((r = y(o).find((u) => u.id === E(t.partId))) == null ? void 0 : r.name) ?? E(t.partId),
      s.applied,
      s.globalApplied,
      s.bonus,
      s.bonusFlat
    ), s.broke && X(E(t.actorUuid), E(t.partId), "break"), s.severed && X(E(t.actorUuid), E(t.partId), "sever"), s.phased !== "" && X(E(t.actorUuid), E(t.partId), "phase");
  } else if (t.t === "present") {
    if (typeof t.by == "string" && t.by === ((n = game.user) == null ? void 0 : n.id)) return;
    const o = await fromUuid(
      E(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = y(o).find((c) => c.id === E(t.partId));
    if (!i) return;
    t.kind === "sever" ? gt(o, i) : t.kind === "phase" ? At(o, i, ft(o) || "?") : ht(o, i);
  }
}
function kt(e) {
  var t;
  try {
    (t = game.socket) == null || t.emit(`module.${m}`, e);
  } catch (a) {
    console.warn("monster-anatomy | falha no socket", a);
  }
}
function Ka(e, t, a, r, n) {
  var i;
  const o = { t: "apply", actorUuid: e, partId: t, components: a, attacker: r, attackerUuid: n, by: (i = game.user) == null ? void 0 : i.id };
  kt(o);
}
function X(e, t, a = "break") {
  var n;
  const r = { t: "present", actorUuid: e, partId: t, kind: a, by: (n = game.user) == null ? void 0 : n.id };
  kt(r);
}
let ge = null;
function ja() {
  ce("dnd5e.rollAttackV2", (...e) => void Wa(e)), ce("dnd5e.rollDamageV2", (...e) => void Qa(e)), ce("dnd5e.preUseActivity", (...e) => Ja(e)), Hooks.on("targetToken", (e, t, a) => {
    var r;
    e.id === ((r = game.user) == null ? void 0 : r.id) && (ge = null);
  });
}
function Ja(e) {
  var i;
  const [t] = e, a = t == null ? void 0 : t.item, r = t == null ? void 0 : t.actor, n = r instanceof Actor ? r : (a == null ? void 0 : a.parent) instanceof Actor ? a.parent : void 0;
  if (!n || typeof (a == null ? void 0 : a.id) != "string" || !Gt(n).has(a.id)) return;
  const o = Vt(n, a.id);
  return (i = ui.notifications) == null || i.warn(
    v("MONSTER_ANATOMY.Usage.Blocked", {
      item: typeof a.name == "string" ? a.name : a.id,
      part: (o == null ? void 0 : o.name) ?? "",
      actor: n.name
    })
  ), !1;
}
async function Wa(e) {
  var F, q;
  const t = vt();
  if (!t) return;
  const a = [...((F = game.user) == null ? void 0 : F.targets) ?? []], r = a.length === 1 ? a[0] : void 0, n = ne(r), o = r == null ? void 0 : r.actor;
  if (!r || !n || !o || n !== t.tokenUuid || o.uuid !== t.actorUuid) {
    H();
    return;
  }
  const [i, c] = e, s = i == null ? void 0 : i[0], u = Number((s == null ? void 0 : s.total) ?? NaN);
  if (!Number.isFinite(u)) return;
  const l = Za(s), d = l === 20, T = l === 1, M = y(o).find(($) => $.id === t.partId);
  if (!M) {
    H();
    return;
  }
  const h = d || !T && u >= M.ac, f = en(c == null ? void 0 : c.subject), B = (f == null ? void 0 : f.name) ?? ((q = game.user) == null ? void 0 : q.name) ?? "?";
  if (ge = {
    tokenUuid: n,
    actorUuid: o.uuid,
    partId: M.id,
    hit: h,
    crit: d,
    attacker: B,
    attackerUuid: f == null ? void 0 : f.uuid
  }, g("attackNotes")) {
    const $ = h ? "MONSTER_ANATOMY.Attack.Hit" : "MONSTER_ANATOMY.Attack.Miss", A = d && h ? ` ${p("MONSTER_ANATOMY.Attack.CritSuffix")}` : "", x = de(o) ? "??" : String(M.ac), Ne = `<div class="monster-anatomy-chat ma-attack"><p>${v($, {
      attacker: B,
      part: M.name,
      actor: o.name,
      total: String(u),
      ac: x
    })}${A}</p></div>`, K = f ? ChatMessage.getSpeaker({ actor: f }) : ChatMessage.getSpeaker({ alias: B });
    await ChatMessage.create({ speaker: K, content: Ne });
  }
}
async function Qa(e) {
  var c, s, u, l;
  const t = ge;
  if (ge = null, !(t != null && t.hit)) return;
  const [a] = e, r = (a ?? []).map((d) => ({ amount: Number(d == null ? void 0 : d.total) || 0, type: Xa(d) })).filter((d) => d.amount > 0);
  if (r.length === 0) return;
  const n = [...((c = game.user) == null ? void 0 : c.targets) ?? []].find((d) => ne(d) === t.tokenUuid), o = n == null ? void 0 : n.actor;
  if (!o || o.uuid !== t.actorUuid) return;
  const i = ((s = y(o).find((d) => d.id === t.partId)) == null ? void 0 : s.name) ?? t.partId;
  if (za(o)) {
    const d = await Te(o, t.partId, r, {
      attacker: t.attacker,
      attackerUuid: t.attackerUuid
    });
    await yt(o, i, d.applied, d.globalApplied, d.bonus, d.bonusFlat), d.broke && X(o.uuid, t.partId, "break"), d.severed && X(o.uuid, t.partId, "sever"), d.phased !== "" && X(o.uuid, t.partId, "phase");
  } else qa() ? (Ka(o.uuid, t.partId, r, t.attacker, t.attackerUuid), (u = ui.notifications) == null || u.info(v("MONSTER_ANATOMY.Target.SentToGM", { part: i }))) : (l = ui.notifications) == null || l.warn(p("MONSTER_ANATOMY.Target.NoGM"));
}
function Xa(e) {
  var r, n;
  const t = e;
  if (typeof ((r = t.options) == null ? void 0 : r.type) == "string" && t.options.type) return t.options.type;
  const a = (n = t.options) == null ? void 0 : n.types;
  if (Array.isArray(a) && typeof a[0] == "string" && a[0]) return a[0];
}
function Za(e) {
  var a;
  const t = e == null ? void 0 : e.dice;
  if (Array.isArray(t))
    for (const r of t) {
      if ((r == null ? void 0 : r.faces) !== 20) continue;
      const n = r == null ? void 0 : r.results;
      if (!Array.isArray(n)) continue;
      const o = (a = n[0]) == null ? void 0 : a.result;
      if (typeof o == "number") return o;
    }
}
function en(e) {
  const t = e == null ? void 0 : e.actor;
  return t instanceof Actor ? t : void 0;
}
function tn() {
  Hooks.on("combatTurnChange", (e, t, a) => {
    var c;
    if (!((c = game.user) != null && c.isActiveGM)) return;
    const r = t, n = a;
    if (r && n) {
      const s = r.round ?? 0, u = n.round ?? 0;
      if (u < s || u === s && (n.turn ?? 0) < (r.turn ?? 0)) return;
    }
    const o = n != null && n.combatantId ? e.combatants.get(n.combatantId) : void 0, i = o == null ? void 0 : o.actor;
    i instanceof Actor && an(i);
  });
}
async function an(e) {
  const t = y(e).filter(
    (n) => (n.regen ?? 0) > 0 && n.hp.value < n.hp.max && n.state !== "destroyed"
  );
  if (t.length === 0) return;
  const a = [];
  for (const n of t)
    try {
      const o = Math.max(1, Math.floor(n.regen ?? 0)), i = n.hp.value, c = await Le(e, n.id, o), s = c.hp.value - i;
      s > 0 && a.push(`${c.name} +${s}`);
    } catch (o) {
      console.warn("monster-anatomy | falha na regeneração", o);
    }
  if (a.length === 0) return;
  let r = !1;
  try {
    r = g("chatMessage") === !0;
  } catch {
    return;
  }
  r && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-regen"><p>${v("MONSTER_ANATOMY.Regen.Text", {
      actor: e.name,
      bits: a.join(", ")
    })}</p></div>`
  });
}
function nn() {
  Ea(), ja(), tn();
}
function rn() {
  game.settings.register(m, "showHeaderButton", {
    name: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "defaultAc", {
    name: "MONSTER_ANATOMY.Settings.DefaultAc.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultAc.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 10
  }), game.settings.register(m, "defaultHp", {
    name: "MONSTER_ANATOMY.Settings.DefaultHp.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultHp.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 20
  }), game.settings.register(m, "damageModel", {
    name: "MONSTER_ANATOMY.Settings.DamageModel.Name",
    hint: "MONSTER_ANATOMY.Settings.DamageModel.Hint",
    scope: "world",
    config: !0,
    type: String,
    choices: {
      independent: "MONSTER_ANATOMY.Settings.DamageModel.Independent",
      shared: "MONSTER_ANATOMY.Settings.DamageModel.Shared",
      percent: "MONSTER_ANATOMY.Settings.DamageModel.Percent"
    },
    default: "shared"
  }), game.settings.register(m, "damagePercent", {
    name: "MONSTER_ANATOMY.Settings.DamagePercent.Name",
    hint: "MONSTER_ANATOMY.Settings.DamagePercent.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 100, step: 5 },
    default: 50
  }), game.settings.register(m, "brokenBonus", {
    name: "MONSTER_ANATOMY.Settings.BrokenBonus.Name",
    hint: "MONSTER_ANATOMY.Settings.BrokenBonus.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 200, step: 5 },
    default: 50
  }), game.settings.register(m, "showAnnouncement", {
    name: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "announceDuration", {
    name: "MONSTER_ANATOMY.Settings.AnnounceDuration.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceDuration.Hint",
    scope: "client",
    config: !0,
    type: Number,
    range: { min: 0.5, max: 10, step: 0.5 },
    default: 2.5
  }), game.settings.register(m, "chatMessage", {
    name: "MONSTER_ANATOMY.Settings.ChatMessage.Name",
    hint: "MONSTER_ANATOMY.Settings.ChatMessage.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "tokenEffect", {
    name: "MONSTER_ANATOMY.Settings.TokenEffect.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenEffect.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "breakSound", {
    name: "MONSTER_ANATOMY.Settings.BreakSound.Name",
    hint: "MONSTER_ANATOMY.Settings.BreakSound.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "promptOnTarget", {
    name: "MONSTER_ANATOMY.Settings.PromptOnTarget.Name",
    hint: "MONSTER_ANATOMY.Settings.PromptOnTarget.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "attackNotes", {
    name: "MONSTER_ANATOMY.Settings.AttackNotes.Name",
    hint: "MONSTER_ANATOMY.Settings.AttackNotes.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "announceTheme", {
    name: "MONSTER_ANATOMY.Settings.AnnounceTheme.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceTheme.Hint",
    scope: "client",
    config: !0,
    type: String,
    choices: {
      persona: "MONSTER_ANATOMY.Settings.AnnounceTheme.Persona",
      monsterhunter: "MONSTER_ANATOMY.Settings.AnnounceTheme.MonsterHunter",
      jrpg: "MONSTER_ANATOMY.Settings.AnnounceTheme.Jrpg",
      minimal: "MONSTER_ANATOMY.Settings.AnnounceTheme.Minimal",
      impact: "MONSTER_ANATOMY.Settings.AnnounceTheme.Impact",
      arcade: "MONSTER_ANATOMY.Settings.AnnounceTheme.Arcade",
      carved: "MONSTER_ANATOMY.Settings.AnnounceTheme.Carved"
    },
    default: "persona"
  }), game.settings.register(m, "customKickerBreak", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "customKickerSever", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerSever.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerSever.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "tokenShake", {
    name: "MONSTER_ANATOMY.Settings.TokenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "screenFlash", {
    name: "MONSTER_ANATOMY.Settings.ScreenFlash.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenFlash.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "reducedMotion", {
    name: "MONSTER_ANATOMY.Settings.ReducedMotion.Name",
    hint: "MONSTER_ANATOMY.Settings.ReducedMotion.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !1
  }), game.settings.register(m, "particles", {
    name: "MONSTER_ANATOMY.Settings.Particles.Name",
    hint: "MONSTER_ANATOMY.Settings.Particles.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "screenShake", {
    name: "MONSTER_ANATOMY.Settings.ScreenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "templatesJson", {
    name: "MONSTER_ANATOMY.Settings.TemplatesJson.Name",
    hint: "MONSTER_ANATOMY.Settings.TemplatesJson.Hint",
    scope: "world",
    config: !1,
    type: String,
    default: "[]"
  });
}
function Ot(e) {
  const t = e == null ? void 0 : e.document;
  return t instanceof Actor ? t : void 0;
}
function Et() {
  try {
    return g("showHeaderButton");
  } catch {
    return !0;
  }
}
function at(e, t) {
  const a = Ot(e);
  !a || !Array.isArray(t) || !Et() || t.some((r) => (r == null ? void 0 : r.action) === "monster-anatomy") || t.unshift({
    action: "monster-anatomy",
    label: "MONSTER_ANATOMY.Panel.OpenButton",
    icon: "fa-solid fa-dragon",
    onClick: () => {
      var r;
      (r = it()) == null || r.openAnatomy(a);
    }
  });
}
function on() {
  Hooks.on("getHeaderControlsActorSheetV2", (...e) => {
    at(e[0], e[1]);
  }), Hooks.on("getHeaderControlsApplicationV2", (...e) => {
    at(e[0], e[1]);
  }), Hooks.on("getActorSheetHeaderButtons", (...e) => {
    const [t, a] = e, r = Ot(t) ?? (t == null ? void 0 : t.actor);
    if (!(r instanceof Actor) || !Array.isArray(a) || !Et()) return;
    const n = r;
    a.unshift({
      class: "monster-anatomy-open",
      icon: "fas fa-dragon",
      label: "MONSTER_ANATOMY.Panel.OpenButton",
      onclick: () => {
        var o;
        (o = it()) == null || o.openAnatomy(n);
      }
    });
  });
}
async function sn() {
  await foundry.applications.handlebars.loadTemplates([
    "modules/monster-anatomy/templates/anatomy-panel.hbs",
    "modules/monster-anatomy/templates/anatomy-tracker.hbs",
    "modules/monster-anatomy/templates/loot-summary.hbs",
    "modules/monster-anatomy/templates/part-editor.hbs",
    "modules/monster-anatomy/templates/target-map.hbs"
  ]);
}
function Se(e, t) {
  try {
    t();
  } catch (a) {
    console.error(`${m} | falha no init (${e})`, a);
  }
}
Hooks.once("init", () => {
  var a;
  console.log(`${m} | init`), Se("settings", rn), Se("header", on), Se("combat", nn);
  const e = Da(), t = (a = game.modules) == null ? void 0 : a.get(m);
  t && (t.api = e), La(e), sn();
});
Hooks.once("setup", () => {
  console.log(`${m} | setup`);
});
Hooks.once("ready", () => {
  var e, t;
  console.log(`${m} | ready (v${((t = (e = game.modules) == null ? void 0 : e.get(m)) == null ? void 0 : t.version) ?? "?"})`), Ga();
});
//# sourceMappingURL=main.js.map
