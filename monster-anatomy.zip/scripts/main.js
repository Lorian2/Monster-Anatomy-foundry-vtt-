var Ct = Object.defineProperty;
var We = (e) => {
  throw TypeError(e);
};
var Ft = (e, t, n) => t in e ? Ct(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n;
var _ = (e, t, n) => Ft(e, typeof t != "symbol" ? t + "" : t, n), we = (e, t, n) => t.has(e) || We("Cannot " + n);
var O = (e, t, n) => (we(e, t, "read from private field"), n ? n.call(e) : t.get(e)), V = (e, t, n) => t.has(e) ? We("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, n), H = (e, t, n, a) => (we(e, t, "write to private field"), a ? a.call(e, n) : t.set(e, n), n), ce = (e, t, n) => (we(e, t, "access private method"), n);
const m = "monster-anatomy", rt = m, ot = "parts", W = {
  /** Disparado quando o painel de anatomia termina de renderizar. */
  PANEL_RENDER: "monsterAnatomy.panelRender",
  /** Disparado após criar/atualizar/remover uma parte. */
  PARTS_CHANGED: "monsterAnatomy.partsChanged",
  /** Disparado após aplicar dano a uma parte (sempre, mesmo sem quebra). */
  PART_DAMAGE: "monsterAnatomy.partDamage",
  /** Disparado na transição para quebrado (uma vez por transição). */
  PART_BREAK: "monsterAnatomy.partBreak",
  /** Disparado na transição para cortado (uma vez por transição). */
  PART_SEVER: "monsterAnatomy.partSever",
  /** Disparado ao entrar em fase (nome da fase). */
  PART_PHASE: "monsterAnatomy.phaseChange"
}, Re = { mode: "inherit", value: 0 };
function xe(e) {
  const t = e.bonus;
  if (!t || typeof t != "object") return { ...Re };
  const n = t.mode === "off" || t.mode === "percent" || t.mode === "flat" ? t.mode : "inherit", a = Number.isFinite(Number(t.value)) ? Math.max(0, Number(t.value)) : 0;
  return { mode: n, value: a };
}
function Me(e) {
  if (!Array.isArray(e.rewards)) return [];
  const t = [];
  for (const n of e.rewards) {
    if (!n || typeof n != "object") continue;
    const a = n, r = typeof a.uuid == "string" && a.uuid.trim() !== "" ? a.uuid.trim() : typeof a.tableUuid == "string" ? a.tableUuid.trim() : "";
    r !== "" && t.push({
      id: typeof a.id == "string" && a.id !== "" ? a.id : foundry.utils.randomID(),
      kind: a.kind === "item" ? "item" : "table",
      uuid: r,
      draws: Math.max(1, Math.min(20, Math.floor(Number(a.draws) || 1))),
      onEvent: a.onEvent === "sever" ? "sever" : "break"
    });
  }
  return t;
}
const Dt = ["slashing", "piercing", "bludgeoning"], Bt = [
  "slashing",
  "piercing",
  "bludgeoning",
  "fire",
  "cold",
  "lightning",
  "thunder",
  "acid",
  "poison",
  "psychic",
  "necrotic",
  "radiant",
  "force"
];
function Lt(e, t) {
  var a;
  if (!t) return 1;
  const n = (a = e.hitzone) == null ? void 0 : a[t];
  return typeof n == "number" && Number.isFinite(n) && n >= 0 ? n : 1;
}
function qt(e) {
  return e.severable && (e.severTypes ?? []).length > 0;
}
function G(e) {
  return e === "broken" || e === "severed";
}
const oe = {
  disableItemId: "",
  disableItemName: "",
  effectName: "",
  effectIcon: "",
  effectDuration: null,
  condition: "",
  setAttrPath: "",
  setAttrValue: "",
  macroUuid: ""
};
function K(e) {
  return { ...oe, ...e.onBreak ?? {} };
}
function Ut(e, t, n, a) {
  return {
    id: foundry.utils.randomID(),
    name: e,
    parts: t.map((r) => {
      var o;
      return {
        name: r.name,
        img: r.img ?? "",
        ac: r.ac,
        hpMax: r.hp.max,
        breakable: r.breakable,
        severable: r.severable,
        regen: Math.max(0, Math.floor(r.regen ?? 0)),
        phaseName: typeof r.phaseName == "string" ? r.phaseName : "",
        hitzone: { ...r.hitzone ?? {} },
        severMax: ((o = r.sever) == null ? void 0 : o.max) ?? r.hp.max,
        severTypes: [...r.severTypes ?? ["slashing"]],
        onBreak: K(r),
        rewards: Me(r).map((i) => ({ ...i })),
        bonus: xe(r)
      };
    })
  };
}
function it(e) {
  const t = (n) => {
    const a = foundry.utils.getProperty(e, n);
    return typeof a == "number" && Number.isFinite(a) && a > 0 ? a : null;
  };
  return { hp: t("system.attributes.hp.max"), ac: t("system.attributes.ac.value") };
}
function zt(e, t) {
  const n = it(t);
  return e.parts.map((a) => {
    const r = typeof a.hpPct == "number" && n.hp !== null ? Math.round(n.hp * a.hpPct / 100) : null, o = Math.max(1, Math.floor(r ?? a.hpMax)), i = typeof a.acDelta == "number" && n.ac !== null ? n.ac + a.acDelta : a.ac, c = le(a.name || "Nova parte", {
      ac: Math.max(0, Math.floor(i)),
      hp: o
    });
    c.img = typeof a.img == "string" ? a.img : "", c.regen = Math.max(0, Math.floor(a.regen || 0)), c.phaseName = typeof a.phaseName == "string" ? a.phaseName : "", c.breakable = a.breakable !== !1, c.severable = a.severable === !0, c.hitzone = { ...a.hitzone ?? {} };
    const s = a.hpMax > 0 ? a.severMax / a.hpMax : 1, u = Math.max(
      1,
      Math.floor(r !== null ? o * s : a.severMax || o)
    );
    c.sever = { value: u, max: u }, c.severTypes = [...a.severTypes ?? ["slashing"]], c.onBreak = { ...oe, ...a.onBreak ?? {} }, c.rewards = (a.rewards ?? []).map((f) => ({ ...f })), c.bonus = { ...Re, ...a.bonus ?? {} };
    const l = c.onBreak.disableItemName.trim(), d = l ? [...t.items].find((f) => f.name === l) : void 0, N = !d && c.onBreak.disableItemId.trim() ? t.items.get(c.onBreak.disableItemId.trim()) : void 0, y = d ?? N;
    return c.onBreak.disableItemId = typeof (y == null ? void 0 : y.id) == "string" ? y.id : "", c.onBreak.disableItemName = typeof (y == null ? void 0 : y.name) == "string" ? y.name : l, c;
  });
}
function T(e, t, n, a = {}) {
  const r = Math.max(1, Math.round(320 * t / 100));
  return {
    name: e,
    ac: 19 + n,
    hpMax: r,
    hpPct: t,
    acDelta: n,
    breakable: !0,
    severable: !1,
    hitzone: {},
    severMax: r,
    severTypes: ["slashing"],
    onBreak: { ...oe },
    rewards: [],
    ...a
  };
}
const Vt = [
  {
    id: "builtin-dragonoid",
    name: "MONSTER_ANATOMY.Template.Dragonoid",
    builtin: !0,
    map: "dragonoid",
    parts: [
      T("Cabeça", 25, 2, { hitzone: { bludgeoning: 1.5, piercing: 0.8 } }),
      T("Corpo", 40, 0),
      T("Asa Esquerda", 20, 1),
      T("Asa Direita", 20, 1),
      T("Cauda", 22, 3, {
        severable: !0,
        severMax: Math.round(320 * 22 / 100 * 0.57),
        onBreak: { ...oe, disableItemName: "Tail Swipe" }
      })
    ]
  },
  {
    id: "builtin-humanoid",
    name: "MONSTER_ANATOMY.Template.Humanoid",
    builtin: !0,
    map: "humanoid",
    parts: [
      T("Cabeça", 20, 2, { hitzone: { bludgeoning: 1.5 } }),
      T("Corpo", 35, 0),
      T("Braço Esquerdo", 15, 0),
      T("Braço Direito", 15, 0),
      T("Perna Esquerda", 18, 0),
      T("Perna Direita", 18, 0)
    ]
  },
  {
    id: "builtin-quadruped",
    name: "MONSTER_ANATOMY.Template.Quadruped",
    builtin: !0,
    map: "dragonoid",
    parts: [
      T("Cabeça", 22, 2, { hitzone: { bludgeoning: 1.5 } }),
      T("Corpo", 40, 0),
      T("Pata Dianteira Esquerda", 15, 1),
      T("Pata Dianteira Direita", 15, 1),
      T("Pata Traseira Esquerda", 15, 1),
      T("Pata Traseira Direita", 15, 1),
      T("Cauda", 15, 2, { severable: !0, severMax: Math.round(320 * 15 / 100 * 0.6) })
    ]
  },
  {
    id: "builtin-serpent",
    name: "MONSTER_ANATOMY.Template.Serpent",
    builtin: !0,
    map: "dragonoid",
    parts: [
      T("Cabeça", 25, 2, { hitzone: { bludgeoning: 1.5 } }),
      T("Corpo", 45, 0),
      T("Cauda", 25, 1, { severable: !0, severMax: Math.round(320 * 25 / 100 * 0.6) })
    ]
  },
  {
    id: "builtin-avian",
    name: "MONSTER_ANATOMY.Template.Avian",
    builtin: !0,
    map: "dragonoid",
    parts: [
      T("Cabeça", 20, 2, { hitzone: { bludgeoning: 1.5 } }),
      T("Corpo", 35, 0),
      T("Asa Esquerda", 20, 1),
      T("Asa Direita", 20, 1),
      T("Pata Esquerda", 15, 1),
      T("Pata Direita", 15, 1)
    ]
  }
], ie = {
  intact: "MONSTER_ANATOMY.State.Intact",
  damaged: "MONSTER_ANATOMY.State.Damaged",
  broken: "MONSTER_ANATOMY.State.Broken",
  severed: "MONSTER_ANATOMY.State.Severed",
  destroyed: "MONSTER_ANATOMY.State.Destroyed"
};
let Qe = 0;
function st() {
  Qe += 1;
  const e = Math.random().toString(36).slice(2, 8);
  return `part-${Date.now().toString(36)}-${e}-${Qe}`;
}
function le(e, t) {
  const n = Math.max(1, Math.floor(t.hp));
  return {
    id: st(),
    name: e.trim(),
    ac: Math.max(0, Math.floor(t.ac)),
    hp: { value: n, max: n },
    breakable: !0,
    severable: !1,
    state: "intact",
    notes: "",
    img: "",
    zone: null,
    regen: 0,
    phaseName: "",
    onBreak: { ...oe },
    hitzone: {},
    sever: { value: n, max: n },
    severTypes: ["slashing"],
    rewards: [],
    bonus: { ...Re }
  };
}
function Gt(e) {
  return e.hp.value <= 0 && e.breakable ? "broken" : e.hp.value < e.hp.max ? "damaged" : "intact";
}
function Kt(e) {
  var n;
  const t = [];
  return (n = e.name) != null && n.trim() || t.push("name"), (e.ac === void 0 || !Number.isFinite(e.ac) || e.ac < 0) && t.push("ac"), (e.hp === void 0 || !Number.isFinite(e.hp.max) || e.hp.max < 1) && t.push("hp.max"), e.hp !== void 0 && (!Number.isFinite(e.hp.value) || e.hp.value < 0) && t.push("hp.value"), t;
}
function Te(e) {
  return {
    ...e,
    hp: { ...e.hp },
    onBreak: K(e),
    hitzone: { ...e.hitzone ?? {} },
    sever: e.sever ? { ...e.sever } : { value: e.hp.max, max: e.hp.max },
    severTypes: [...e.severTypes ?? ["slashing"]],
    rewards: Me(e).map((t) => ({ ...t })),
    bonus: xe(e)
  };
}
function p(e) {
  var t;
  return ((t = game.i18n) == null ? void 0 : t.localize(e)) ?? e;
}
function w(e, t) {
  var n;
  return ((n = game.i18n) == null ? void 0 : n.format(e, t)) ?? e;
}
function g(e) {
  return game.settings.get(m, e);
}
function re(e) {
  if (!e || typeof e != "object") return;
  const t = e;
  if (typeof t.uuid == "string" && t.uuid) return t.uuid;
  if (t.document && typeof t.document == "object") {
    const n = t.document.uuid;
    if (typeof n == "string" && n) return n;
  }
}
function ct() {
  var e, t;
  return (t = (e = game.modules) == null ? void 0 : e.get(m)) == null ? void 0 : t.api;
}
function Q(e, ...t) {
  Hooks.callAll.call(Hooks, e, ...t);
}
function ue(e, t) {
  return Hooks.on.call(Hooks, e, t);
}
function jt(e, t) {
  Hooks.off.call(Hooks, e, t);
}
const _e = "attrBackup";
function Jt(e) {
  const t = /* @__PURE__ */ new Set();
  for (const n of ut(e)) {
    if (!G(n.state)) continue;
    const a = K(n).disableItemId.trim();
    a && t.add(a);
  }
  return t;
}
function Wt(e, t) {
  return ut(e).find(
    (n) => G(n.state) && K(n).disableItemId.trim() === t
  );
}
function ut(e) {
  const t = e.getFlag(m, "parts");
  return Array.isArray(t) ? t : [];
}
async function Qt(e, t) {
  const n = K(t);
  n.effectName.trim() && await Xt(e, t, n.effectName.trim(), n), n.condition.trim() && await Zt(e, t, n.condition.trim()), n.setAttrPath.trim() && await en(e, t, n), n.macroUuid.trim() && await nn(n.macroUuid.trim());
}
async function Xe(e, t) {
  for (const n of [...e.effects])
    try {
      if (n.getFlag(m, "partId") !== t.id) continue;
      const a = n.getFlag(m, "kind");
      (a === "break-effect" || a === "break-condition" || a === "part-broken" || a === "part-severed") && await n.delete();
    } catch (a) {
      console.warn("monster-anatomy | falha ao remover efeito da parte", a);
    }
  await tn(e, t.id);
}
async function Xt(e, t, n, a) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(m, "partId") === t.id && i.getFlag(m, "kind") === "break-effect";
    } catch {
      return !1;
    }
  })) return;
  const o = {};
  o[m] = { partId: t.id, kind: "break-effect" }, await ActiveEffect.create(
    {
      name: n,
      img: a.effectIcon.trim() || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      duration: typeof a.effectDuration == "number" ? { rounds: a.effectDuration } : void 0,
      flags: o
    },
    { parent: e }
  );
}
async function Zt(e, t, n) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(m, "partId") === t.id && i.getFlag(m, "kind") === "break-condition";
    } catch {
      return !1;
    }
  })) return;
  const r = CONFIG.statusEffects.find(
    (i) => (i == null ? void 0 : i.id) === n
  ), o = {};
  o[m] = { partId: t.id, kind: "break-condition" }, await ActiveEffect.create(
    {
      name: w("MONSTER_ANATOMY.Effect.ConditionName", {
        status: (r == null ? void 0 : r.name) ?? n,
        part: t.name
      }),
      img: (r == null ? void 0 : r.img) || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      statuses: [n],
      flags: o
    },
    { parent: e }
  );
}
async function en(e, t, n) {
  const a = n.setAttrPath.trim(), r = lt(e);
  t.id in r || (r[t.id] = { [a]: foundry.utils.getProperty(e, a) }, await e.setFlag(m, _e, r)), await e.update({
    [a]: an(n.setAttrValue)
  });
}
async function tn(e, t) {
  const n = lt(e), a = n[t];
  if (!a) return;
  const r = {};
  for (const [o, i] of Object.entries(a)) r[o] = i;
  delete n[t];
  try {
    await e.update(r);
  } catch (o) {
    console.warn("monster-anatomy | falha ao restaurar atributo", o);
  }
  await e.setFlag(m, _e, n);
}
function lt(e) {
  try {
    const t = e.getFlag(m, _e);
    if (t && typeof t == "object" && !Array.isArray(t))
      return JSON.parse(JSON.stringify(t));
  } catch {
  }
  return {};
}
async function nn(e) {
  try {
    const n = await fromUuid(e);
    typeof (n == null ? void 0 : n.execute) == "function" ? await n.execute() : console.warn(`monster-anatomy | macro não encontrada (${e})`);
  } catch (t) {
    console.warn(`monster-anatomy | falha ao executar macro (${e})`, t);
  }
}
function an(e) {
  const t = e.trim();
  return t === "true" ? !0 : t === "false" ? !1 : t !== "" && Number.isFinite(Number(t)) ? Number(t) : e;
}
function M(e) {
  const t = e.getFlag(rt, ot);
  return Array.isArray(t) ? t.map((n) => ({ ...n, hp: { ...n.hp } })) : [];
}
async function se(e, t) {
  var a;
  if (!e.isOwner)
    throw (a = ui.notifications) == null || a.warn(p("MONSTER_ANATOMY.Errors.NoPermission")), new Error("monster-anatomy: actor não editável pelo usuário atual");
  const n = M(e);
  await e.setFlag(rt, ot, t.map(Te)), await rn(e, n, t), Q(W.PARTS_CHANGED, e, M(e));
}
async function rn(e, t, n) {
  var o;
  const a = new Map(t.map((i) => [i.id, i])), r = new Set(n.map((i) => i.id));
  for (const i of n) {
    const c = G(((o = a.get(i.id)) == null ? void 0 : o.state) ?? "intact"), s = G(i.state);
    if (s !== c)
      try {
        s ? await Qt(e, i) : await Xe(e, i);
      } catch (u) {
        console.warn("monster-anatomy | falha na vinculação de ruptura", u);
      }
  }
  for (const i of t)
    if (!(r.has(i.id) || !G(i.state)))
      try {
        await Xe(e, i);
      } catch (c) {
        console.warn("monster-anatomy | falha na limpeza de ruptura", c);
      }
}
async function mt(e, t) {
  const n = M(e);
  if (n.some((a) => a.id === t.id))
    throw new Error(`monster-anatomy: id de parte duplicado (${t.id})`);
  n.push(Te(t)), await se(e, n);
}
async function me(e, t, n) {
  const a = M(e), r = a.findIndex((i) => i.id === t);
  if (r < 0) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = a[r];
  a[r] = {
    ...o,
    ...n,
    id: o.id,
    // id é imutável (§5.1 do design)
    hp: { ...o.hp, ...n.hp ?? {} }
  }, await se(e, a);
}
async function on(e, t) {
  const n = M(e).filter((a) => a.id !== t);
  await se(e, n);
}
async function dt(e, t) {
  const n = M(e), a = n.find((o) => o.id === t);
  if (!a) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const r = {
    ...Te(a),
    id: st(),
    name: `${a.name}${p("MONSTER_ANATOMY.Panel.CopySuffix")}`
  };
  return n.push(r), await se(e, n), r;
}
function k(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function te() {
  var e;
  return ((e = game.user) == null ? void 0 : e.isGM) === !0;
}
function sn(e) {
  const t = e.name.startsWith("MONSTER_ANATOMY.") ? p(e.name) : e.name;
  return e.builtin ? `${t} ${p("MONSTER_ANATOMY.Template.BuiltinTag")}` : t;
}
function Ye() {
  return [...Vt, ...de()];
}
function de() {
  try {
    const e = g("templatesJson");
    if (typeof e != "string" || e.trim() === "") return [];
    const t = JSON.parse(e);
    return Array.isArray(t) ? t.filter(
      (n) => !!n && typeof n == "object" && typeof n.id == "string"
    ) : [];
  } catch {
    return [];
  }
}
async function ft(e) {
  await game.settings.set(m, "templatesJson", JSON.stringify(e));
}
async function cn(e, t, n, a) {
  const r = Ut(e, t);
  return await ft([...de(), r]), r;
}
async function un(e) {
  if (e.startsWith("builtin-")) return !1;
  const t = de().filter((n) => n.id !== e);
  return t.length === de().length ? !1 : (await ft(t), !0);
}
async function pt(e, t) {
  const n = Ye().find((r) => r.id === t);
  if (!n) throw new Error(`monster-anatomy: modelo não encontrado (${t})`);
  const a = zt(n, e);
  return await se(e, [...M(e), ...a]), n.map && await e.setFlag(m, "mapLayout", n.map), typeof n.mapImage == "string" && n.mapImage !== "" && await e.setFlag(m, "mapImage", n.mapImage), a.length;
}
function ht(e) {
  try {
    const t = e.getFlag(m, "phase");
    return typeof t == "string" ? t : "";
  } catch {
    return "";
  }
}
async function ln(e, t) {
  await e.setFlag(m, "phase", t);
}
function fe(e) {
  try {
    return e.getFlag(m, "hideAc") === !0;
  } catch {
    return !1;
  }
}
async function mn(e, t) {
  await e.setFlag(m, "hideAc", t);
}
function Pe() {
  var e;
  try {
    if (g("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function dn(e) {
  if (Pe()) return;
  const t = e.textContent ?? "";
  if (t.length === 0 || t.length > 24) return;
  e.textContent = "";
  let n = 0;
  for (const a of Array.from(t)) {
    if (a === " ") {
      e.appendChild(document.createTextNode(" "));
      continue;
    }
    const r = document.createElement("span");
    r.className = "ma-letter", r.textContent = a, r.style.setProperty("--i", String(n)), e.appendChild(r), n++;
  }
}
function Ie(e) {
  try {
    if (g("particles") !== !0 || Pe() || document.hidden) return;
  } catch {
    return;
  }
  const t = document.createElement("canvas");
  t.className = "monster-anatomy-particles";
  const n = Math.min(2, window.devicePixelRatio || 1);
  t.width = Math.floor(window.innerWidth * n), t.height = Math.floor(window.innerHeight * n), document.body.appendChild(t);
  const a = t.getContext("2d");
  if (!a) {
    t.remove();
    return;
  }
  a.scale(n, n);
  const r = window.innerWidth / 2, o = window.innerHeight / 2 - window.innerHeight * 0.06;
  let i = !1;
  try {
    i = String(g("announceTheme") ?? "celestial") === "celestial";
  } catch {
  }
  const c = i ? e ? ["#00f0ff", "#e8fdff", "#4dd0e0", "#00606a", "#ffffff"] : ["#f4d068", "#fffdf5", "#ffe9a3", "#b88a1e", "#ff2a54"] : e ? ["#9adcff", "#e8f7ff", "#4da6d8", "#0e4d64", "#ffffff"] : ["#ff3b3b", "#ffb454", "#fff3d6", "#7a1a00", "#1a1a1a"], s = [], u = 90;
  for (let y = 0; y < u; y++) {
    const f = Math.random() * Math.PI * 2, b = 180 + Math.random() * 560, h = 0.7 + Math.random() * 0.6;
    s.push({
      x: r + (Math.random() - 0.5) * 60,
      y: o + (Math.random() - 0.5) * 30,
      vx: Math.cos(f) * b,
      vy: Math.sin(f) * b - 160,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 14,
      size: 3 + Math.random() * 8,
      life: h,
      maxLife: h,
      color: c[Math.floor(Math.random() * c.length)],
      circle: Math.random() < 0.3
    });
  }
  const l = 900;
  let d = performance.now();
  const N = (y) => {
    const f = Math.min(0.05, (y - d) / 1e3);
    d = y, a.clearRect(0, 0, window.innerWidth, window.innerHeight);
    let b = !1;
    for (const h of s)
      h.life -= f, !(h.life <= 0) && (b = !0, h.vy += l * f, h.x += h.vx * f, h.y += h.vy * f, h.rot += h.vr * f, a.save(), a.globalAlpha = Math.max(0, h.life / h.maxLife), a.translate(h.x, h.y), a.rotate(h.rot), a.fillStyle = h.color, h.circle ? (a.beginPath(), a.arc(0, 0, h.size / 2, 0, Math.PI * 2), a.fill()) : a.fillRect(-h.size / 2, -h.size / 4, h.size, h.size / 2), a.restore());
    b ? requestAnimationFrame(N) : t.remove();
  };
  requestAnimationFrame(N);
}
function He() {
  try {
    if (g("screenShake") !== !0 || Pe()) return;
  } catch {
    return;
  }
  const e = document.getElementById("board");
  if (!e) return;
  const t = 11, n = 380, a = performance.now(), r = (o) => {
    const i = o - a;
    if (i >= n) {
      e.style.transform = "";
      return;
    }
    const c = 1 - i / n, s = Math.sin(o / 17) * t * c, u = Math.cos(o / 23) * t * 0.7 * c;
    e.style.transform = `translate(${s.toFixed(1)}px, ${u.toFixed(1)}px)`, requestAnimationFrame(r);
  };
  requestAnimationFrame(r);
}
async function fn(e, t, n) {
  g("showAnnouncement") && At(e, t), g("chatMessage") && await An(e, t, n), g("tokenEffect") && await Mn(e, t), await gt();
}
async function pn(e, t, n) {
  g("showAnnouncement") && yt(e, t), g("chatMessage") && await yn(e, t, n), g("tokenEffect") && await Tn(e, t), await gt();
}
async function gt() {
  const e = String(g("breakSound") ?? "").trim();
  if (e)
    try {
      await foundry.audio.AudioHelper.play({ src: e, volume: 0.8 });
    } catch (t) {
      console.warn(`monster-anatomy | falha ao tocar som (${e})`, t);
    }
}
function P(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function At(e, t) {
  const n = Math.max(0.5, Math.min(10, Number(g("announceDuration") ?? 2.5)));
  Ce(e, t, n, !1), Fe(!1), De(e), Ie(!1), He();
}
function yt(e, t) {
  const n = Math.max(0.5, Math.min(10, Number(g("announceDuration") ?? 2.5)));
  Ce(e, t, n, !0), Fe(!0), De(e), Ie(!0), He();
}
function Mt(e, t, n) {
  const a = Math.max(0.5, Math.min(10, Number(g("announceDuration") ?? 2.5)));
  Ce(e, t, a, !1, n, "is-phase"), Fe(!1), De(e), Ie(!1), He();
}
function $e() {
  var e;
  try {
    if (g("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function Tt() {
  const e = String(g("announceTheme") ?? "celestial");
  return e === "celestial" || e === "monsterhunter" || e === "jrpg" || e === "minimal" || e === "impact" || e === "arcade" || e === "carved" ? e : "celestial";
}
function hn(e) {
  const t = String(
    g(e ? "customKickerSever" : "customKickerBreak") ?? ""
  ).trim();
  return t !== "" ? t : p(e ? "MONSTER_ANATOMY.Announce.Severed" : "MONSTER_ANATOMY.Announce.Break");
}
function Ce(e, t, n, a, r, o) {
  document.querySelectorAll(".monster-anatomy-announce").forEach((u) => u.remove());
  const i = document.createElement("div");
  i.className = `monster-anatomy-announce theme-${Tt()}` + (a ? " is-sever" : "") + (o ? ` ${o}` : ""), i.style.setProperty("--ma-duration", `${n}s`), $e() && i.classList.add("is-reduced");
  const c = (r ?? "") !== "" ? r : hn(a);
  i.innerHTML = `<div class="ma-announce-band"></div><div class="ma-announce-kicker">${P(c)}</div><div class="ma-announce-part">${P(t.name)}</div><div class="ma-announce-actor">${P(e.name)}</div>`, document.body.appendChild(i);
  const s = i.querySelector(".ma-announce-kicker");
  s && dn(s), requestAnimationFrame(() => i.classList.add("is-showing")), window.setTimeout(() => {
    i.classList.remove("is-showing"), window.setTimeout(() => i.remove(), 450);
  }, Math.max(400, Math.round(n * 1e3)));
}
function Fe(e) {
  try {
    if (g("screenFlash") !== !0 || $e()) return;
  } catch {
    return;
  }
  const t = document.createElement("div");
  t.className = `monster-anatomy-flash theme-${Tt()}` + (e ? " is-sever" : ""), document.body.appendChild(t), requestAnimationFrame(() => t.classList.add("is-showing")), window.setTimeout(() => t.classList.remove("is-showing"), 120), window.setTimeout(() => t.remove(), 450);
}
function De(e) {
  try {
    if (g("tokenShake") !== !0 || $e()) return;
  } catch {
    return;
  }
  try {
    const t = e.getActiveTokens();
    for (const n of t) {
      const a = n == null ? void 0 : n.mesh;
      gn(a);
    }
  } catch {
  }
}
function gn(e) {
  const t = e == null ? void 0 : e.position;
  if (!t || typeof t.x != "number" || typeof t.y != "number") return;
  const n = t.x, a = t.y, r = 9, o = 420, i = performance.now(), c = typeof t.set == "function" ? t.set.bind(t) : null, s = (l, d) => {
    c ? c(l, d) : (t.x = l, t.y = d);
  }, u = (l) => {
    const d = l - i;
    if (d >= o) {
      s(n, a);
      return;
    }
    const N = 1 - d / o;
    s(n + Math.sin(l / 16) * r * N, a), requestAnimationFrame(u);
  };
  requestAnimationFrame(u);
}
async function An(e, t, n) {
  const a = n.attacker ? `<p class="ma-chat-attacker">${P(
    w("MONSTER_ANATOMY.Chat.BreakBy", {
      attacker: n.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", r = `<div class="monster-anatomy-chat ma-break"><h3>💥 ${P(p("MONSTER_ANATOMY.Announce.Break"))}</h3><p>${P(
    w("MONSTER_ANATOMY.Chat.BreakText", {
      part: t.name,
      actor: e.name,
      amount: String(n.amount)
    })
  )}</p>${a}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: r
  });
}
async function Nt(e, t, n, a, r = 0, o = 0) {
  let i = !1;
  try {
    i = g("attackNotes") === !0;
  } catch {
    return;
  }
  if (!i) return;
  const c = [];
  r > 0 && c.push(`+${r}%`), o > 0 && c.push(`+${o}`);
  const s = c.length > 0 ? ` ${w("MONSTER_ANATOMY.Routed.Bonus", { mark: c.join(" ") })}` : "";
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-routed"><p>${P(
      w("MONSTER_ANATOMY.Routed.Text", {
        amount: String(n),
        part: t,
        actor: e.name,
        global: String(a)
      })
    )}${P(s)}</p></div>`
  });
}
async function yn(e, t, n) {
  const a = n.attacker ? `<p class="ma-chat-attacker">${P(
    w("MONSTER_ANATOMY.Chat.SeverBy", {
      attacker: n.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", r = `<div class="monster-anatomy-chat ma-break ma-sever"><h3>🗡️ ${P(p("MONSTER_ANATOMY.Announce.Severed"))}</h3><p>${P(
    w("MONSTER_ANATOMY.Chat.SeverText", {
      part: t.name,
      actor: e.name,
      amount: String(n.amount)
    })
  )}</p>${a}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: r
  });
}
async function Mn(e, t) {
  if (e.effects.some((r) => {
    try {
      return r.getFlag(m, "partId") === t.id;
    } catch {
      return !1;
    }
  })) return;
  const a = {};
  a[m] = { partId: t.id, kind: "part-broken" }, await ActiveEffect.create(
    {
      name: w("MONSTER_ANATOMY.Effect.BrokenName", { part: t.name }),
      img: "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      flags: a
    },
    { parent: e }
  );
}
async function Tn(e, t) {
  if (e.effects.some((r) => {
    try {
      return r.getFlag(m, "partId") === t.id && r.getFlag(m, "kind") === "part-severed";
    } catch {
      return !1;
    }
  })) return;
  const a = {};
  a[m] = { partId: t.id, kind: "part-severed" }, await ActiveEffect.create(
    {
      name: w("MONSTER_ANATOMY.Effect.SeveredName", { part: t.name }),
      img: "systems/dnd5e/icons/svg/damage/slashing.svg",
      origin: e.uuid,
      disabled: !1,
      flags: a
    },
    { parent: e }
  );
}
const Be = "loot", Nn = 20;
async function Ze(e, t, n, a = {}) {
  const r = Me(t).filter((s) => s.onEvent === n);
  if (r.length === 0) return;
  const o = await Sn(e, a.attackerUuid), i = [];
  let c;
  for (const s of r) {
    if (s.kind === "item") {
      const l = await wn(e, o, s.uuid, s.draws);
      l && (i.push(s.draws > 1 ? `${l} ×${s.draws}` : l), o && (c = o.name));
      continue;
    }
    const u = await On(s.uuid);
    if (!u) {
      console.warn(`monster-anatomy | tabela não encontrada (${s.uuid})`);
      continue;
    }
    for (let l = 0; l < Math.min(Math.floor(s.draws), Nn); l++)
      try {
        const d = await u.draw({ displayChat: !1 });
        for (const N of d.results ?? []) {
          const y = kn(N);
          y && i.push(y);
        }
      } catch (d) {
        console.warn("monster-anatomy | falha no sorteio", d);
        break;
      }
  }
  i.length !== 0 && (await vn(e, {
    partId: t.id,
    partName: t.name,
    event: n,
    items: i,
    ...c ? { grantedTo: c } : {},
    at: Date.now()
  }), g("chatMessage") && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-loot"><h3>🎁 ${et(p("MONSTER_ANATOMY.Loot.Title"))}</h3><p>${et(
      w("MONSTER_ANATOMY.Loot.Text", {
        part: t.name,
        actor: e.name,
        items: i.join(", ")
      })
    )}</p></div>`
  }));
}
async function Sn(e, t) {
  const n = t && t !== e.uuid ? t : void 0;
  if (n) {
    const r = await Le(n);
    if (r instanceof Actor && r.uuid !== e.uuid) return r;
  }
  const a = game.user;
  if (a && !a.isGM) {
    const r = a.character;
    if (r instanceof Actor && r.uuid !== e.uuid) return r;
  }
  return null;
}
async function wn(e, t, n, a) {
  var i, c, s;
  const r = await Le(n);
  if (!(r instanceof Item))
    return console.warn(`monster-anatomy | item não encontrado (${n})`), null;
  const o = typeof r.name == "string" ? r.name : n;
  if (!t)
    return console.warn("monster-anatomy | sem atacante para entregar o item; registrado no pool"), o;
  try {
    const u = r.toObject() ?? {};
    delete u._id;
    const d = await t.createEmbeddedDocuments.call(t, "Item", [u]);
    if (a > 1 && ((i = d[0]) != null && i.update))
      try {
        await ((s = (c = d[0]).update) == null ? void 0 : s.call(c, { "system.quantity": a }));
      } catch {
      }
    return o;
  } catch (u) {
    return console.warn("monster-anatomy | falha ao criar item no recebedor", u), o;
  }
}
function St(e) {
  try {
    const t = e.getFlag(m, Be);
    return Array.isArray(t) ? t.filter((n) => n && Array.isArray(n.items)) : [];
  } catch {
    return [];
  }
}
async function bn(e) {
  await e.setFlag(m, Be, []);
}
async function vn(e, t) {
  const n = [...St(e), t].slice(-200);
  await e.setFlag(m, Be, n);
}
async function On(e) {
  const t = await Le(e);
  return t instanceof RollTable ? t : null;
}
async function Le(e) {
  try {
    return await fromUuid(e);
  } catch {
    return null;
  }
}
function kn(e) {
  const t = e;
  return typeof (t == null ? void 0 : t.name) == "string" && t.name ? t.name : typeof (t == null ? void 0 : t.text) == "string" && t.text ? t.text : typeof (t == null ? void 0 : t.id) == "string" && t.id ? t.id : "";
}
function et(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
const be = "system.attributes.hp.value";
async function wt(e, t, n, a = {}) {
  return Ne(e, t, [{ amount: n, type: a.type }], a);
}
async function Ne(e, t, n, a = {}) {
  const r = M(e).find((A) => A.id === t);
  if (!r) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  let o = 0, i = 0;
  const c = qt(r);
  for (const A of n) {
    const x = Math.max(0, Math.floor(Number(A == null ? void 0 : A.amount) || 0));
    x <= 0 || (o += x * Lt(r, A == null ? void 0 : A.type), c && typeof (A == null ? void 0 : A.type) == "string" && (r.severTypes ?? []).includes(A.type) && (i += x));
  }
  o = Math.floor(o);
  const s = r.state, u = xe(r);
  let l = 0, d = 0;
  if (G(s) && (u.mode === "percent" ? l = Math.max(0, Math.min(200, u.value)) : u.mode === "flat" ? d = Math.max(0, Math.floor(u.value)) : u.mode !== "off" && (l = Math.max(0, Math.min(200, Number(g("brokenBonus") ?? 0))))), l > 0 || d > 0) {
    const A = 1 + l / 100;
    o = Math.floor(o * A) + d, i = Math.floor(i * A) + d;
  }
  const N = Math.max(0, r.hp.value - o);
  let y = s;
  N <= 0 && r.breakable ? y = s === "severed" ? "severed" : "broken" : N < r.hp.max && s === "intact" && (y = "damaged"), await me(e, t, { hp: { ...r.hp, value: N }, state: y });
  let f = M(e).find((A) => A.id === t);
  const b = await En(e, o);
  Q(W.PART_DAMAGE, e, f, o, a.attacker ?? null);
  const h = y === "broken" && s !== "broken";
  let D = "";
  if (h) {
    await fn(e, f, { amount: o, attacker: a.attacker }), await Ze(e, f, "break", { attackerUuid: a.attackerUuid }), Q(W.PART_BREAK, e, f, o, a.attacker ?? null);
    const A = (f.phaseName ?? "").trim();
    A !== "" && (D = A, await ln(e, A), Mt(e, f, A), Q(W.PART_PHASE, e, f, A));
  }
  let z = !1;
  const F = f.sever ?? { value: f.hp.max, max: f.hp.max };
  if (c && i > 0 && f.state !== "severed") {
    const A = Math.max(0, F.value - i);
    await me(e, t, {
      sever: { value: A, max: F.max },
      ...A <= 0 ? { state: "severed" } : {}
    }), f = M(e).find((x) => x.id === t), A <= 0 && (z = !0, await pn(e, f, { amount: i, attacker: a.attacker }), await Ze(e, f, "sever", { attackerUuid: a.attackerUuid }), Q(W.PART_SEVER, e, f, i, a.attacker ?? null));
  }
  return { part: f, broke: h, severed: z, globalApplied: b, applied: o, bonus: l, bonusFlat: d, phased: D };
}
async function qe(e, t, n) {
  const a = Math.max(0, Math.floor(Number(n) || 0)), r = M(e).find((u) => u.id === t);
  if (!r) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = Math.min(r.hp.max, r.hp.value + a), i = o >= r.hp.max, c = i && (r.state === "damaged" || r.state === "broken") ? "intact" : r.state, s = r.sever ?? { value: r.hp.max, max: r.hp.max };
  return await me(e, t, {
    hp: { ...r.hp, value: o },
    state: c,
    ...i ? { sever: { value: s.max, max: s.max } } : {}
  }), M(e).find((u) => u.id === t);
}
async function En(e, t) {
  if (t <= 0) return 0;
  const n = g("damageModel");
  if (n === "independent") return 0;
  const a = n === "percent" ? Math.max(0, Math.min(100, Number(g("damagePercent") ?? 50))) : 100, r = Math.floor(t * a / 100);
  if (r <= 0) return 0;
  const o = foundry.utils.getProperty(e, be);
  if (typeof o != "number")
    return console.warn(`monster-anatomy | HP global não encontrado em ${be}`), 0;
  const i = Math.max(0, o - r);
  return await e.update({
    [be]: i
  }), r;
}
const { ApplicationV2: Rn, HandlebarsApplicationMixin: xn } = foundry.applications.api;
function _n(e, t) {
  const n = e.hp.max > 0 ? e.hp.value / e.hp.max * 100 : 0;
  return {
    id: e.id,
    img: e.img ?? "",
    name: e.name,
    state: e.state,
    stateLabel: p(ie[e.state]),
    acDisplay: t ? "??" : String(e.ac),
    hpValue: e.hp.value,
    hpMax: e.hp.max,
    hpPct: Math.max(0, Math.min(100, Math.round(n)))
  };
}
var $, ee, bt, vt;
const ne = class ne extends xn(Rn) {
  constructor(n, a) {
    super(n);
    V(this, ee);
    V(this, $, null);
    H(this, $, a);
  }
  /** Abre o seletor e resolve com o id da parte (null = normal/dispensado). */
  static pick(n) {
    return new Promise((a) => {
      var o;
      (o = foundry.applications.instances.get("monster-anatomy-target-map")) == null || o.close(), new ne({ actor: n }, a).render(!0);
    });
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.actor, o = fe(r) && !te();
    return {
      ...a,
      actorName: r.name,
      canAdd: k(r),
      parts: M(r).map((i) => _n(i, o))
    };
  }
  async _onRender(n, a) {
    var o, i;
    await super._onRender(n, a);
    const r = (c) => {
      if (!O(this, $)) return;
      const s = O(this, $);
      H(this, $, null), s(c), this.close();
    };
    (o = this.element.querySelector("[data-parts]")) == null || o.addEventListener("click", (c) => {
      const s = c.target.closest("[data-part-id]"), u = s == null ? void 0 : s.dataset.partId;
      u && r(u);
    }), (i = this.element.querySelector("[data-normal]")) == null || i.addEventListener("click", () => r(null)), ce(this, ee, bt).call(this);
  }
  async close(n) {
    if (O(this, $)) {
      const a = O(this, $);
      H(this, $, null), a(null);
    }
    return super.close(n);
  }
};
$ = new WeakMap(), ee = new WeakSet(), /** Quick-add: cria parte na hora (nome + imagem opcional) e atualiza a lista. */
bt = function() {
  var i, c;
  const n = this.element.querySelector('[data-qa="name"]'), a = this.element.querySelector('[data-qa="img"]'), r = this.element.querySelector('[data-qa="preview"]');
  if (!n || !a) return;
  const o = () => {
    if (!r) return;
    const s = a.value.trim();
    r.hidden = s === "", s !== "" && (r.src = s);
  };
  a.addEventListener("input", o), r == null || r.addEventListener("error", () => {
    r && (r.hidden = !0);
  }), (i = this.element.querySelector("[data-qa-browse]")) == null || i.addEventListener("click", () => {
    new foundry.applications.apps.FilePicker({
      type: "image",
      current: a.value,
      callback: (u) => {
        a.value = u, o();
      }
    }).render(!0);
  }), (c = this.element.querySelector("[data-qa-add]")) == null || c.addEventListener("click", () => {
    ce(this, ee, vt).call(this);
  });
}, vt = async function() {
  const n = this.actor;
  if (!k(n)) return;
  const a = this.element.querySelector('[data-qa="name"]'), r = this.element.querySelector('[data-qa="img"]');
  if (!a || !r) return;
  const o = M(n).length, i = a.value.trim() || `${p("MONSTER_ANATOMY.Part.New")} ${o + 1}`, c = Number(g("defaultAc") ?? 10), s = Number(g("defaultHp") ?? 20), u = le(i, {
    ac: Number.isFinite(c) ? c : 10,
    hp: Number.isFinite(s) ? s : 20
  }), l = r.value.trim();
  l !== "" && (u.img = l), await mt(n, u), a.value = "", r.value = "", await this.render();
}, _(ne, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-target-map",
  classes: ["monster-anatomy", "monster-anatomy-target"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Target.Title",
    icon: "fa-solid fa-crosshairs",
    resizable: !1
  },
  position: { width: 340, height: "auto" },
  actions: {}
}), _(ne, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/target-map.hbs" }
});
let ke = ne, C = null;
function Ot() {
  return C;
}
function Y() {
  C = null, kt();
}
function kt() {
  var i;
  if ((i = document.getElementById("monster-anatomy-aim")) == null || i.remove(), !C) return;
  const e = fromUuidSync(C.actorUuid), t = e instanceof Actor ? M(e).find((c) => c.id === (C == null ? void 0 : C.partId)) : void 0;
  if (!t) return;
  const n = document.createElement("button");
  n.type = "button", n.id = "monster-anatomy-aim", n.className = "monster-anatomy ma-aim-chip", n.title = p("MONSTER_ANATOMY.Target.AimClear");
  const a = document.createElement("i");
  a.className = "fa-solid fa-crosshairs";
  const r = document.createElement("span");
  r.textContent = w("MONSTER_ANATOMY.Target.Aiming", { part: t.name });
  const o = document.createElement("i");
  o.className = "fa-solid fa-xmark", n.append(a, r, o), n.addEventListener("click", () => Y()), document.body.append(n);
}
async function Et(e) {
  var l;
  const t = re(e), n = /* @__PURE__ */ new Set();
  t && n.add(t);
  let a;
  for (const d of ((l = game.user) == null ? void 0 : l.targets) ?? []) {
    const N = re(d);
    N && (n.add(N), (N === t || !t && n.size === 1) && (a = d));
  }
  if (n.size !== 1) {
    Y();
    return;
  }
  const r = [...n][0], o = t === r ? e : a, i = o == null ? void 0 : o.actor;
  if (!(i instanceof Actor)) {
    Y();
    return;
  }
  if (M(i).length === 0) {
    Y();
    return;
  }
  const s = await ke.pick(i);
  if (!s) {
    Y();
    return;
  }
  const u = M(i).find((d) => d.id === s);
  if (!u) {
    Y();
    return;
  }
  C = {
    tokenUuid: r,
    actorUuid: i.uuid,
    partId: u.id
  }, kt();
}
function Yn() {
  Hooks.on("targetToken", (e, t, n) => {
    var a;
    if (e.id === ((a = game.user) == null ? void 0 : a.id)) {
      if (!n) {
        C && re(t) === C.tokenUuid && Y();
        return;
      }
      if (!g("promptOnTarget")) {
        Y();
        return;
      }
      Et(t);
    }
  });
}
const { ApplicationV2: Pn, HandlebarsApplicationMixin: In } = foundry.applications.api;
var ye, Rt;
const B = class B extends In(Pn) {
  constructor() {
    super(...arguments);
    V(this, ye);
  }
  static async openFor(n, a, r) {
    const o = `monster-anatomy-editor-${n.uuid.replaceAll(".", "-")}-${a ?? "new"}`, i = foundry.applications.instances.get(o);
    if (i) {
      await i.render({ force: !0 }), i.bringToFront();
      return;
    }
    await new B({ id: o, actor: n, partId: a, onSaved: r }).render(!0);
  }
  get editorOptions() {
    return this.options;
  }
  get editing() {
    const { actor: n, partId: a } = this.editorOptions;
    if (a) {
      const i = M(n).find((c) => c.id === a);
      if (i) return Te(i);
    }
    const r = Number(g("defaultAc") ?? 10), o = Number(g("defaultHp") ?? 20);
    return le("", {
      ac: Number.isFinite(r) ? r : 10,
      hp: Number.isFinite(o) ? o : 20
    });
  }
  get isNew() {
    return !this.editorOptions.partId;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.editing, o = this.editorOptions.actor, i = ve(), c = (s) => {
      var u;
      return ((u = i.find((l) => l.key === s)) == null ? void 0 : u.label) ?? s;
    };
    return {
      ...a,
      part: r,
      isNew: this.isNew,
      actorName: o.name,
      link: K(r),
      sever: r.sever ?? { value: r.hp.max, max: r.hp.max },
      severTypes: r.severTypes ?? ["slashing"],
      rewards: Me(r).map((s) => ({ ...s })),
      items: [...o.items].flatMap(
        (s) => typeof s.id == "string" ? [{ id: s.id, label: `${s.name} (${s.type})` }] : []
      ),
      damageTypes: ve(),
      physicalTypes: Dt.map((s) => ({
        key: s,
        label: c(s),
        checked: (r.severTypes ?? ["slashing"]).includes(s)
      })),
      hitzones: i.map((s) => {
        var u;
        return {
          key: s.key,
          label: s.label,
          value: ((u = r.hitzone) == null ? void 0 : u[s.key]) ?? 1
        };
      }),
      statuses: (CONFIG.statusEffects ?? []).filter((s) => typeof (s == null ? void 0 : s.id) == "string").map((s) => ({ value: s.id, label: s.name ?? s.id })),
      states: Object.entries(ie).map(
        ([s, u]) => ({ value: s, label: p(u) })
      )
    };
  }
  async _onRender(n, a) {
    var i;
    await super._onRender(n, a), (i = this.element.querySelector("form.monster-anatomy-form")) == null || i.addEventListener("submit", (c) => void ce(this, ye, Rt).call(this, c));
    const r = this.element.querySelector("#ma-img"), o = this.element.querySelector(".ma-imgpreview");
    r == null || r.addEventListener("input", () => tt(r, o)), o == null || o.addEventListener("error", () => {
      o && (o.hidden = !0);
    });
  }
  static onBrowseImage(n, a) {
    const r = this, o = r.element.querySelector("#ma-img"), i = r.element.querySelector(".ma-imgpreview");
    new foundry.applications.apps.FilePicker({
      type: "image",
      current: (o == null ? void 0 : o.value) ?? "",
      callback: (s) => {
        o && (o.value = s, o.dispatchEvent(new Event("input", { bubbles: !0 }))), tt(o, i);
      }
    }).render(!0);
  }
  static onAddReward(n, a) {
    const o = this.element.querySelector("[data-rewards]");
    if (!o) return;
    const i = document.createElement("div");
    i.className = "ma-reward", i.setAttribute("data-reward", ""), i.setAttribute("data-reward-id", foundry.utils.randomID()), i.innerHTML = `<select name="rw_event" title="${p("MONSTER_ANATOMY.Editor.RewardEvent")}"><option value="break">${p("MONSTER_ANATOMY.Reward.Break")}</option><option value="sever">${p("MONSTER_ANATOMY.Reward.Sever")}</option></select><select name="rw_kind" title="${p("MONSTER_ANATOMY.Editor.RewardKind")}"><option value="table">${p("MONSTER_ANATOMY.Reward.TableKind")}</option><option value="item">${p("MONSTER_ANATOMY.Reward.ItemKind")}</option></select><input name="rw_table" type="text" placeholder="RollTable.xxx / Item.xxx" title="${p("MONSTER_ANATOMY.Editor.RewardTable")}" /><input name="rw_draws" type="number" min="1" max="20" step="1" value="1" title="${p("MONSTER_ANATOMY.Editor.RewardDraws")}" /><button type="button" data-action="remove-reward" title="${p("MONSTER_ANATOMY.Editor.RewardRemove")}"><i class="fa-solid fa-xmark"></i></button>`, o.appendChild(i);
  }
  static onRemoveReward(n, a) {
    var r;
    (r = a.closest("[data-reward]")) == null || r.remove();
  }
};
ye = new WeakSet(), Rt = async function(n) {
  var ze, Ve, Ge, Ke;
  n.preventDefault();
  const a = n.target, r = new FormData(a), o = (S) => String(r.get(S) ?? "").trim(), i = (S, E) => {
    const I = Number(r.get(S));
    return Number.isFinite(I) ? I : E;
  }, { actor: c, partId: s, onSaved: u } = this.editorOptions, l = s ? M(c).find((S) => S.id === s) : void 0, d = Math.max(1, Math.floor(i("hpMax", (l == null ? void 0 : l.hp.max) ?? 10))), N = Math.max(0, Math.floor(i("regen", (l == null ? void 0 : l.regen) ?? 0))), y = o("phaseName"), f = o("zone"), b = f === "head" || f === "torso" || f === "left" || f === "right" || f === "tail" ? f : (l == null ? void 0 : l.zone) ?? null, h = o("effectDuration"), D = o("disableItemId"), z = {
    disableItemId: D,
    disableItemName: ((ze = c.items.get(D)) == null ? void 0 : ze.name) ?? "",
    effectName: o("effectName"),
    effectIcon: o("effectIcon"),
    effectDuration: h === "" ? null : Math.max(0, Math.floor(i("effectDuration", 0))),
    condition: o("condition"),
    setAttrPath: o("setAttrPath"),
    setAttrValue: o("setAttrValue"),
    macroUuid: o("macroUuid")
  }, F = {};
  for (const { key: S } of ve()) {
    const E = r.get(`hz_${S}`);
    if (E == null) continue;
    const I = Number(E);
    !Number.isFinite(I) || I < 0 || I === 1 || !S || (F[S] = Math.round(I * 100) / 100);
  }
  const A = r.getAll("severType").filter((S) => typeof S == "string" && S !== ""), x = Math.max(
    1,
    Math.floor(i("severMax", ((Ve = l == null ? void 0 : l.sever) == null ? void 0 : Ve.max) ?? d))
  ), Se = ((Ge = l == null ? void 0 : l.sever) == null ? void 0 : Ge.value) ?? x, j = o("bonusMode"), Pt = {
    mode: j === "off" || j === "percent" || j === "flat" ? j : "inherit",
    value: Math.max(0, i("bonusValue", 0))
  }, Ue = [];
  a.querySelectorAll("[data-reward]").forEach((S) => {
    const E = ($t) => {
      var je, Je;
      return ((Je = (je = S.querySelector($t)) == null ? void 0 : je.value) == null ? void 0 : Je.trim()) ?? "";
    }, I = E('input[name="rw_table"]');
    if (!I) return;
    const It = E('select[name="rw_event"]'), Ht = E('select[name="rw_kind"]');
    Ue.push({
      id: S.dataset.rewardId || foundry.utils.randomID(),
      kind: Ht === "item" ? "item" : "table",
      uuid: I,
      draws: Math.max(1, Math.min(20, Math.floor(Number(E('input[name="rw_draws"]')) || 1))),
      onEvent: It === "sever" ? "sever" : "break"
    });
  });
  const J = {
    id: (l == null ? void 0 : l.id) ?? "",
    name: o("name"),
    img: o("img"),
    zone: b,
    ac: Math.max(0, Math.floor(i("ac", (l == null ? void 0 : l.ac) ?? 10))),
    hp: {
      max: d,
      value: Math.max(0, Math.min(d, Math.floor(i("hpValue", (l == null ? void 0 : l.hp.value) ?? d))))
    },
    breakable: r.get("breakable") === "on",
    severable: r.get("severable") === "on",
    state: o("state") || (l == null ? void 0 : l.state) || "intact",
    notes: o("notes"),
    regen: N,
    phaseName: y,
    onBreak: z,
    hitzone: F,
    sever: { value: Math.min(x, Se), max: x },
    severTypes: A,
    rewards: Ue,
    bonus: Pt
  };
  if (Kt(J).length > 0) {
    (Ke = ui.notifications) == null || Ke.error(p("MONSTER_ANATOMY.Editor.Invalid"));
    return;
  }
  if (l) {
    const { id: S, ...E } = J;
    await me(c, l.id, E);
  } else {
    const S = le(J.name || p("MONSTER_ANATOMY.Part.New"), {
      ac: J.ac,
      hp: J.hp.max
    });
    await mt(c, { ...S, ...J, id: S.id });
  }
  u == null || u(), await this.close();
}, _(B, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-part-editor",
  classes: ["monster-anatomy", "monster-anatomy-editor"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Editor.Title",
    icon: "fa-solid fa-pen-to-square",
    resizable: !1
  },
  position: { width: 460, height: "auto" },
  actions: {
    "add-reward": B.onAddReward,
    "remove-reward": B.onRemoveReward,
    "browse-image": B.onBrowseImage
  }
}), _(B, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/part-editor.hbs" }
});
let pe = B;
function tt(e, t) {
  var a;
  if (!t) return;
  const n = ((a = e == null ? void 0 : e.value) == null ? void 0 : a.trim()) ?? "";
  t.hidden = n === "", n !== "" && (t.src = n);
}
function ve() {
  var t;
  const e = (t = CONFIG == null ? void 0 : CONFIG.DND5E) == null ? void 0 : t.damageTypes;
  return e && typeof e == "object" ? Object.entries(e).map(([n, a]) => ({
    key: n,
    label: Hn(
      typeof a == "string" ? a : typeof (a == null ? void 0 : a.label) == "string" ? a.label : n
    )
  })) : [...Bt].map((n) => ({ key: n, label: n }));
}
function Hn(e) {
  try {
    return p(e);
  } catch {
    return e;
  }
}
const { ApplicationV2: $n, HandlebarsApplicationMixin: Cn } = foundry.applications.api;
var L;
const ae = class ae extends Cn($n) {
  constructor() {
    super(...arguments);
    V(this, L, null);
  }
  static async openFor(n) {
    const a = `monster-anatomy-tracker-${n.uuid.replaceAll(".", "-")}`, r = foundry.applications.instances.get(a);
    if (r) {
      await r.render({ force: !0 }), r.bringToFront();
      return;
    }
    await new ae({ id: a, actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = M(this.actor).map((o) => {
      const i = o.hp.max > 0 ? o.hp.value / o.hp.max * 100 : 0;
      return {
        ...o,
        hp: { ...o.hp },
        hpPct: Math.max(0, Math.min(100, Math.round(i))),
        stateLabel: p(ie[o.state])
      };
    });
    return {
      ...a,
      actorName: this.actor.name,
      parts: r,
      empty: r.length === 0
    };
  }
  async _onRender(n, a) {
    await super._onRender(n, a), O(this, L) === null && H(this, L, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(n) {
    return O(this, L) !== null && (Hooks.off("updateActor", O(this, L)), H(this, L, null)), super.close(n);
  }
};
L = new WeakMap(), _(ae, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-tracker",
  classes: ["monster-anatomy", "monster-anatomy-tracker"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Tracker.Title",
    icon: "fa-solid fa-heart-pulse",
    resizable: !0
  },
  position: { width: 320, height: "auto" },
  actions: {}
}), _(ae, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-tracker.hbs" }
});
let he = ae;
const { ApplicationV2: Fn, HandlebarsApplicationMixin: Dn } = foundry.applications.api;
var q;
const X = class X extends Dn(Fn) {
  constructor() {
    super(...arguments);
    V(this, q, null);
  }
  static async openFor(n) {
    const a = `monster-anatomy-summary-${n.uuid.replaceAll(".", "-")}`, r = foundry.applications.instances.get(a);
    if (r) {
      await r.render({ force: !0 }), r.bringToFront();
      return;
    }
    await new X({ id: a, actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.actor, o = M(r).map((c) => ({
      name: c.name,
      stateLabel: p(ie[c.state]),
      hp: `${c.hp.value} / ${c.hp.max}`
    })), i = St(r).map((c) => ({
      ...c,
      eventLabel: p(
        c.event === "sever" ? "MONSTER_ANATOMY.Reward.Sever" : "MONSTER_ANATOMY.Reward.Break"
      ),
      itemsText: c.items.join(", ")
    }));
    return {
      ...a,
      actorName: r.name,
      parts: o,
      loot: i,
      emptyParts: o.length === 0,
      emptyLoot: i.length === 0,
      canClear: k(r)
    };
  }
  async _onRender(n, a) {
    await super._onRender(n, a), O(this, q) === null && H(this, q, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(n) {
    return O(this, q) !== null && (Hooks.off("updateActor", O(this, q)), H(this, q, null)), super.close(n);
  }
  static async onClearLoot(n, a) {
    const r = this;
    k(r.actor) && await bn(r.actor);
  }
};
q = new WeakMap(), _(X, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-summary",
  classes: ["monster-anatomy", "monster-anatomy-summary"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Summary.Title",
    icon: "fa-solid fa-scroll",
    resizable: !0
  },
  position: { width: 460, height: "auto" },
  actions: {
    "clear-loot": X.onClearLoot
  }
}), _(X, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/loot-summary.hbs" }
});
let ge = X;
const { ApplicationV2: Bn, HandlebarsApplicationMixin: Ln } = foundry.applications.api;
function qn(e, t, n) {
  const a = e.hp.max > 0 ? e.hp.value / e.hp.max * 100 : 0, r = K(e).disableItemId.trim(), o = r ? t.items.get(r) : void 0, i = e.sever ?? { value: e.hp.max, max: e.hp.max }, c = i.max > 0 ? i.value / i.max * 100 : 0;
  return {
    ...e,
    hp: { ...e.hp },
    sever: { value: i.value, max: i.max },
    hpPct: Math.max(0, Math.min(100, Math.round(a))),
    stateLabel: p(ie[e.state]),
    hpMismatch: Gt(e) !== e.state,
    linkedItemName: (o == null ? void 0 : o.name) ?? r,
    linkedDisabled: r !== "" && G(e.state),
    severPct: Math.max(0, Math.min(100, Math.round(c))),
    acDisplay: n ? "??" : String(e.ac)
  };
}
function nt(e) {
  const t = e.closest(".ma-part"), n = t == null ? void 0 : t.querySelector("input.ma-amount"), a = Math.floor(Number(n == null ? void 0 : n.value));
  return Number.isFinite(a) && a > 0 ? a : null;
}
var U;
const v = class v extends Ln(Bn) {
  constructor() {
    super(...arguments);
    V(this, U, null);
  }
  /** Abre o painel para um Actor. */
  static async openFor(n) {
    const a = `monster-anatomy-panel-${n.uuid.replaceAll(".", "-")}`, r = foundry.applications.instances.get(a);
    if (r) {
      await r.render({ force: !0 }), r.bringToFront();
      return;
    }
    await new v({ id: a, actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.actor, o = te(), i = fe(r), c = i && !o, s = M(r).map((u) => qn(u, r, c));
    return {
      ...a,
      actorName: r.name,
      actorImg: r.img ?? "icons/svg/mystery-man.svg",
      canEdit: k(r),
      isGM: o,
      hideAc: i,
      phase: ht(r),
      templates: Ye().map((u) => ({ id: u.id, name: sn(u) })),
      parts: s,
      empty: s.length === 0
    };
  }
  async _onRender(n, a) {
    await super._onRender(n, a), O(this, U) === null && (H(this, U, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    })), Q(W.PANEL_RENDER, this));
  }
  async close(n) {
    return O(this, U) !== null && (Hooks.off("updateActor", O(this, U)), H(this, U, null)), super.close(n);
  }
  // -- actions (this = instância, injetado pelo ApplicationV2) -----------------
  static async onAddPart(n, a) {
    const r = this;
    k(r.actor) && await pe.openFor(r.actor, void 0, () => void r.render());
  }
  static async onDuplicatePart(n, a) {
    const r = this;
    if (!k(r.actor)) return;
    const o = a.dataset.partId;
    o && await dt(r.actor, o);
  }
  static async onEditPart(n, a) {
    const r = this;
    if (!k(r.actor)) return;
    const o = a.dataset.partId;
    o && await pe.openFor(r.actor, o, () => void r.render());
  }
  static async onOpenTracker(n, a) {
    const r = this;
    await he.openFor(r.actor);
  }
  static async onOpenSummary(n, a) {
    const r = this;
    await ge.openFor(r.actor);
  }
  static async onDamagePart(n, a) {
    const r = this;
    if (!k(r.actor)) return;
    const o = a.dataset.partId, i = nt(a);
    !o || i === null || await wt(r.actor, o, i);
  }
  static async onHealPart(n, a) {
    const r = this;
    if (!k(r.actor)) return;
    const o = a.dataset.partId, i = nt(a);
    !o || i === null || await qe(r.actor, o, i);
  }
  static async onDeletePart(n, a) {
    const r = this;
    if (!k(r.actor)) return;
    const o = a.dataset.partId, i = M(r.actor).find((s) => s.id === o);
    !o || !i || !await foundry.applications.api.DialogV2.confirm({
      window: { title: p("MONSTER_ANATOMY.Delete.Title") },
      content: `<p>${w("MONSTER_ANATOMY.Delete.Prompt", { name: i.name })}</p>`,
      modal: !0
    }) || await on(r.actor, o);
  }
  static async onApplyTemplate(n, a) {
    var c, s;
    const r = this;
    if (!k(r.actor)) return;
    const o = ((c = a.parentElement) == null ? void 0 : c.querySelector("select.ma-template-select")) ?? r.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (i)
      try {
        const u = await pt(r.actor, i), l = it(r.actor), d = i.startsWith("builtin-") && l.hp !== null && l.ac !== null;
        (s = ui.notifications) == null || s.info(
          d ? w("MONSTER_ANATOMY.Template.AppliedScaled", {
            count: String(u),
            hp: String(l.hp),
            ac: String(l.ac)
          }) : w("MONSTER_ANATOMY.Template.Applied", { count: String(u) })
        );
      } catch (u) {
        console.warn("monster-anatomy | falha ao aplicar modelo", u);
      }
  }
  static async onSaveTemplate(n, a) {
    var c, s;
    const r = this;
    if (!te()) return;
    const o = M(r.actor);
    if (o.length === 0) {
      (c = ui.notifications) == null || c.warn(p("MONSTER_ANATOMY.Template.Empty"));
      return;
    }
    const i = await Un(r.actor.name);
    i && (await cn(i, o), (s = ui.notifications) == null || s.info(w("MONSTER_ANATOMY.Template.Saved", { name: i })), r.render());
  }
  static async onDeleteTemplate(n, a) {
    var s, u;
    const r = this;
    if (!te()) return;
    const o = r.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (!i) return;
    if (!await un(i)) {
      (s = ui.notifications) == null || s.warn(p("MONSTER_ANATOMY.Template.Protected"));
      return;
    }
    (u = ui.notifications) == null || u.info(p("MONSTER_ANATOMY.Template.Deleted")), r.render();
  }
  static async onToggleHideAc(n, a) {
    const r = this;
    te() && await mn(r.actor, !fe(r.actor));
  }
};
U = new WeakMap(), _(v, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-panel",
  classes: ["monster-anatomy", "monster-anatomy-panel"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Panel.Title",
    icon: "fa-solid fa-dragon",
    resizable: !0
  },
  position: { width: 500, height: "auto" },
  actions: {
    "add-part": v.onAddPart,
    "edit-part": v.onEditPart,
    "delete-part": v.onDeletePart,
    "duplicate-part": v.onDuplicatePart,
    "open-tracker": v.onOpenTracker,
    "open-summary": v.onOpenSummary,
    "damage-part": v.onDamagePart,
    "heal-part": v.onHealPart,
    "apply-template": v.onApplyTemplate,
    "save-template": v.onSaveTemplate,
    "delete-template": v.onDeleteTemplate,
    "toggle-hide-ac": v.onToggleHideAc
  }
}), _(v, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-panel.hbs" }
});
let Ee = v;
async function Un(e) {
  const t = await foundry.applications.api.DialogV2.wait({
    window: { title: p("MONSTER_ANATOMY.Template.NameTitle") },
    content: `<div class="form-group"><label>${p("MONSTER_ANATOMY.Template.NamePrompt")}</label><input name="templateName" type="text" value="${e}" maxlength="80" /></div>`,
    buttons: [
      {
        action: "save",
        label: p("MONSTER_ANATOMY.Editor.Save"),
        default: !0,
        callback: (n, a) => {
          var o, i;
          const r = (o = a.form) == null ? void 0 : o.querySelector(
            'input[name="templateName"]'
          );
          return ((i = r == null ? void 0 : r.value) == null ? void 0 : i.trim()) ?? "";
        }
      }
    ],
    modal: !0
  });
  return typeof t != "string" || t.trim() === "" ? null : t.trim();
}
function zn() {
  var t, n;
  return {
    version: ((n = (t = game.modules) == null ? void 0 : t.get(m)) == null ? void 0 : n.version) ?? "0.0.0",
    async openAnatomy(a) {
      await Ee.openFor(a);
    },
    getParts(a) {
      return M(a);
    },
    canEdit(a) {
      return k(a);
    },
    damagePart(a, r, o, i) {
      return wt(a, r, o, i);
    },
    healPart(a, r, o) {
      return qe(a, r, o);
    },
    damagePartDetailed(a, r, o, i) {
      return Ne(a, r, o, i);
    },
    getSelection() {
      return Ot();
    },
    clearSelection() {
      Y();
    },
    promptTargetSelection(a) {
      return Et(a);
    },
    openTracker(a) {
      return he.openFor(a);
    },
    openSummary(a) {
      return ge.openFor(a);
    },
    on(a, r) {
      const o = a.startsWith("monsterAnatomy.") ? a : `monsterAnatomy.${a}`, i = ue(o, r);
      return () => jt(o, i);
    },
    getTemplates() {
      return Ye();
    },
    applyTemplate(a, r) {
      return pt(a, r);
    },
    duplicatePart(a, r) {
      return dt(a, r);
    }
  };
}
function Vn(e) {
  globalThis.MonsterAnatomy = e;
}
function R(e) {
  return typeof e == "string" ? e : "";
}
function Gn(e) {
  if (!Array.isArray(e)) return [];
  const t = [];
  for (const n of e) {
    if (!n || typeof n != "object") continue;
    const a = Math.max(0, Math.floor(Number(n.amount) || 0));
    if (a <= 0) continue;
    const r = n.type;
    t.push(typeof r == "string" && r ? { amount: a, type: r } : { amount: a });
  }
  return t;
}
function Kn() {
  var e;
  return ((e = game.users) == null ? void 0 : e.some((t) => t.isGM && t.active)) ?? !1;
}
function jn(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function Jn() {
  var e;
  (e = game.socket) == null || e.on(`module.${m}`, (t) => {
    Wn(t);
  });
}
async function Wn(e) {
  var n, a, r;
  if (!e || typeof e != "object") return;
  const t = e;
  if (t.t === "apply") {
    if (!((n = game.user) != null && n.isActiveGM)) return;
    const o = await fromUuid(
      R(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = typeof t.attacker == "string" ? t.attacker : void 0, c = typeof t.attackerUuid == "string" ? t.attackerUuid : void 0, s = await Ne(
      o,
      R(t.partId),
      Gn(t.components),
      { attacker: i, attackerUuid: c }
    );
    await Nt(
      o,
      ((a = M(o).find((u) => u.id === R(t.partId))) == null ? void 0 : a.name) ?? R(t.partId),
      s.applied,
      s.globalApplied,
      s.bonus,
      s.bonusFlat
    ), s.broke && Z(R(t.actorUuid), R(t.partId), "break"), s.severed && Z(R(t.actorUuid), R(t.partId), "sever"), s.phased !== "" && Z(R(t.actorUuid), R(t.partId), "phase");
  } else if (t.t === "present") {
    if (typeof t.by == "string" && t.by === ((r = game.user) == null ? void 0 : r.id)) return;
    const o = await fromUuid(
      R(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = M(o).find((c) => c.id === R(t.partId));
    if (!i) return;
    t.kind === "sever" ? yt(o, i) : t.kind === "phase" ? Mt(o, i, ht(o) || "?") : At(o, i);
  }
}
function xt(e) {
  var t;
  try {
    (t = game.socket) == null || t.emit(`module.${m}`, e);
  } catch (n) {
    console.warn("monster-anatomy | falha no socket", n);
  }
}
function Qn(e, t, n, a, r) {
  var i;
  const o = { t: "apply", actorUuid: e, partId: t, components: n, attacker: a, attackerUuid: r, by: (i = game.user) == null ? void 0 : i.id };
  xt(o);
}
function Z(e, t, n = "break") {
  var r;
  const a = { t: "present", actorUuid: e, partId: t, kind: n, by: (r = game.user) == null ? void 0 : r.id };
  xt(a);
}
let Ae = null;
function Xn() {
  ue("dnd5e.rollAttackV2", (...e) => void ea(e)), ue("dnd5e.rollDamageV2", (...e) => void ta(e)), ue("dnd5e.preUseActivity", (...e) => Zn(e)), Hooks.on("targetToken", (e, t, n) => {
    var a;
    e.id === ((a = game.user) == null ? void 0 : a.id) && (Ae = null);
  });
}
function Zn(e) {
  var i;
  const [t] = e, n = t == null ? void 0 : t.item, a = t == null ? void 0 : t.actor, r = a instanceof Actor ? a : (n == null ? void 0 : n.parent) instanceof Actor ? n.parent : void 0;
  if (!r || typeof (n == null ? void 0 : n.id) != "string" || !Jt(r).has(n.id)) return;
  const o = Wt(r, n.id);
  return (i = ui.notifications) == null || i.warn(
    w("MONSTER_ANATOMY.Usage.Blocked", {
      item: typeof n.name == "string" ? n.name : n.id,
      part: (o == null ? void 0 : o.name) ?? "",
      actor: r.name
    })
  ), !1;
}
async function ea(e) {
  var D, z;
  const t = Ot();
  if (!t) return;
  const n = [...((D = game.user) == null ? void 0 : D.targets) ?? []], a = n.length === 1 ? n[0] : void 0, r = re(a), o = a == null ? void 0 : a.actor;
  if (!a || !r || !o || r !== t.tokenUuid || o.uuid !== t.actorUuid) {
    Y();
    return;
  }
  const [i, c] = e, s = i == null ? void 0 : i[0], u = Number((s == null ? void 0 : s.total) ?? NaN);
  if (!Number.isFinite(u)) return;
  const l = aa(s), d = l === 20, N = l === 1, y = M(o).find((F) => F.id === t.partId);
  if (!y) {
    Y();
    return;
  }
  const f = d || !N && u >= y.ac, b = ra(c == null ? void 0 : c.subject), h = (b == null ? void 0 : b.name) ?? ((z = game.user) == null ? void 0 : z.name) ?? "?";
  if (Ae = {
    tokenUuid: r,
    actorUuid: o.uuid,
    partId: y.id,
    hit: f,
    crit: d,
    attacker: h,
    attackerUuid: b == null ? void 0 : b.uuid
  }, g("attackNotes")) {
    const F = f ? "MONSTER_ANATOMY.Attack.Hit" : "MONSTER_ANATOMY.Attack.Miss", A = d && f ? ` ${p("MONSTER_ANATOMY.Attack.CritSuffix")}` : "", x = fe(o) ? "??" : String(y.ac), Se = `<div class="monster-anatomy-chat ma-attack"><p>${w(F, {
      attacker: h,
      part: y.name,
      actor: o.name,
      total: String(u),
      ac: x
    })}${A}</p></div>`, j = b ? ChatMessage.getSpeaker({ actor: b }) : ChatMessage.getSpeaker({ alias: h });
    await ChatMessage.create({ speaker: j, content: Se });
  }
}
async function ta(e) {
  var c, s, u, l;
  const t = Ae;
  if (Ae = null, !(t != null && t.hit)) return;
  const [n] = e, a = (n ?? []).map((d) => ({ amount: Number(d == null ? void 0 : d.total) || 0, type: na(d) })).filter((d) => d.amount > 0);
  if (a.length === 0) return;
  const r = [...((c = game.user) == null ? void 0 : c.targets) ?? []].find((d) => re(d) === t.tokenUuid), o = r == null ? void 0 : r.actor;
  if (!o || o.uuid !== t.actorUuid) return;
  const i = ((s = M(o).find((d) => d.id === t.partId)) == null ? void 0 : s.name) ?? t.partId;
  if (jn(o)) {
    const d = await Ne(o, t.partId, a, {
      attacker: t.attacker,
      attackerUuid: t.attackerUuid
    });
    await Nt(o, i, d.applied, d.globalApplied, d.bonus, d.bonusFlat), d.broke && Z(o.uuid, t.partId, "break"), d.severed && Z(o.uuid, t.partId, "sever"), d.phased !== "" && Z(o.uuid, t.partId, "phase");
  } else Kn() ? (Qn(o.uuid, t.partId, a, t.attacker, t.attackerUuid), (u = ui.notifications) == null || u.info(w("MONSTER_ANATOMY.Target.SentToGM", { part: i }))) : (l = ui.notifications) == null || l.warn(p("MONSTER_ANATOMY.Target.NoGM"));
}
function na(e) {
  var a, r;
  const t = e;
  if (typeof ((a = t.options) == null ? void 0 : a.type) == "string" && t.options.type) return t.options.type;
  const n = (r = t.options) == null ? void 0 : r.types;
  if (Array.isArray(n) && typeof n[0] == "string" && n[0]) return n[0];
}
function aa(e) {
  var n;
  const t = e == null ? void 0 : e.dice;
  if (Array.isArray(t))
    for (const a of t) {
      if ((a == null ? void 0 : a.faces) !== 20) continue;
      const r = a == null ? void 0 : a.results;
      if (!Array.isArray(r)) continue;
      const o = (n = r[0]) == null ? void 0 : n.result;
      if (typeof o == "number") return o;
    }
}
function ra(e) {
  const t = e == null ? void 0 : e.actor;
  return t instanceof Actor ? t : void 0;
}
function oa() {
  Hooks.on("combatTurnChange", (e, t, n) => {
    var c;
    if (!((c = game.user) != null && c.isActiveGM)) return;
    const a = t, r = n;
    if (a && r) {
      const s = a.round ?? 0, u = r.round ?? 0;
      if (u < s || u === s && (r.turn ?? 0) < (a.turn ?? 0)) return;
    }
    const o = r != null && r.combatantId ? e.combatants.get(r.combatantId) : void 0, i = o == null ? void 0 : o.actor;
    i instanceof Actor && ia(i);
  });
}
async function ia(e) {
  const t = M(e).filter(
    (r) => (r.regen ?? 0) > 0 && r.hp.value < r.hp.max && r.state !== "destroyed"
  );
  if (t.length === 0) return;
  const n = [];
  for (const r of t)
    try {
      const o = Math.max(1, Math.floor(r.regen ?? 0)), i = r.hp.value, c = await qe(e, r.id, o), s = c.hp.value - i;
      s > 0 && n.push(`${c.name} +${s}`);
    } catch (o) {
      console.warn("monster-anatomy | falha na regeneração", o);
    }
  if (n.length === 0) return;
  let a = !1;
  try {
    a = g("chatMessage") === !0;
  } catch {
    return;
  }
  a && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-regen"><p>${w("MONSTER_ANATOMY.Regen.Text", {
      actor: e.name,
      bits: n.join(", ")
    })}</p></div>`
  });
}
function sa() {
  Yn(), Xn(), oa();
}
function ca() {
  game.settings.register(m, "showHeaderButton", {
    name: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "defaultAc", {
    name: "MONSTER_ANATOMY.Settings.DefaultAc.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultAc.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 10
  }), game.settings.register(m, "defaultHp", {
    name: "MONSTER_ANATOMY.Settings.DefaultHp.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultHp.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 20
  }), game.settings.register(m, "damageModel", {
    name: "MONSTER_ANATOMY.Settings.DamageModel.Name",
    hint: "MONSTER_ANATOMY.Settings.DamageModel.Hint",
    scope: "world",
    config: !0,
    type: String,
    choices: {
      independent: "MONSTER_ANATOMY.Settings.DamageModel.Independent",
      shared: "MONSTER_ANATOMY.Settings.DamageModel.Shared",
      percent: "MONSTER_ANATOMY.Settings.DamageModel.Percent"
    },
    default: "shared"
  }), game.settings.register(m, "damagePercent", {
    name: "MONSTER_ANATOMY.Settings.DamagePercent.Name",
    hint: "MONSTER_ANATOMY.Settings.DamagePercent.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 100, step: 5 },
    default: 50
  }), game.settings.register(m, "brokenBonus", {
    name: "MONSTER_ANATOMY.Settings.BrokenBonus.Name",
    hint: "MONSTER_ANATOMY.Settings.BrokenBonus.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 200, step: 5 },
    default: 50
  }), game.settings.register(m, "showAnnouncement", {
    name: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "announceDuration", {
    name: "MONSTER_ANATOMY.Settings.AnnounceDuration.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceDuration.Hint",
    scope: "client",
    config: !0,
    type: Number,
    range: { min: 0.5, max: 10, step: 0.5 },
    default: 2.5
  }), game.settings.register(m, "chatMessage", {
    name: "MONSTER_ANATOMY.Settings.ChatMessage.Name",
    hint: "MONSTER_ANATOMY.Settings.ChatMessage.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "tokenEffect", {
    name: "MONSTER_ANATOMY.Settings.TokenEffect.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenEffect.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "breakSound", {
    name: "MONSTER_ANATOMY.Settings.BreakSound.Name",
    hint: "MONSTER_ANATOMY.Settings.BreakSound.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "promptOnTarget", {
    name: "MONSTER_ANATOMY.Settings.PromptOnTarget.Name",
    hint: "MONSTER_ANATOMY.Settings.PromptOnTarget.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "attackNotes", {
    name: "MONSTER_ANATOMY.Settings.AttackNotes.Name",
    hint: "MONSTER_ANATOMY.Settings.AttackNotes.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "announceTheme", {
    name: "MONSTER_ANATOMY.Settings.AnnounceTheme.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceTheme.Hint",
    scope: "client",
    config: !0,
    type: String,
    choices: {
      celestial: "MONSTER_ANATOMY.Settings.AnnounceTheme.Celestial",
      persona: "MONSTER_ANATOMY.Settings.AnnounceTheme.Persona",
      monsterhunter: "MONSTER_ANATOMY.Settings.AnnounceTheme.MonsterHunter",
      jrpg: "MONSTER_ANATOMY.Settings.AnnounceTheme.Jrpg",
      minimal: "MONSTER_ANATOMY.Settings.AnnounceTheme.Minimal",
      impact: "MONSTER_ANATOMY.Settings.AnnounceTheme.Impact",
      arcade: "MONSTER_ANATOMY.Settings.AnnounceTheme.Arcade",
      carved: "MONSTER_ANATOMY.Settings.AnnounceTheme.Carved"
    },
    default: "celestial"
  }), game.settings.register(m, "customKickerBreak", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "customKickerSever", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerSever.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerSever.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(m, "tokenShake", {
    name: "MONSTER_ANATOMY.Settings.TokenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "screenFlash", {
    name: "MONSTER_ANATOMY.Settings.ScreenFlash.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenFlash.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "reducedMotion", {
    name: "MONSTER_ANATOMY.Settings.ReducedMotion.Name",
    hint: "MONSTER_ANATOMY.Settings.ReducedMotion.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !1
  }), game.settings.register(m, "particles", {
    name: "MONSTER_ANATOMY.Settings.Particles.Name",
    hint: "MONSTER_ANATOMY.Settings.Particles.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "screenShake", {
    name: "MONSTER_ANATOMY.Settings.ScreenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(m, "templatesJson", {
    name: "MONSTER_ANATOMY.Settings.TemplatesJson.Name",
    hint: "MONSTER_ANATOMY.Settings.TemplatesJson.Hint",
    scope: "world",
    config: !1,
    type: String,
    default: "[]"
  });
}
function _t(e) {
  const t = e == null ? void 0 : e.document;
  return t instanceof Actor ? t : void 0;
}
function Yt() {
  try {
    return g("showHeaderButton");
  } catch {
    return !0;
  }
}
function at(e, t) {
  const n = _t(e);
  !n || !Array.isArray(t) || !Yt() || t.some((a) => (a == null ? void 0 : a.action) === "monster-anatomy") || t.unshift({
    action: "monster-anatomy",
    label: "MONSTER_ANATOMY.Panel.OpenButton",
    icon: "fa-solid fa-dragon",
    onClick: () => {
      var a;
      (a = ct()) == null || a.openAnatomy(n);
    }
  });
}
function ua() {
  Hooks.on("getHeaderControlsActorSheetV2", (...e) => {
    at(e[0], e[1]);
  }), Hooks.on("getHeaderControlsApplicationV2", (...e) => {
    at(e[0], e[1]);
  }), Hooks.on("getActorSheetHeaderButtons", (...e) => {
    const [t, n] = e, a = _t(t) ?? (t == null ? void 0 : t.actor);
    if (!(a instanceof Actor) || !Array.isArray(n) || !Yt()) return;
    const r = a;
    n.unshift({
      class: "monster-anatomy-open",
      icon: "fas fa-dragon",
      label: "MONSTER_ANATOMY.Panel.OpenButton",
      onclick: () => {
        var o;
        (o = ct()) == null || o.openAnatomy(r);
      }
    });
  });
}
async function la() {
  await foundry.applications.handlebars.loadTemplates([
    "modules/monster-anatomy/templates/anatomy-panel.hbs",
    "modules/monster-anatomy/templates/anatomy-tracker.hbs",
    "modules/monster-anatomy/templates/loot-summary.hbs",
    "modules/monster-anatomy/templates/part-editor.hbs",
    "modules/monster-anatomy/templates/target-map.hbs"
  ]);
}
function Oe(e, t) {
  try {
    t();
  } catch (n) {
    console.error(`${m} | falha no init (${e})`, n);
  }
}
Hooks.once("init", () => {
  var n;
  console.log(`${m} | init`), Oe("settings", ca), Oe("header", ua), Oe("combat", sa);
  const e = zn(), t = (n = game.modules) == null ? void 0 : n.get(m);
  t && (t.api = e), Vn(e), la();
});
Hooks.once("setup", () => {
  console.log(`${m} | setup`);
});
Hooks.once("ready", () => {
  var e, t;
  console.log(`${m} | ready (v${((t = (e = game.modules) == null ? void 0 : e.get(m)) == null ? void 0 : t.version) ?? "?"})`), Jn();
});
//# sourceMappingURL=main.js.map
