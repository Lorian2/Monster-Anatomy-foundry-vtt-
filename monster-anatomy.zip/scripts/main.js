var qt = Object.defineProperty;
var Ze = (e) => {
  throw TypeError(e);
};
var Ut = (e, t, n) => t in e ? qt(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n;
var _ = (e, t, n) => Ut(e, typeof t != "symbol" ? t + "" : t, n), we = (e, t, n) => t.has(e) || Ze("Cannot " + n);
var O = (e, t, n) => (we(e, t, "read from private field"), n ? n.call(e) : t.get(e)), G = (e, t, n) => t.has(e) ? Ze("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, n), D = (e, t, n, a) => (we(e, t, "write to private field"), a ? a.call(e, n) : t.set(e, n), n), me = (e, t, n) => (we(e, t, "access private method"), n);
const d = "monster-anatomy", st = d, ct = "parts", W = {
  /** Disparado quando o painel de anatomia termina de renderizar. */
  PANEL_RENDER: "monsterAnatomy.panelRender",
  /** Disparado após criar/atualizar/remover uma parte. */
  PARTS_CHANGED: "monsterAnatomy.partsChanged",
  /** Disparado após aplicar dano a uma parte (sempre, mesmo sem quebra). */
  PART_DAMAGE: "monsterAnatomy.partDamage",
  /** Disparado na transição para quebrado (uma vez por transição). */
  PART_BREAK: "monsterAnatomy.partBreak",
  /** Disparado na transição para cortado (uma vez por transição). */
  PART_SEVER: "monsterAnatomy.partSever",
  /** Disparado ao entrar em fase (nome da fase). */
  PART_PHASE: "monsterAnatomy.phaseChange"
}, _e = { mode: "inherit", value: 0 };
function Ye(e) {
  const t = e.bonus;
  if (!t || typeof t != "object") return { ..._e };
  const n = t.mode === "off" || t.mode === "percent" || t.mode === "flat" ? t.mode : "inherit", a = Number.isFinite(Number(t.value)) ? Math.max(0, Number(t.value)) : 0;
  return { mode: n, value: a };
}
function Te(e) {
  if (!Array.isArray(e.rewards)) return [];
  const t = [];
  for (const n of e.rewards) {
    if (!n || typeof n != "object") continue;
    const a = n, r = typeof a.uuid == "string" && a.uuid.trim() !== "" ? a.uuid.trim() : typeof a.tableUuid == "string" ? a.tableUuid.trim() : "";
    r !== "" && t.push({
      id: typeof a.id == "string" && a.id !== "" ? a.id : foundry.utils.randomID(),
      kind: a.kind === "item" ? "item" : "table",
      uuid: r,
      draws: Math.max(1, Math.min(20, Math.floor(Number(a.draws) || 1))),
      onEvent: a.onEvent === "sever" ? "sever" : "break"
    });
  }
  return t;
}
const zt = ["slashing", "piercing", "bludgeoning"], Gt = [
  "slashing",
  "piercing",
  "bludgeoning",
  "fire",
  "cold",
  "lightning",
  "thunder",
  "acid",
  "poison",
  "psychic",
  "necrotic",
  "radiant",
  "force"
];
function Vt(e, t) {
  var a;
  if (!t) return 1;
  const n = (a = e.hitzone) == null ? void 0 : a[t];
  return typeof n == "number" && Number.isFinite(n) && n >= 0 ? n : 1;
}
function Kt(e) {
  return e.severable && (e.severTypes ?? []).length > 0;
}
function V(e) {
  return e === "broken" || e === "severed";
}
const ce = {
  disableItemId: "",
  disableItemName: "",
  effectName: "",
  effectIcon: "",
  effectDuration: null,
  condition: "",
  setAttrPath: "",
  setAttrValue: "",
  macroUuid: ""
};
function K(e) {
  return { ...ce, ...e.onBreak ?? {} };
}
function jt(e, t, n, a) {
  return {
    id: foundry.utils.randomID(),
    name: e,
    parts: t.map((r) => {
      var o;
      return {
        name: r.name,
        img: r.img ?? "",
        ac: r.ac,
        hpMax: r.hp.max,
        breakable: r.breakable,
        severable: r.severable,
        regen: Math.max(0, Math.floor(r.regen ?? 0)),
        phaseName: typeof r.phaseName == "string" ? r.phaseName : "",
        hitzone: { ...r.hitzone ?? {} },
        severMax: ((o = r.sever) == null ? void 0 : o.max) ?? r.hp.max,
        severTypes: [...r.severTypes ?? ["slashing"]],
        onBreak: K(r),
        rewards: Te(r).map((i) => ({ ...i })),
        bonus: Ye(r)
      };
    })
  };
}
function ut(e) {
  const t = (n) => {
    const a = foundry.utils.getProperty(e, n);
    return typeof a == "number" && Number.isFinite(a) && a > 0 ? a : null;
  };
  return { hp: t("system.attributes.hp.max"), ac: t("system.attributes.ac.value") };
}
function Jt(e, t) {
  const n = ut(t);
  return e.parts.map((a) => {
    const r = typeof a.hpPct == "number" && n.hp !== null ? Math.round(n.hp * a.hpPct / 100) : null, o = Math.max(1, Math.floor(r ?? a.hpMax)), i = typeof a.acDelta == "number" && n.ac !== null ? n.ac + a.acDelta : a.ac, c = de(a.name || "Nova parte", {
      ac: Math.max(0, Math.floor(i)),
      hp: o
    });
    c.img = typeof a.img == "string" ? a.img : "", c.regen = Math.max(0, Math.floor(a.regen || 0)), c.phaseName = typeof a.phaseName == "string" ? a.phaseName : "", c.breakable = a.breakable !== !1, c.severable = a.severable === !0, c.hitzone = { ...a.hitzone ?? {} };
    const s = a.hpMax > 0 ? a.severMax / a.hpMax : 1, u = Math.max(
      1,
      Math.floor(r !== null ? o * s : a.severMax || o)
    );
    c.sever = { value: u, max: u }, c.severTypes = [...a.severTypes ?? ["slashing"]], c.onBreak = { ...ce, ...a.onBreak ?? {} }, c.rewards = (a.rewards ?? []).map((f) => ({ ...f })), c.bonus = { ..._e, ...a.bonus ?? {} };
    const l = c.onBreak.disableItemName.trim(), m = l ? [...t.items].find((f) => f.name === l) : void 0, N = !m && c.onBreak.disableItemId.trim() ? t.items.get(c.onBreak.disableItemId.trim()) : void 0, y = m ?? N;
    return c.onBreak.disableItemId = typeof (y == null ? void 0 : y.id) == "string" ? y.id : "", c.onBreak.disableItemName = typeof (y == null ? void 0 : y.name) == "string" ? y.name : l, c;
  });
}
function T(e, t, n, a = {}) {
  const r = Math.max(1, Math.round(320 * t / 100));
  return {
    name: e,
    ac: 19 + n,
    hpMax: r,
    hpPct: t,
    acDelta: n,
    breakable: !0,
    severable: !1,
    hitzone: {},
    severMax: r,
    severTypes: ["slashing"],
    onBreak: { ...ce },
    rewards: [],
    ...a
  };
}
const Wt = [
  {
    id: "builtin-dragonoid",
    name: "MONSTER_ANATOMY.Template.Dragonoid",
    builtin: !0,
    map: "dragonoid",
    parts: [
      T("Cabeça", 25, 2, { hitzone: { bludgeoning: 1.5, piercing: 0.8 } }),
      T("Corpo", 40, 0),
      T("Asa Esquerda", 20, 1),
      T("Asa Direita", 20, 1),
      T("Cauda", 22, 3, {
        severable: !0,
        severMax: Math.round(320 * 22 / 100 * 0.57),
        onBreak: { ...ce, disableItemName: "Tail Swipe" }
      })
    ]
  },
  {
    id: "builtin-humanoid",
    name: "MONSTER_ANATOMY.Template.Humanoid",
    builtin: !0,
    map: "humanoid",
    parts: [
      T("Cabeça", 20, 2, { hitzone: { bludgeoning: 1.5 } }),
      T("Corpo", 35, 0),
      T("Braço Esquerdo", 15, 0),
      T("Braço Direito", 15, 0),
      T("Perna Esquerda", 18, 0),
      T("Perna Direita", 18, 0)
    ]
  },
  {
    id: "builtin-quadruped",
    name: "MONSTER_ANATOMY.Template.Quadruped",
    builtin: !0,
    map: "dragonoid",
    parts: [
      T("Cabeça", 22, 2, { hitzone: { bludgeoning: 1.5 } }),
      T("Corpo", 40, 0),
      T("Pata Dianteira Esquerda", 15, 1),
      T("Pata Dianteira Direita", 15, 1),
      T("Pata Traseira Esquerda", 15, 1),
      T("Pata Traseira Direita", 15, 1),
      T("Cauda", 15, 2, { severable: !0, severMax: Math.round(320 * 15 / 100 * 0.6) })
    ]
  },
  {
    id: "builtin-serpent",
    name: "MONSTER_ANATOMY.Template.Serpent",
    builtin: !0,
    map: "dragonoid",
    parts: [
      T("Cabeça", 25, 2, { hitzone: { bludgeoning: 1.5 } }),
      T("Corpo", 45, 0),
      T("Cauda", 25, 1, { severable: !0, severMax: Math.round(320 * 25 / 100 * 0.6) })
    ]
  },
  {
    id: "builtin-avian",
    name: "MONSTER_ANATOMY.Template.Avian",
    builtin: !0,
    map: "dragonoid",
    parts: [
      T("Cabeça", 20, 2, { hitzone: { bludgeoning: 1.5 } }),
      T("Corpo", 35, 0),
      T("Asa Esquerda", 20, 1),
      T("Asa Direita", 20, 1),
      T("Pata Esquerda", 15, 1),
      T("Pata Direita", 15, 1)
    ]
  }
], ue = {
  intact: "MONSTER_ANATOMY.State.Intact",
  damaged: "MONSTER_ANATOMY.State.Damaged",
  broken: "MONSTER_ANATOMY.State.Broken",
  severed: "MONSTER_ANATOMY.State.Severed",
  destroyed: "MONSTER_ANATOMY.State.Destroyed"
};
let et = 0;
function lt() {
  et += 1;
  const e = Math.random().toString(36).slice(2, 8);
  return `part-${Date.now().toString(36)}-${e}-${et}`;
}
function de(e, t) {
  const n = Math.max(1, Math.floor(t.hp));
  return {
    id: lt(),
    name: e.trim(),
    ac: Math.max(0, Math.floor(t.ac)),
    hp: { value: n, max: n },
    breakable: !0,
    severable: !1,
    state: "intact",
    notes: "",
    img: "",
    zone: null,
    regen: 0,
    phaseName: "",
    onBreak: { ...ce },
    hitzone: {},
    sever: { value: n, max: n },
    severTypes: ["slashing"],
    rewards: [],
    bonus: { ..._e }
  };
}
function Qt(e) {
  return e.hp.value <= 0 && e.breakable ? "broken" : e.hp.value < e.hp.max ? "damaged" : "intact";
}
function Xt(e) {
  var n;
  const t = [];
  return (n = e.name) != null && n.trim() || t.push("name"), (e.ac === void 0 || !Number.isFinite(e.ac) || e.ac < 0) && t.push("ac"), (e.hp === void 0 || !Number.isFinite(e.hp.max) || e.hp.max < 1) && t.push("hp.max"), e.hp !== void 0 && (!Number.isFinite(e.hp.value) || e.hp.value < 0) && t.push("hp.value"), t;
}
function Ne(e) {
  return {
    ...e,
    hp: { ...e.hp },
    onBreak: K(e),
    hitzone: { ...e.hitzone ?? {} },
    sever: e.sever ? { ...e.sever } : { value: e.hp.max, max: e.hp.max },
    severTypes: [...e.severTypes ?? ["slashing"]],
    rewards: Te(e).map((t) => ({ ...t })),
    bonus: Ye(e)
  };
}
function p(e) {
  var t;
  return ((t = game.i18n) == null ? void 0 : t.localize(e)) ?? e;
}
function S(e, t) {
  var n;
  return ((n = game.i18n) == null ? void 0 : n.format(e, t)) ?? e;
}
function h(e) {
  return game.settings.get(d, e);
}
function se(e) {
  if (!e || typeof e != "object") return;
  const t = e;
  if (typeof t.uuid == "string" && t.uuid) return t.uuid;
  if (t.document && typeof t.document == "object") {
    const n = t.document.uuid;
    if (typeof n == "string" && n) return n;
  }
}
function mt() {
  var e, t;
  return (t = (e = game.modules) == null ? void 0 : e.get(d)) == null ? void 0 : t.api;
}
function Q(e, ...t) {
  Hooks.callAll.call(Hooks, e, ...t);
}
function ae(e, t) {
  return Hooks.on.call(Hooks, e, t);
}
function Zt(e, t) {
  Hooks.off.call(Hooks, e, t);
}
const Pe = "attrBackup";
function en(e) {
  const t = /* @__PURE__ */ new Set();
  for (const n of dt(e)) {
    if (!V(n.state)) continue;
    const a = K(n).disableItemId.trim();
    a && t.add(a);
  }
  return t;
}
function tn(e, t) {
  return dt(e).find(
    (n) => V(n.state) && K(n).disableItemId.trim() === t
  );
}
function dt(e) {
  const t = e.getFlag(d, "parts");
  return Array.isArray(t) ? t : [];
}
async function nn(e, t) {
  const n = K(t);
  n.effectName.trim() && await an(e, t, n.effectName.trim(), n), n.condition.trim() && await rn(e, t, n.condition.trim()), n.setAttrPath.trim() && await on(e, t, n), n.macroUuid.trim() && await cn(n.macroUuid.trim());
}
async function tt(e, t) {
  for (const n of [...e.effects])
    try {
      if (n.getFlag(d, "partId") !== t.id) continue;
      const a = n.getFlag(d, "kind");
      (a === "break-effect" || a === "break-condition" || a === "part-broken" || a === "part-severed") && await n.delete();
    } catch (a) {
      console.warn("monster-anatomy | falha ao remover efeito da parte", a);
    }
  await sn(e, t.id);
}
async function an(e, t, n, a) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(d, "partId") === t.id && i.getFlag(d, "kind") === "break-effect";
    } catch {
      return !1;
    }
  })) return;
  const o = {};
  o[d] = { partId: t.id, kind: "break-effect" }, await ActiveEffect.create(
    {
      name: n,
      img: a.effectIcon.trim() || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      duration: typeof a.effectDuration == "number" ? { rounds: a.effectDuration } : void 0,
      flags: o
    },
    { parent: e }
  );
}
async function rn(e, t, n) {
  if (e.effects.some((i) => {
    try {
      return i.getFlag(d, "partId") === t.id && i.getFlag(d, "kind") === "break-condition";
    } catch {
      return !1;
    }
  })) return;
  const r = CONFIG.statusEffects.find(
    (i) => (i == null ? void 0 : i.id) === n
  ), o = {};
  o[d] = { partId: t.id, kind: "break-condition" }, await ActiveEffect.create(
    {
      name: S("MONSTER_ANATOMY.Effect.ConditionName", {
        status: (r == null ? void 0 : r.name) ?? n,
        part: t.name
      }),
      img: (r == null ? void 0 : r.img) || "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      statuses: [n],
      flags: o
    },
    { parent: e }
  );
}
async function on(e, t, n) {
  const a = n.setAttrPath.trim(), r = ft(e);
  t.id in r || (r[t.id] = { [a]: foundry.utils.getProperty(e, a) }, await e.setFlag(d, Pe, r)), await e.update({
    [a]: un(n.setAttrValue)
  });
}
async function sn(e, t) {
  const n = ft(e), a = n[t];
  if (!a) return;
  const r = {};
  for (const [o, i] of Object.entries(a)) r[o] = i;
  delete n[t];
  try {
    await e.update(r);
  } catch (o) {
    console.warn("monster-anatomy | falha ao restaurar atributo", o);
  }
  await e.setFlag(d, Pe, n);
}
function ft(e) {
  try {
    const t = e.getFlag(d, Pe);
    if (t && typeof t == "object" && !Array.isArray(t))
      return JSON.parse(JSON.stringify(t));
  } catch {
  }
  return {};
}
async function cn(e) {
  try {
    const n = await fromUuid(e);
    typeof (n == null ? void 0 : n.execute) == "function" ? await n.execute() : console.warn(`monster-anatomy | macro não encontrada (${e})`);
  } catch (t) {
    console.warn(`monster-anatomy | falha ao executar macro (${e})`, t);
  }
}
function un(e) {
  const t = e.trim();
  return t === "true" ? !0 : t === "false" ? !1 : t !== "" && Number.isFinite(Number(t)) ? Number(t) : e;
}
function M(e) {
  const t = e.getFlag(st, ct);
  return Array.isArray(t) ? t.map((n) => ({ ...n, hp: { ...n.hp } })) : [];
}
async function le(e, t) {
  var a;
  if (!e.isOwner)
    throw (a = ui.notifications) == null || a.warn(p("MONSTER_ANATOMY.Errors.NoPermission")), new Error("monster-anatomy: actor não editável pelo usuário atual");
  const n = M(e);
  await e.setFlag(st, ct, t.map(Ne)), await ln(e, n, t), Q(W.PARTS_CHANGED, e, M(e));
}
async function ln(e, t, n) {
  var o;
  const a = new Map(t.map((i) => [i.id, i])), r = new Set(n.map((i) => i.id));
  for (const i of n) {
    const c = V(((o = a.get(i.id)) == null ? void 0 : o.state) ?? "intact"), s = V(i.state);
    if (s !== c)
      try {
        s ? await nn(e, i) : await tt(e, i);
      } catch (u) {
        console.warn("monster-anatomy | falha na vinculação de ruptura", u);
      }
  }
  for (const i of t)
    if (!(r.has(i.id) || !V(i.state)))
      try {
        await tt(e, i);
      } catch (c) {
        console.warn("monster-anatomy | falha na limpeza de ruptura", c);
      }
}
async function pt(e, t) {
  const n = M(e);
  if (n.some((a) => a.id === t.id))
    throw new Error(`monster-anatomy: id de parte duplicado (${t.id})`);
  n.push(Ne(t)), await le(e, n);
}
async function fe(e, t, n) {
  const a = M(e), r = a.findIndex((i) => i.id === t);
  if (r < 0) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = a[r];
  a[r] = {
    ...o,
    ...n,
    id: o.id,
    // id é imutável (§5.1 do design)
    hp: { ...o.hp, ...n.hp ?? {} }
  }, await le(e, a);
}
async function mn(e, t) {
  const n = M(e).filter((a) => a.id !== t);
  await le(e, n);
}
async function ht(e, t) {
  const n = M(e), a = n.find((o) => o.id === t);
  if (!a) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const r = {
    ...Ne(a),
    id: lt(),
    name: `${a.name}${p("MONSTER_ANATOMY.Panel.CopySuffix")}`
  };
  return n.push(r), await le(e, n), r;
}
function E(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function re() {
  var e;
  return ((e = game.user) == null ? void 0 : e.isGM) === !0;
}
function dn(e) {
  const t = e.name.startsWith("MONSTER_ANATOMY.") ? p(e.name) : e.name;
  return e.builtin ? `${t} ${p("MONSTER_ANATOMY.Template.BuiltinTag")}` : t;
}
function Ie() {
  return [...Wt, ...pe()];
}
function pe() {
  try {
    const e = h("templatesJson");
    if (typeof e != "string" || e.trim() === "") return [];
    const t = JSON.parse(e);
    return Array.isArray(t) ? t.filter(
      (n) => !!n && typeof n == "object" && typeof n.id == "string"
    ) : [];
  } catch {
    return [];
  }
}
async function gt(e) {
  await game.settings.set(d, "templatesJson", JSON.stringify(e));
}
async function fn(e, t, n, a) {
  const r = jt(e, t);
  return await gt([...pe(), r]), r;
}
async function pn(e) {
  if (e.startsWith("builtin-")) return !1;
  const t = pe().filter((n) => n.id !== e);
  return t.length === pe().length ? !1 : (await gt(t), !0);
}
async function At(e, t) {
  const n = Ie().find((r) => r.id === t);
  if (!n) throw new Error(`monster-anatomy: modelo não encontrado (${t})`);
  const a = Jt(n, e);
  return await le(e, [...M(e), ...a]), n.map && await e.setFlag(d, "mapLayout", n.map), typeof n.mapImage == "string" && n.mapImage !== "" && await e.setFlag(d, "mapImage", n.mapImage), a.length;
}
function yt(e) {
  try {
    const t = e.getFlag(d, "phase");
    return typeof t == "string" ? t : "";
  } catch {
    return "";
  }
}
async function hn(e, t) {
  await e.setFlag(d, "phase", t);
}
function he(e) {
  try {
    return e.getFlag(d, "hideAc") === !0;
  } catch {
    return !1;
  }
}
async function gn(e, t) {
  await e.setFlag(d, "hideAc", t);
}
function De() {
  var e;
  try {
    if (h("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function An(e) {
  if (De()) return;
  const t = e.textContent ?? "";
  if (t.length === 0 || t.length > 24) return;
  e.textContent = "";
  let n = 0;
  for (const a of Array.from(t)) {
    if (a === " ") {
      e.appendChild(document.createTextNode(" "));
      continue;
    }
    const r = document.createElement("span");
    r.className = "ma-letter", r.textContent = a, r.style.setProperty("--i", String(n)), e.appendChild(r), n++;
  }
}
function He(e) {
  try {
    if (h("particles") !== !0 || De() || document.hidden) return;
  } catch {
    return;
  }
  const t = document.createElement("canvas");
  t.className = "monster-anatomy-particles";
  const n = Math.min(2, window.devicePixelRatio || 1);
  t.width = Math.floor(window.innerWidth * n), t.height = Math.floor(window.innerHeight * n), document.body.appendChild(t);
  const a = t.getContext("2d");
  if (!a) {
    t.remove();
    return;
  }
  a.scale(n, n);
  const r = window.innerWidth / 2, o = window.innerHeight / 2 - window.innerHeight * 0.06;
  let i = !1;
  try {
    i = String(h("announceTheme") ?? "celestial") === "celestial";
  } catch {
  }
  const c = i ? e ? ["#00f0ff", "#e8fdff", "#4dd0e0", "#00606a", "#ffffff"] : ["#f4d068", "#fffdf5", "#ffe9a3", "#b88a1e", "#ff2a54"] : e ? ["#9adcff", "#e8f7ff", "#4da6d8", "#0e4d64", "#ffffff"] : ["#ff3b3b", "#ffb454", "#fff3d6", "#7a1a00", "#1a1a1a"], s = [], u = 90;
  for (let y = 0; y < u; y++) {
    const f = Math.random() * Math.PI * 2, v = 180 + Math.random() * 560, g = 0.7 + Math.random() * 0.6;
    s.push({
      x: r + (Math.random() - 0.5) * 60,
      y: o + (Math.random() - 0.5) * 30,
      vx: Math.cos(f) * v,
      vy: Math.sin(f) * v - 160,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 14,
      size: 3 + Math.random() * 8,
      life: g,
      maxLife: g,
      color: c[Math.floor(Math.random() * c.length)],
      circle: Math.random() < 0.3
    });
  }
  const l = 900;
  let m = performance.now();
  const N = (y) => {
    const f = Math.min(0.05, (y - m) / 1e3);
    m = y, a.clearRect(0, 0, window.innerWidth, window.innerHeight);
    let v = !1;
    for (const g of s)
      g.life -= f, !(g.life <= 0) && (v = !0, g.vy += l * f, g.x += g.vx * f, g.y += g.vy * f, g.rot += g.vr * f, a.save(), a.globalAlpha = Math.max(0, g.life / g.maxLife), a.translate(g.x, g.y), a.rotate(g.rot), a.fillStyle = g.color, g.circle ? (a.beginPath(), a.arc(0, 0, g.size / 2, 0, Math.PI * 2), a.fill()) : a.fillRect(-g.size / 2, -g.size / 4, g.size, g.size / 2), a.restore());
    v ? requestAnimationFrame(N) : t.remove();
  };
  requestAnimationFrame(N);
}
function Ce() {
  try {
    if (h("screenShake") !== !0 || De()) return;
  } catch {
    return;
  }
  const e = document.getElementById("board");
  if (!e) return;
  const t = 11, n = 380, a = performance.now(), r = (o) => {
    const i = o - a;
    if (i >= n) {
      e.style.transform = "";
      return;
    }
    const c = 1 - i / n, s = Math.sin(o / 17) * t * c, u = Math.cos(o / 23) * t * 0.7 * c;
    e.style.transform = `translate(${s.toFixed(1)}px, ${u.toFixed(1)}px)`, requestAnimationFrame(r);
  };
  requestAnimationFrame(r);
}
async function yn(e, t, n) {
  h("showAnnouncement") && Tt(e, t), h("chatMessage") && await Sn(e, t, n), h("tokenEffect") && await vn(e, t), await Mt();
}
async function Mn(e, t, n) {
  h("showAnnouncement") && Nt(e, t), h("chatMessage") && await bn(e, t, n), h("tokenEffect") && await wn(e, t), await Mt();
}
async function Mt() {
  const e = String(h("breakSound") ?? "").trim();
  if (e)
    try {
      await foundry.audio.AudioHelper.play({ src: e, volume: 0.8 });
    } catch (t) {
      console.warn(`monster-anatomy | falha ao tocar som (${e})`, t);
    }
}
function P(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function Tt(e, t) {
  const n = Math.max(0.5, Math.min(10, Number(h("announceDuration") ?? 2.5)));
  Be(e, t, n, !1), Fe(!1), Le(e), He(!1), Ce();
}
function Nt(e, t) {
  const n = Math.max(0.5, Math.min(10, Number(h("announceDuration") ?? 2.5)));
  Be(e, t, n, !0), Fe(!0), Le(e), He(!0), Ce();
}
function St(e, t, n) {
  const a = Math.max(0.5, Math.min(10, Number(h("announceDuration") ?? 2.5)));
  Be(e, t, a, !1, n, "is-phase"), Fe(!1), Le(e), He(!1), Ce();
}
function $e() {
  var e;
  try {
    if (h("reducedMotion") === !0) return !0;
  } catch {
  }
  return ((e = window.matchMedia) == null ? void 0 : e.call(window, "(prefers-reduced-motion: reduce)").matches) === !0;
}
function bt() {
  const e = String(h("announceTheme") ?? "celestial");
  return e === "celestial" || e === "monsterhunter" || e === "jrpg" || e === "minimal" || e === "impact" || e === "arcade" || e === "carved" ? e : "celestial";
}
function Tn(e) {
  const t = String(
    h(e ? "customKickerSever" : "customKickerBreak") ?? ""
  ).trim();
  return t !== "" ? t : p(e ? "MONSTER_ANATOMY.Announce.Severed" : "MONSTER_ANATOMY.Announce.Break");
}
function Be(e, t, n, a, r, o) {
  document.querySelectorAll(".monster-anatomy-announce").forEach((u) => u.remove());
  const i = document.createElement("div");
  i.className = `monster-anatomy-announce theme-${bt()}` + (a ? " is-sever" : "") + (o ? ` ${o}` : ""), i.style.setProperty("--ma-duration", `${n}s`), $e() && i.classList.add("is-reduced");
  const c = (r ?? "") !== "" ? r : Tn(a);
  i.innerHTML = `<div class="ma-announce-band"></div><div class="ma-announce-kicker">${P(c)}</div><div class="ma-announce-part">${P(t.name)}</div><div class="ma-announce-actor">${P(e.name)}</div>`, document.body.appendChild(i);
  const s = i.querySelector(".ma-announce-kicker");
  s && An(s), requestAnimationFrame(() => i.classList.add("is-showing")), window.setTimeout(() => {
    i.classList.remove("is-showing"), window.setTimeout(() => i.remove(), 450);
  }, Math.max(400, Math.round(n * 1e3)));
}
function Fe(e) {
  try {
    if (h("screenFlash") !== !0 || $e()) return;
  } catch {
    return;
  }
  const t = document.createElement("div");
  t.className = `monster-anatomy-flash theme-${bt()}` + (e ? " is-sever" : ""), document.body.appendChild(t), requestAnimationFrame(() => t.classList.add("is-showing")), window.setTimeout(() => t.classList.remove("is-showing"), 120), window.setTimeout(() => t.remove(), 450);
}
function Le(e) {
  try {
    if (h("tokenShake") !== !0 || $e()) return;
  } catch {
    return;
  }
  try {
    const t = e.getActiveTokens();
    for (const n of t) {
      const a = n == null ? void 0 : n.mesh;
      Nn(a);
    }
  } catch {
  }
}
function Nn(e) {
  const t = e == null ? void 0 : e.position;
  if (!t || typeof t.x != "number" || typeof t.y != "number") return;
  const n = t.x, a = t.y, r = 9, o = 420, i = performance.now(), c = typeof t.set == "function" ? t.set.bind(t) : null, s = (l, m) => {
    c ? c(l, m) : (t.x = l, t.y = m);
  }, u = (l) => {
    const m = l - i;
    if (m >= o) {
      s(n, a);
      return;
    }
    const N = 1 - m / o;
    s(n + Math.sin(l / 16) * r * N, a), requestAnimationFrame(u);
  };
  requestAnimationFrame(u);
}
async function Sn(e, t, n) {
  const a = n.attacker ? `<p class="ma-chat-attacker">${P(
    S("MONSTER_ANATOMY.Chat.BreakBy", {
      attacker: n.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", r = `<div class="monster-anatomy-chat ma-break"><h3>💥 ${P(p("MONSTER_ANATOMY.Announce.Break"))}</h3><p>${P(
    S("MONSTER_ANATOMY.Chat.BreakText", {
      part: t.name,
      actor: e.name,
      amount: String(n.amount)
    })
  )}</p>${a}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: r
  });
}
async function vt(e, t, n, a, r = 0, o = 0) {
  let i = !1;
  try {
    i = h("attackNotes") === !0;
  } catch {
    return;
  }
  if (!i) return;
  const c = [];
  r > 0 && c.push(`+${r}%`), o > 0 && c.push(`+${o}`);
  const s = c.length > 0 ? ` ${S("MONSTER_ANATOMY.Routed.Bonus", { mark: c.join(" ") })}` : "";
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-routed"><p>${P(
      S("MONSTER_ANATOMY.Routed.Text", {
        amount: String(n),
        part: t,
        actor: e.name,
        global: String(a)
      })
    )}${P(s)}</p></div>`
  });
}
async function bn(e, t, n) {
  const a = n.attacker ? `<p class="ma-chat-attacker">${P(
    S("MONSTER_ANATOMY.Chat.SeverBy", {
      attacker: n.attacker,
      part: t.name,
      actor: e.name
    })
  )}</p>` : "", r = `<div class="monster-anatomy-chat ma-break ma-sever"><h3>🗡️ ${P(p("MONSTER_ANATOMY.Announce.Severed"))}</h3><p>${P(
    S("MONSTER_ANATOMY.Chat.SeverText", {
      part: t.name,
      actor: e.name,
      amount: String(n.amount)
    })
  )}</p>${a}</div>`;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: r
  });
}
async function vn(e, t) {
  if (e.effects.some((r) => {
    try {
      return r.getFlag(d, "partId") === t.id;
    } catch {
      return !1;
    }
  })) return;
  const a = {};
  a[d] = { partId: t.id, kind: "part-broken" }, await ActiveEffect.create(
    {
      name: S("MONSTER_ANATOMY.Effect.BrokenName", { part: t.name }),
      img: "icons/svg/skull.svg",
      origin: e.uuid,
      disabled: !1,
      flags: a
    },
    { parent: e }
  );
}
async function wn(e, t) {
  if (e.effects.some((r) => {
    try {
      return r.getFlag(d, "partId") === t.id && r.getFlag(d, "kind") === "part-severed";
    } catch {
      return !1;
    }
  })) return;
  const a = {};
  a[d] = { partId: t.id, kind: "part-severed" }, await ActiveEffect.create(
    {
      name: S("MONSTER_ANATOMY.Effect.SeveredName", { part: t.name }),
      img: "systems/dnd5e/icons/svg/damage/slashing.svg",
      origin: e.uuid,
      disabled: !1,
      flags: a
    },
    { parent: e }
  );
}
const qe = "loot", On = 20;
async function nt(e, t, n, a = {}) {
  const r = Te(t).filter((s) => s.onEvent === n);
  if (r.length === 0) return;
  const o = await kn(e, a.attackerUuid), i = [];
  let c;
  for (const s of r) {
    if (s.kind === "item") {
      const l = await En(e, o, s.uuid, s.draws);
      l && (i.push(s.draws > 1 ? `${l} ×${s.draws}` : l), o && (c = o.name));
      continue;
    }
    const u = await _n(s.uuid);
    if (!u) {
      console.warn(`monster-anatomy | tabela não encontrada (${s.uuid})`);
      continue;
    }
    for (let l = 0; l < Math.min(Math.floor(s.draws), On); l++)
      try {
        const m = await u.draw({ displayChat: !1 });
        for (const N of m.results ?? []) {
          const y = Yn(N);
          y && i.push(y);
        }
      } catch (m) {
        console.warn("monster-anatomy | falha no sorteio", m);
        break;
      }
  }
  i.length !== 0 && (await xn(e, {
    partId: t.id,
    partName: t.name,
    event: n,
    items: i,
    ...c ? { grantedTo: c } : {},
    at: Date.now()
  }), h("chatMessage") && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-loot"><h3>🎁 ${at(p("MONSTER_ANATOMY.Loot.Title"))}</h3><p>${at(
      S("MONSTER_ANATOMY.Loot.Text", {
        part: t.name,
        actor: e.name,
        items: i.join(", ")
      })
    )}</p></div>`
  }));
}
async function kn(e, t) {
  const n = t && t !== e.uuid ? t : void 0;
  if (n) {
    const r = await Ue(n);
    if (r instanceof Actor && r.uuid !== e.uuid) return r;
  }
  const a = game.user;
  if (a && !a.isGM) {
    const r = a.character;
    if (r instanceof Actor && r.uuid !== e.uuid) return r;
  }
  return null;
}
async function En(e, t, n, a) {
  var i, c, s;
  const r = await Ue(n);
  if (!(r instanceof Item))
    return console.warn(`monster-anatomy | item não encontrado (${n})`), null;
  const o = typeof r.name == "string" ? r.name : n;
  if (!t)
    return console.warn("monster-anatomy | sem atacante para entregar o item; registrado no pool"), o;
  try {
    const u = r.toObject() ?? {};
    delete u._id;
    const m = await t.createEmbeddedDocuments.call(t, "Item", [u]);
    if (a > 1 && ((i = m[0]) != null && i.update))
      try {
        await ((s = (c = m[0]).update) == null ? void 0 : s.call(c, { "system.quantity": a }));
      } catch {
      }
    return o;
  } catch (u) {
    return console.warn("monster-anatomy | falha ao criar item no recebedor", u), o;
  }
}
function wt(e) {
  try {
    const t = e.getFlag(d, qe);
    return Array.isArray(t) ? t.filter((n) => n && Array.isArray(n.items)) : [];
  } catch {
    return [];
  }
}
async function Rn(e) {
  await e.setFlag(d, qe, []);
}
async function xn(e, t) {
  const n = [...wt(e), t].slice(-200);
  await e.setFlag(d, qe, n);
}
async function _n(e) {
  const t = await Ue(e);
  return t instanceof RollTable ? t : null;
}
async function Ue(e) {
  try {
    return await fromUuid(e);
  } catch {
    return null;
  }
}
function Yn(e) {
  const t = e;
  return typeof (t == null ? void 0 : t.name) == "string" && t.name ? t.name : typeof (t == null ? void 0 : t.text) == "string" && t.text ? t.text : typeof (t == null ? void 0 : t.id) == "string" && t.id ? t.id : "";
}
function at(e) {
  return e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
const Oe = "system.attributes.hp.value";
async function Ot(e, t, n, a = {}) {
  return Se(e, t, [{ amount: n, type: a.type }], a);
}
async function Se(e, t, n, a = {}) {
  const r = M(e).find((A) => A.id === t);
  if (!r) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  let o = 0, i = 0;
  const c = Kt(r);
  for (const A of n) {
    const x = Math.max(0, Math.floor(Number(A == null ? void 0 : A.amount) || 0));
    x <= 0 || (o += x * Vt(r, A == null ? void 0 : A.type), c && typeof (A == null ? void 0 : A.type) == "string" && (r.severTypes ?? []).includes(A.type) && (i += x));
  }
  o = Math.floor(o);
  const s = r.state, u = Ye(r);
  let l = 0, m = 0;
  if (V(s) && (u.mode === "percent" ? l = Math.max(0, Math.min(200, u.value)) : u.mode === "flat" ? m = Math.max(0, Math.floor(u.value)) : u.mode !== "off" && (l = Math.max(0, Math.min(200, Number(h("brokenBonus") ?? 0))))), l > 0 || m > 0) {
    const A = 1 + l / 100;
    o = Math.floor(o * A) + m, i = Math.floor(i * A) + m;
  }
  const N = Math.max(0, r.hp.value - o);
  let y = s;
  N <= 0 && r.breakable ? y = s === "severed" ? "severed" : "broken" : N < r.hp.max && s === "intact" && (y = "damaged"), await fe(e, t, { hp: { ...r.hp, value: N }, state: y });
  let f = M(e).find((A) => A.id === t);
  const v = await Pn(e, o);
  Q(W.PART_DAMAGE, e, f, o, a.attacker ?? null);
  const g = y === "broken" && s !== "broken";
  let B = "";
  if (g) {
    await yn(e, f, { amount: o, attacker: a.attacker }), await nt(e, f, "break", { attackerUuid: a.attackerUuid }), Q(W.PART_BREAK, e, f, o, a.attacker ?? null);
    const A = (f.phaseName ?? "").trim();
    A !== "" && (B = A, await hn(e, A), St(e, f, A), Q(W.PART_PHASE, e, f, A));
  }
  let z = !1;
  const $ = f.sever ?? { value: f.hp.max, max: f.hp.max };
  if (c && i > 0 && f.state !== "severed") {
    const A = Math.max(0, $.value - i);
    await fe(e, t, {
      sever: { value: A, max: $.max },
      ...A <= 0 ? { state: "severed" } : {}
    }), f = M(e).find((x) => x.id === t), A <= 0 && (z = !0, await Mn(e, f, { amount: i, attacker: a.attacker }), await nt(e, f, "sever", { attackerUuid: a.attackerUuid }), Q(W.PART_SEVER, e, f, i, a.attacker ?? null));
  }
  return { part: f, broke: g, severed: z, globalApplied: v, applied: o, bonus: l, bonusFlat: m, phased: B };
}
async function ze(e, t, n) {
  const a = Math.max(0, Math.floor(Number(n) || 0)), r = M(e).find((u) => u.id === t);
  if (!r) throw new Error(`monster-anatomy: parte não encontrada (${t})`);
  const o = Math.min(r.hp.max, r.hp.value + a), i = o >= r.hp.max, c = i && (r.state === "damaged" || r.state === "broken") ? "intact" : r.state, s = r.sever ?? { value: r.hp.max, max: r.hp.max };
  return await fe(e, t, {
    hp: { ...r.hp, value: o },
    state: c,
    ...i ? { sever: { value: s.max, max: s.max } } : {}
  }), M(e).find((u) => u.id === t);
}
async function Pn(e, t) {
  if (t <= 0) return 0;
  const n = h("damageModel");
  if (n === "independent") return 0;
  const a = n === "percent" ? Math.max(0, Math.min(100, Number(h("damagePercent") ?? 50))) : 100, r = Math.floor(t * a / 100);
  if (r <= 0) return 0;
  const o = foundry.utils.getProperty(e, Oe);
  if (typeof o != "number")
    return console.warn(`monster-anatomy | HP global não encontrado em ${Oe}`), 0;
  const i = Math.max(0, o - r);
  return await e.update({
    [Oe]: i
  }), r;
}
const { ApplicationV2: In, HandlebarsApplicationMixin: Dn } = foundry.applications.api;
var L;
const oe = class oe extends Dn(In) {
  constructor() {
    super(...arguments);
    G(this, L, null);
  }
  static async openFor(n) {
    const a = `monster-anatomy-tracker-${n.uuid.replaceAll(".", "-")}`, r = foundry.applications.instances.get(a);
    if (r) {
      await r.render({ force: !0 }), r.bringToFront();
      return;
    }
    await new oe({ id: a, actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = M(this.actor).map((o) => {
      const i = o.hp.max > 0 ? o.hp.value / o.hp.max * 100 : 0;
      return {
        ...o,
        hp: { ...o.hp },
        hpPct: Math.max(0, Math.min(100, Math.round(i))),
        stateLabel: p(ue[o.state])
      };
    });
    return {
      ...a,
      actorName: this.actor.name,
      parts: r,
      empty: r.length === 0
    };
  }
  async _onRender(n, a) {
    await super._onRender(n, a), O(this, L) === null && D(this, L, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(n) {
    return O(this, L) !== null && (Hooks.off("updateActor", O(this, L)), D(this, L, null)), super.close(n);
  }
};
L = new WeakMap(), _(oe, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-tracker",
  classes: ["monster-anatomy", "monster-anatomy-tracker"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Tracker.Title",
    icon: "fa-solid fa-heart-pulse",
    resizable: !0
  },
  position: { width: 320, height: "auto" },
  actions: {}
}), _(oe, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-tracker.hbs" }
});
let te = oe;
const { ApplicationV2: Hn, HandlebarsApplicationMixin: Cn } = foundry.applications.api;
function $n(e, t) {
  const n = e.hp.max > 0 ? e.hp.value / e.hp.max * 100 : 0;
  return {
    id: e.id,
    img: e.img ?? "",
    name: e.name,
    state: e.state,
    stateLabel: p(ue[e.state]),
    acDisplay: t ? "??" : String(e.ac),
    hpValue: e.hp.value,
    hpMax: e.hp.max,
    hpPct: Math.max(0, Math.min(100, Math.round(n)))
  };
}
var H, ne, kt, Et;
const ie = class ie extends Cn(Hn) {
  constructor(n, a) {
    super(n);
    G(this, ne);
    G(this, H, null);
    D(this, H, a);
  }
  /** Abre o seletor e resolve com o id da parte (null = normal/dispensado). */
  static pick(n) {
    return new Promise((a) => {
      var o;
      (o = foundry.applications.instances.get("monster-anatomy-target-map")) == null || o.close(), new ie({ actor: n }, a).render(!0);
    });
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.actor, o = he(r) && !re();
    return {
      ...a,
      actorName: r.name,
      canAdd: E(r),
      parts: M(r).map((i) => $n(i, o))
    };
  }
  async _onRender(n, a) {
    var o, i, c;
    await super._onRender(n, a);
    const r = (s) => {
      if (!O(this, H)) return;
      const u = O(this, H);
      D(this, H, null), u(s), this.close();
    };
    (o = this.element.querySelector("[data-parts]")) == null || o.addEventListener("click", (s) => {
      const u = s.target.closest("[data-part-id]"), l = u == null ? void 0 : u.dataset.partId;
      l && r(l);
    }), (i = this.element.querySelector("[data-normal]")) == null || i.addEventListener("click", () => r(null)), (c = this.element.querySelector("[data-tracker]")) == null || c.addEventListener("click", () => void te.openFor(this.actor)), me(this, ne, kt).call(this);
  }
  async close(n) {
    if (O(this, H)) {
      const a = O(this, H);
      D(this, H, null), a(null);
    }
    return super.close(n);
  }
};
H = new WeakMap(), ne = new WeakSet(), /** Quick-add: cria parte na hora (nome + imagem opcional) e atualiza a lista. */
kt = function() {
  var i, c;
  const n = this.element.querySelector('[data-qa="name"]'), a = this.element.querySelector('[data-qa="img"]'), r = this.element.querySelector('[data-qa="preview"]');
  if (!n || !a) return;
  const o = () => {
    if (!r) return;
    const s = a.value.trim();
    r.hidden = s === "", s !== "" && (r.src = s);
  };
  a.addEventListener("input", o), r == null || r.addEventListener("error", () => {
    r && (r.hidden = !0);
  }), (i = this.element.querySelector("[data-qa-browse]")) == null || i.addEventListener("click", () => {
    new foundry.applications.apps.FilePicker({
      type: "image",
      current: a.value,
      callback: (u) => {
        a.value = u, o();
      }
    }).render(!0);
  }), (c = this.element.querySelector("[data-qa-add]")) == null || c.addEventListener("click", () => {
    me(this, ne, Et).call(this);
  });
}, Et = async function() {
  const n = this.actor;
  if (!E(n)) return;
  const a = this.element.querySelector('[data-qa="name"]'), r = this.element.querySelector('[data-qa="img"]');
  if (!a || !r) return;
  const o = M(n).length, i = a.value.trim() || `${p("MONSTER_ANATOMY.Part.New")} ${o + 1}`, c = Number(h("defaultAc") ?? 10), s = Number(h("defaultHp") ?? 20), u = de(i, {
    ac: Number.isFinite(c) ? c : 10,
    hp: Number.isFinite(s) ? s : 20
  }), l = r.value.trim();
  l !== "" && (u.img = l), await pt(n, u), a.value = "", r.value = "", await this.render();
}, _(ie, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-target-map",
  classes: ["monster-anatomy", "monster-anatomy-target"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Target.Title",
    icon: "fa-solid fa-crosshairs",
    resizable: !1
  },
  position: { width: 340, height: "auto" },
  actions: {}
}), _(ie, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/target-map.hbs" }
});
let Re = ie, C = null;
function Rt() {
  return C;
}
function Y() {
  C = null, xt();
}
function xt() {
  var l;
  if ((l = document.getElementById("monster-anatomy-aim")) == null || l.remove(), !C) return;
  const e = fromUuidSync(C.actorUuid), t = e instanceof Actor ? M(e).find((m) => m.id === (C == null ? void 0 : C.partId)) : void 0;
  if (!t) return;
  const n = e, a = document.createElement("div");
  a.id = "monster-anatomy-aim", a.className = "monster-anatomy ma-aim-chip";
  const r = document.createElement("button");
  r.type = "button", r.className = "ma-aim-main", r.title = p("MONSTER_ANATOMY.Target.AimClear");
  const o = document.createElement("i");
  o.className = "fa-solid fa-crosshairs";
  const i = document.createElement("span");
  i.textContent = S("MONSTER_ANATOMY.Target.Aiming", { part: t.name });
  const c = document.createElement("i");
  c.className = "fa-solid fa-xmark", r.append(o, i, c), r.addEventListener("click", () => Y());
  const s = document.createElement("button");
  s.type = "button", s.className = "ma-aim-tracker", s.title = p("MONSTER_ANATOMY.Target.OpenTracker");
  const u = document.createElement("i");
  u.className = "fa-solid fa-heart-pulse", s.append(u), s.addEventListener("click", () => void te.openFor(n)), a.append(r, s), document.body.append(a);
}
async function _t(e) {
  var l;
  const t = se(e), n = /* @__PURE__ */ new Set();
  t && n.add(t);
  let a;
  for (const m of ((l = game.user) == null ? void 0 : l.targets) ?? []) {
    const N = se(m);
    N && (n.add(N), (N === t || !t && n.size === 1) && (a = m));
  }
  if (n.size !== 1) {
    Y();
    return;
  }
  const r = [...n][0], o = t === r ? e : a, i = o == null ? void 0 : o.actor;
  if (!(i instanceof Actor)) {
    Y();
    return;
  }
  if (M(i).length === 0) {
    Y();
    return;
  }
  const s = await Re.pick(i);
  if (!s) {
    Y();
    return;
  }
  const u = M(i).find((m) => m.id === s);
  if (!u) {
    Y();
    return;
  }
  C = {
    tokenUuid: r,
    actorUuid: i.uuid,
    partId: u.id
  }, xt();
}
function Bn() {
  Hooks.on("targetToken", (e, t, n) => {
    var a;
    if (e.id === ((a = game.user) == null ? void 0 : a.id)) {
      if (!n) {
        C && se(t) === C.tokenUuid && Y();
        return;
      }
      if (!h("promptOnTarget")) {
        Y();
        return;
      }
      _t(t);
    }
  });
}
const { ApplicationV2: Fn, HandlebarsApplicationMixin: Ln } = foundry.applications.api;
var Me, Yt;
const F = class F extends Ln(Fn) {
  constructor() {
    super(...arguments);
    G(this, Me);
  }
  static async openFor(n, a, r) {
    const o = `monster-anatomy-editor-${n.uuid.replaceAll(".", "-")}-${a ?? "new"}`, i = foundry.applications.instances.get(o);
    if (i) {
      await i.render({ force: !0 }), i.bringToFront();
      return;
    }
    await new F({ id: o, actor: n, partId: a, onSaved: r }).render(!0);
  }
  get editorOptions() {
    return this.options;
  }
  get editing() {
    const { actor: n, partId: a } = this.editorOptions;
    if (a) {
      const i = M(n).find((c) => c.id === a);
      if (i) return Ne(i);
    }
    const r = Number(h("defaultAc") ?? 10), o = Number(h("defaultHp") ?? 20);
    return de("", {
      ac: Number.isFinite(r) ? r : 10,
      hp: Number.isFinite(o) ? o : 20
    });
  }
  get isNew() {
    return !this.editorOptions.partId;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.editing, o = this.editorOptions.actor, i = ke(), c = (s) => {
      var u;
      return ((u = i.find((l) => l.key === s)) == null ? void 0 : u.label) ?? s;
    };
    return {
      ...a,
      part: r,
      isNew: this.isNew,
      actorName: o.name,
      link: K(r),
      sever: r.sever ?? { value: r.hp.max, max: r.hp.max },
      severTypes: r.severTypes ?? ["slashing"],
      rewards: Te(r).map((s) => ({ ...s })),
      items: [...o.items].flatMap(
        (s) => typeof s.id == "string" ? [{ id: s.id, label: `${s.name} (${s.type})` }] : []
      ),
      damageTypes: ke(),
      physicalTypes: zt.map((s) => ({
        key: s,
        label: c(s),
        checked: (r.severTypes ?? ["slashing"]).includes(s)
      })),
      hitzones: i.map((s) => {
        var u;
        return {
          key: s.key,
          label: s.label,
          value: ((u = r.hitzone) == null ? void 0 : u[s.key]) ?? 1
        };
      }),
      statuses: (CONFIG.statusEffects ?? []).filter((s) => typeof (s == null ? void 0 : s.id) == "string").map((s) => ({ value: s.id, label: s.name ?? s.id })),
      states: Object.entries(ue).map(
        ([s, u]) => ({ value: s, label: p(u) })
      )
    };
  }
  async _onRender(n, a) {
    var i;
    await super._onRender(n, a), (i = this.element.querySelector("form.monster-anatomy-form")) == null || i.addEventListener("submit", (c) => void me(this, Me, Yt).call(this, c));
    const r = this.element.querySelector("#ma-img"), o = this.element.querySelector(".ma-imgpreview");
    r == null || r.addEventListener("input", () => rt(r, o)), o == null || o.addEventListener("error", () => {
      o && (o.hidden = !0);
    });
  }
  static onBrowseImage(n, a) {
    const r = this, o = r.element.querySelector("#ma-img"), i = r.element.querySelector(".ma-imgpreview");
    new foundry.applications.apps.FilePicker({
      type: "image",
      current: (o == null ? void 0 : o.value) ?? "",
      callback: (s) => {
        o && (o.value = s, o.dispatchEvent(new Event("input", { bubbles: !0 }))), rt(o, i);
      }
    }).render(!0);
  }
  static onAddReward(n, a) {
    const o = this.element.querySelector("[data-rewards]");
    if (!o) return;
    const i = document.createElement("div");
    i.className = "ma-reward", i.setAttribute("data-reward", ""), i.setAttribute("data-reward-id", foundry.utils.randomID()), i.innerHTML = `<select name="rw_event" title="${p("MONSTER_ANATOMY.Editor.RewardEvent")}"><option value="break">${p("MONSTER_ANATOMY.Reward.Break")}</option><option value="sever">${p("MONSTER_ANATOMY.Reward.Sever")}</option></select><select name="rw_kind" title="${p("MONSTER_ANATOMY.Editor.RewardKind")}"><option value="table">${p("MONSTER_ANATOMY.Reward.TableKind")}</option><option value="item">${p("MONSTER_ANATOMY.Reward.ItemKind")}</option></select><input name="rw_table" type="text" placeholder="RollTable.xxx / Item.xxx" title="${p("MONSTER_ANATOMY.Editor.RewardTable")}" /><input name="rw_draws" type="number" min="1" max="20" step="1" value="1" title="${p("MONSTER_ANATOMY.Editor.RewardDraws")}" /><button type="button" data-action="remove-reward" title="${p("MONSTER_ANATOMY.Editor.RewardRemove")}"><i class="fa-solid fa-xmark"></i></button>`, o.appendChild(i);
  }
  static onRemoveReward(n, a) {
    var r;
    (r = a.closest("[data-reward]")) == null || r.remove();
  }
};
Me = new WeakSet(), Yt = async function(n) {
  var Ke, je, Je, We;
  n.preventDefault();
  const a = n.target, r = new FormData(a), o = (b) => String(r.get(b) ?? "").trim(), i = (b, R) => {
    const I = Number(r.get(b));
    return Number.isFinite(I) ? I : R;
  }, { actor: c, partId: s, onSaved: u } = this.editorOptions, l = s ? M(c).find((b) => b.id === s) : void 0, m = Math.max(1, Math.floor(i("hpMax", (l == null ? void 0 : l.hp.max) ?? 10))), N = Math.max(0, Math.floor(i("regen", (l == null ? void 0 : l.regen) ?? 0))), y = o("phaseName"), f = o("zone"), v = f === "head" || f === "torso" || f === "left" || f === "right" || f === "tail" ? f : (l == null ? void 0 : l.zone) ?? null, g = o("effectDuration"), B = o("disableItemId"), z = {
    disableItemId: B,
    disableItemName: ((Ke = c.items.get(B)) == null ? void 0 : Ke.name) ?? "",
    effectName: o("effectName"),
    effectIcon: o("effectIcon"),
    effectDuration: g === "" ? null : Math.max(0, Math.floor(i("effectDuration", 0))),
    condition: o("condition"),
    setAttrPath: o("setAttrPath"),
    setAttrValue: o("setAttrValue"),
    macroUuid: o("macroUuid")
  }, $ = {};
  for (const { key: b } of ke()) {
    const R = r.get(`hz_${b}`);
    if (R == null) continue;
    const I = Number(R);
    !Number.isFinite(I) || I < 0 || I === 1 || !b || ($[b] = Math.round(I * 100) / 100);
  }
  const A = r.getAll("severType").filter((b) => typeof b == "string" && b !== ""), x = Math.max(
    1,
    Math.floor(i("severMax", ((je = l == null ? void 0 : l.sever) == null ? void 0 : je.max) ?? m))
  ), ve = ((Je = l == null ? void 0 : l.sever) == null ? void 0 : Je.value) ?? x, j = o("bonusMode"), $t = {
    mode: j === "off" || j === "percent" || j === "flat" ? j : "inherit",
    value: Math.max(0, i("bonusValue", 0))
  }, Ve = [];
  a.querySelectorAll("[data-reward]").forEach((b) => {
    const R = (Lt) => {
      var Qe, Xe;
      return ((Xe = (Qe = b.querySelector(Lt)) == null ? void 0 : Qe.value) == null ? void 0 : Xe.trim()) ?? "";
    }, I = R('input[name="rw_table"]');
    if (!I) return;
    const Bt = R('select[name="rw_event"]'), Ft = R('select[name="rw_kind"]');
    Ve.push({
      id: b.dataset.rewardId || foundry.utils.randomID(),
      kind: Ft === "item" ? "item" : "table",
      uuid: I,
      draws: Math.max(1, Math.min(20, Math.floor(Number(R('input[name="rw_draws"]')) || 1))),
      onEvent: Bt === "sever" ? "sever" : "break"
    });
  });
  const J = {
    id: (l == null ? void 0 : l.id) ?? "",
    name: o("name"),
    img: o("img"),
    zone: v,
    ac: Math.max(0, Math.floor(i("ac", (l == null ? void 0 : l.ac) ?? 10))),
    hp: {
      max: m,
      value: Math.max(0, Math.min(m, Math.floor(i("hpValue", (l == null ? void 0 : l.hp.value) ?? m))))
    },
    breakable: r.get("breakable") === "on",
    severable: r.get("severable") === "on",
    state: o("state") || (l == null ? void 0 : l.state) || "intact",
    notes: o("notes"),
    regen: N,
    phaseName: y,
    onBreak: z,
    hitzone: $,
    sever: { value: Math.min(x, ve), max: x },
    severTypes: A,
    rewards: Ve,
    bonus: $t
  };
  if (Xt(J).length > 0) {
    (We = ui.notifications) == null || We.error(p("MONSTER_ANATOMY.Editor.Invalid"));
    return;
  }
  if (l) {
    const { id: b, ...R } = J;
    await fe(c, l.id, R);
  } else {
    const b = de(J.name || p("MONSTER_ANATOMY.Part.New"), {
      ac: J.ac,
      hp: J.hp.max
    });
    await pt(c, { ...b, ...J, id: b.id });
  }
  u == null || u(), await this.close();
}, _(F, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-part-editor",
  classes: ["monster-anatomy", "monster-anatomy-editor"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Editor.Title",
    icon: "fa-solid fa-pen-to-square",
    resizable: !1
  },
  position: { width: 460, height: "auto" },
  actions: {
    "add-reward": F.onAddReward,
    "remove-reward": F.onRemoveReward,
    "browse-image": F.onBrowseImage
  }
}), _(F, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/part-editor.hbs" }
});
let ge = F;
function rt(e, t) {
  var a;
  if (!t) return;
  const n = ((a = e == null ? void 0 : e.value) == null ? void 0 : a.trim()) ?? "";
  t.hidden = n === "", n !== "" && (t.src = n);
}
function ke() {
  var t;
  const e = (t = CONFIG == null ? void 0 : CONFIG.DND5E) == null ? void 0 : t.damageTypes;
  return e && typeof e == "object" ? Object.entries(e).map(([n, a]) => ({
    key: n,
    label: qn(
      typeof a == "string" ? a : typeof (a == null ? void 0 : a.label) == "string" ? a.label : n
    )
  })) : [...Gt].map((n) => ({ key: n, label: n }));
}
function qn(e) {
  try {
    return p(e);
  } catch {
    return e;
  }
}
const { ApplicationV2: Un, HandlebarsApplicationMixin: zn } = foundry.applications.api;
var q;
const X = class X extends zn(Un) {
  constructor() {
    super(...arguments);
    G(this, q, null);
  }
  static async openFor(n) {
    const a = `monster-anatomy-summary-${n.uuid.replaceAll(".", "-")}`, r = foundry.applications.instances.get(a);
    if (r) {
      await r.render({ force: !0 }), r.bringToFront();
      return;
    }
    await new X({ id: a, actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.actor, o = M(r).map((c) => ({
      name: c.name,
      stateLabel: p(ue[c.state]),
      hp: `${c.hp.value} / ${c.hp.max}`
    })), i = wt(r).map((c) => ({
      ...c,
      eventLabel: p(
        c.event === "sever" ? "MONSTER_ANATOMY.Reward.Sever" : "MONSTER_ANATOMY.Reward.Break"
      ),
      itemsText: c.items.join(", ")
    }));
    return {
      ...a,
      actorName: r.name,
      parts: o,
      loot: i,
      emptyParts: o.length === 0,
      emptyLoot: i.length === 0,
      canClear: E(r)
    };
  }
  async _onRender(n, a) {
    await super._onRender(n, a), O(this, q) === null && D(this, q, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    }));
  }
  async close(n) {
    return O(this, q) !== null && (Hooks.off("updateActor", O(this, q)), D(this, q, null)), super.close(n);
  }
  static async onClearLoot(n, a) {
    const r = this;
    E(r.actor) && await Rn(r.actor);
  }
};
q = new WeakMap(), _(X, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-summary",
  classes: ["monster-anatomy", "monster-anatomy-summary"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Summary.Title",
    icon: "fa-solid fa-scroll",
    resizable: !0
  },
  position: { width: 460, height: "auto" },
  actions: {
    "clear-loot": X.onClearLoot
  }
}), _(X, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/loot-summary.hbs" }
});
let Ae = X;
const { ApplicationV2: Gn, HandlebarsApplicationMixin: Vn } = foundry.applications.api;
function Kn(e, t, n) {
  const a = e.hp.max > 0 ? e.hp.value / e.hp.max * 100 : 0, r = K(e).disableItemId.trim(), o = r ? t.items.get(r) : void 0, i = e.sever ?? { value: e.hp.max, max: e.hp.max }, c = i.max > 0 ? i.value / i.max * 100 : 0;
  return {
    ...e,
    hp: { ...e.hp },
    sever: { value: i.value, max: i.max },
    hpPct: Math.max(0, Math.min(100, Math.round(a))),
    stateLabel: p(ue[e.state]),
    hpMismatch: Qt(e) !== e.state,
    linkedItemName: (o == null ? void 0 : o.name) ?? r,
    linkedDisabled: r !== "" && V(e.state),
    severPct: Math.max(0, Math.min(100, Math.round(c))),
    acDisplay: n ? "??" : String(e.ac)
  };
}
function ot(e) {
  const t = e.closest(".ma-part"), n = t == null ? void 0 : t.querySelector("input.ma-amount"), a = Math.floor(Number(n == null ? void 0 : n.value));
  return Number.isFinite(a) && a > 0 ? a : null;
}
var U;
const w = class w extends Vn(Gn) {
  constructor() {
    super(...arguments);
    G(this, U, null);
  }
  /** Abre o painel para um Actor. */
  static async openFor(n) {
    const a = `monster-anatomy-panel-${n.uuid.replaceAll(".", "-")}`, r = foundry.applications.instances.get(a);
    if (r) {
      await r.render({ force: !0 }), r.bringToFront();
      return;
    }
    await new w({ id: a, actor: n }).render(!0);
  }
  get actor() {
    return this.options.actor;
  }
  async _prepareContext(n) {
    const a = await super._prepareContext(n), r = this.actor, o = re(), i = he(r), c = i && !o, s = M(r).map((u) => Kn(u, r, c));
    return {
      ...a,
      actorName: r.name,
      actorImg: r.img ?? "icons/svg/mystery-man.svg",
      canEdit: E(r),
      isGM: o,
      hideAc: i,
      phase: yt(r),
      templates: Ie().map((u) => ({ id: u.id, name: dn(u) })),
      parts: s,
      empty: s.length === 0
    };
  }
  async _onRender(n, a) {
    await super._onRender(n, a), O(this, U) === null && (D(this, U, Hooks.on("updateActor", (r) => {
      r.uuid === this.actor.uuid && this.render();
    })), Q(W.PANEL_RENDER, this));
  }
  async close(n) {
    return O(this, U) !== null && (Hooks.off("updateActor", O(this, U)), D(this, U, null)), super.close(n);
  }
  // -- actions (this = instância, injetado pelo ApplicationV2) -----------------
  static async onAddPart(n, a) {
    const r = this;
    E(r.actor) && await ge.openFor(r.actor, void 0, () => void r.render());
  }
  static async onDuplicatePart(n, a) {
    const r = this;
    if (!E(r.actor)) return;
    const o = a.dataset.partId;
    o && await ht(r.actor, o);
  }
  static async onEditPart(n, a) {
    const r = this;
    if (!E(r.actor)) return;
    const o = a.dataset.partId;
    o && await ge.openFor(r.actor, o, () => void r.render());
  }
  static async onOpenTracker(n, a) {
    const r = this;
    await te.openFor(r.actor);
  }
  static async onOpenSummary(n, a) {
    const r = this;
    await Ae.openFor(r.actor);
  }
  static async onDamagePart(n, a) {
    const r = this;
    if (!E(r.actor)) return;
    const o = a.dataset.partId, i = ot(a);
    !o || i === null || await Ot(r.actor, o, i);
  }
  static async onHealPart(n, a) {
    const r = this;
    if (!E(r.actor)) return;
    const o = a.dataset.partId, i = ot(a);
    !o || i === null || await ze(r.actor, o, i);
  }
  static async onDeletePart(n, a) {
    const r = this;
    if (!E(r.actor)) return;
    const o = a.dataset.partId, i = M(r.actor).find((s) => s.id === o);
    !o || !i || !await foundry.applications.api.DialogV2.confirm({
      window: { title: p("MONSTER_ANATOMY.Delete.Title") },
      content: `<p>${S("MONSTER_ANATOMY.Delete.Prompt", { name: i.name })}</p>`,
      modal: !0
    }) || await mn(r.actor, o);
  }
  static async onApplyTemplate(n, a) {
    var c, s;
    const r = this;
    if (!E(r.actor)) return;
    const o = ((c = a.parentElement) == null ? void 0 : c.querySelector("select.ma-template-select")) ?? r.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (i)
      try {
        const u = await At(r.actor, i), l = ut(r.actor), m = i.startsWith("builtin-") && l.hp !== null && l.ac !== null;
        (s = ui.notifications) == null || s.info(
          m ? S("MONSTER_ANATOMY.Template.AppliedScaled", {
            count: String(u),
            hp: String(l.hp),
            ac: String(l.ac)
          }) : S("MONSTER_ANATOMY.Template.Applied", { count: String(u) })
        );
      } catch (u) {
        console.warn("monster-anatomy | falha ao aplicar modelo", u);
      }
  }
  static async onSaveTemplate(n, a) {
    var c, s;
    const r = this;
    if (!re()) return;
    const o = M(r.actor);
    if (o.length === 0) {
      (c = ui.notifications) == null || c.warn(p("MONSTER_ANATOMY.Template.Empty"));
      return;
    }
    const i = await jn(r.actor.name);
    i && (await fn(i, o), (s = ui.notifications) == null || s.info(S("MONSTER_ANATOMY.Template.Saved", { name: i })), r.render());
  }
  static async onDeleteTemplate(n, a) {
    var s, u;
    const r = this;
    if (!re()) return;
    const o = r.element.querySelector("select.ma-template-select"), i = o == null ? void 0 : o.value;
    if (!i) return;
    if (!await pn(i)) {
      (s = ui.notifications) == null || s.warn(p("MONSTER_ANATOMY.Template.Protected"));
      return;
    }
    (u = ui.notifications) == null || u.info(p("MONSTER_ANATOMY.Template.Deleted")), r.render();
  }
  static async onToggleHideAc(n, a) {
    const r = this;
    re() && await gn(r.actor, !he(r.actor));
  }
};
U = new WeakMap(), _(w, "DEFAULT_OPTIONS", {
  id: "monster-anatomy-panel",
  classes: ["monster-anatomy", "monster-anatomy-panel"],
  tag: "section",
  window: {
    title: "MONSTER_ANATOMY.Panel.Title",
    icon: "fa-solid fa-dragon",
    resizable: !0
  },
  position: { width: 500, height: "auto" },
  actions: {
    "add-part": w.onAddPart,
    "edit-part": w.onEditPart,
    "delete-part": w.onDeletePart,
    "duplicate-part": w.onDuplicatePart,
    "open-tracker": w.onOpenTracker,
    "open-summary": w.onOpenSummary,
    "damage-part": w.onDamagePart,
    "heal-part": w.onHealPart,
    "apply-template": w.onApplyTemplate,
    "save-template": w.onSaveTemplate,
    "delete-template": w.onDeleteTemplate,
    "toggle-hide-ac": w.onToggleHideAc
  }
}), _(w, "PARTS", {
  main: { template: "modules/monster-anatomy/templates/anatomy-panel.hbs" }
});
let xe = w;
async function jn(e) {
  const t = await foundry.applications.api.DialogV2.wait({
    window: { title: p("MONSTER_ANATOMY.Template.NameTitle") },
    content: `<div class="form-group"><label>${p("MONSTER_ANATOMY.Template.NamePrompt")}</label><input name="templateName" type="text" value="${e}" maxlength="80" /></div>`,
    buttons: [
      {
        action: "save",
        label: p("MONSTER_ANATOMY.Editor.Save"),
        default: !0,
        callback: (n, a) => {
          var o, i;
          const r = (o = a.form) == null ? void 0 : o.querySelector(
            'input[name="templateName"]'
          );
          return ((i = r == null ? void 0 : r.value) == null ? void 0 : i.trim()) ?? "";
        }
      }
    ],
    modal: !0
  });
  return typeof t != "string" || t.trim() === "" ? null : t.trim();
}
function Jn() {
  var t, n;
  return {
    version: ((n = (t = game.modules) == null ? void 0 : t.get(d)) == null ? void 0 : n.version) ?? "0.0.0",
    async openAnatomy(a) {
      await xe.openFor(a);
    },
    getParts(a) {
      return M(a);
    },
    canEdit(a) {
      return E(a);
    },
    damagePart(a, r, o, i) {
      return Ot(a, r, o, i);
    },
    healPart(a, r, o) {
      return ze(a, r, o);
    },
    damagePartDetailed(a, r, o, i) {
      return Se(a, r, o, i);
    },
    getSelection() {
      return Rt();
    },
    clearSelection() {
      Y();
    },
    promptTargetSelection(a) {
      return _t(a);
    },
    openTracker(a) {
      return te.openFor(a);
    },
    openSummary(a) {
      return Ae.openFor(a);
    },
    on(a, r) {
      const o = a.startsWith("monsterAnatomy.") ? a : `monsterAnatomy.${a}`, i = ae(o, r);
      return () => Zt(o, i);
    },
    getTemplates() {
      return Ie();
    },
    applyTemplate(a, r) {
      return At(a, r);
    },
    duplicatePart(a, r) {
      return ht(a, r);
    }
  };
}
function Wn(e) {
  globalThis.MonsterAnatomy = e;
}
const Qn = 600 * 1e3, Xn = 120 * 1e3;
let Z = [];
function be(e) {
  return e.map((t) => Math.floor(Number(t) || 0)).filter((t) => t > 0).sort((t, n) => t - n).join(",");
}
function Pt() {
  const e = Date.now();
  Z = Z.filter((t) => t.expires > e).slice(-60);
}
function It(e, t, n) {
  if (!e || !t) return;
  Pt();
  const a = n ? Qn : Xn;
  Z.push({ actorUuid: e, sig: t, ...n ? { messageId: n } : {}, expires: Date.now() + a });
}
function Zn(e, t, n) {
  var r;
  Pt();
  const a = Z.findIndex((o) => o.actorUuid !== e ? !1 : o.messageId ? n !== void 0 && o.messageId === n : o.sig === t);
  return a < 0 ? !1 : ((r = Z[a]) != null && r.messageId || Z.splice(a, 1), !0);
}
function ea(e, t) {
  var a, r;
  const n = ((a = game.messages) == null ? void 0 : a.contents) ?? [];
  for (let o = n.length - 1; o >= Math.max(0, n.length - 12); o--) {
    const i = n[o];
    if (!i || t && ((r = i.author) == null ? void 0 : r.id) !== t) continue;
    const c = i.rolls;
    if (!Array.isArray(c) || c.length === 0) continue;
    if (be(c.map((u) => Number(u == null ? void 0 : u.total))) === e) return i.id ?? void 0;
  }
}
function k(e) {
  return typeof e == "string" ? e : "";
}
function ta(e) {
  if (!Array.isArray(e)) return [];
  const t = [];
  for (const n of e) {
    if (!n || typeof n != "object") continue;
    const a = Math.max(0, Math.floor(Number(n.amount) || 0));
    if (a <= 0) continue;
    const r = n.type;
    t.push(typeof r == "string" && r ? { amount: a, type: r } : { amount: a });
  }
  return t;
}
function na() {
  var e;
  return ((e = game.users) == null ? void 0 : e.some((t) => t.isGM && t.active)) ?? !1;
}
function aa(e) {
  var t;
  return ((t = game.user) == null ? void 0 : t.isGM) === !0 || e.isOwner;
}
function ra() {
  var e;
  (e = game.socket) == null || e.on(`module.${d}`, (t) => {
    oa(t);
  });
}
async function oa(e) {
  var n, a, r;
  if (!e || typeof e != "object") return;
  const t = e;
  if (t.t === "apply") {
    if (!((n = game.user) != null && n.isActiveGM)) return;
    const o = await fromUuid(
      k(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = typeof t.attacker == "string" ? t.attacker : void 0, c = typeof t.attackerUuid == "string" ? t.attackerUuid : void 0, s = ta(t.components), u = await Se(o, k(t.partId), s, {
      attacker: i,
      attackerUuid: c
    });
    u.globalApplied > 0 && Dt(o.uuid, be(s.map((l) => l.amount)), typeof t.by == "string" ? t.by : void 0), await vt(
      o,
      ((a = M(o).find((l) => l.id === k(t.partId))) == null ? void 0 : a.name) ?? k(t.partId),
      u.applied,
      u.globalApplied,
      u.bonus,
      u.bonusFlat
    ), u.broke && ee(k(t.actorUuid), k(t.partId), "break"), u.severed && ee(k(t.actorUuid), k(t.partId), "sever"), u.phased !== "" && ee(k(t.actorUuid), k(t.partId), "phase");
  } else if (t.t === "claim")
    It(
      k(t.actorUuid),
      k(t.sig),
      typeof t.messageId == "string" && t.messageId !== "" ? t.messageId : void 0
    );
  else if (t.t === "present") {
    if (typeof t.by == "string" && t.by === ((r = game.user) == null ? void 0 : r.id)) return;
    const o = await fromUuid(
      k(t.actorUuid)
    );
    if (!(o instanceof Actor)) return;
    const i = M(o).find((c) => c.id === k(t.partId));
    if (!i) return;
    t.kind === "sever" ? Nt(o, i) : t.kind === "phase" ? St(o, i, yt(o) || "?") : Tt(o, i);
  }
}
function Ge(e) {
  var t;
  try {
    (t = game.socket) == null || t.emit(`module.${d}`, e);
  } catch (n) {
    console.warn("monster-anatomy | falha no socket", n);
  }
}
function Dt(e, t, n) {
  var r;
  if (!t) return;
  const a = ea(t, n ?? ((r = game.user) == null ? void 0 : r.id) ?? void 0);
  It(e, t, a), Ge({ t: "claim", actorUuid: e, sig: t, ...a ? { messageId: a } : {} });
}
function ia(e, t, n, a, r) {
  var i;
  const o = { t: "apply", actorUuid: e, partId: t, components: n, attacker: a, attackerUuid: r, by: (i = game.user) == null ? void 0 : i.id };
  Ge(o);
}
function ee(e, t, n = "break") {
  var r;
  const a = { t: "present", actorUuid: e, partId: t, kind: n, by: (r = game.user) == null ? void 0 : r.id };
  Ge(a);
}
let ye = null;
function sa() {
  ae("dnd5e.rollAttackV2", (...e) => void la(e)), ae("dnd5e.rollDamageV2", (...e) => void ma(e)), ae("dnd5e.preUseActivity", (...e) => ua(e)), ae("dnd5e.preApplyDamage", (...e) => ca(e)), Hooks.on("targetToken", (e, t, n) => {
    var a;
    e.id === ((a = game.user) == null ? void 0 : a.id) && (ye = null);
  });
}
function ca(e) {
  var c;
  try {
    if (h("blockDuplicateDamage") !== !0) return;
  } catch {
    return;
  }
  const [t, n, , a] = e;
  if (!(t instanceof Actor) || !(Number(n) > 0)) return;
  const r = (a == null ? void 0 : a.originatingMessage) ?? (a == null ? void 0 : a.origin);
  if (!r || !Array.isArray(r.rolls)) return;
  const o = be(r.rolls.map((s) => Number(s == null ? void 0 : s.total))), i = typeof r.id == "string" ? r.id : void 0;
  if (Zn(t.uuid, o, i))
    return (c = ui.notifications) == null || c.info(S("MONSTER_ANATOMY.Target.DuplicateBlocked", { actor: t.name })), !1;
}
function ua(e) {
  var i;
  const [t] = e, n = t == null ? void 0 : t.item, a = t == null ? void 0 : t.actor, r = a instanceof Actor ? a : (n == null ? void 0 : n.parent) instanceof Actor ? n.parent : void 0;
  if (!r || typeof (n == null ? void 0 : n.id) != "string" || !en(r).has(n.id)) return;
  const o = tn(r, n.id);
  return (i = ui.notifications) == null || i.warn(
    S("MONSTER_ANATOMY.Usage.Blocked", {
      item: typeof n.name == "string" ? n.name : n.id,
      part: (o == null ? void 0 : o.name) ?? "",
      actor: r.name
    })
  ), !1;
}
async function la(e) {
  var B, z;
  const t = Rt();
  if (!t) return;
  const n = [...((B = game.user) == null ? void 0 : B.targets) ?? []], a = n.length === 1 ? n[0] : void 0, r = se(a), o = a == null ? void 0 : a.actor;
  if (!a || !r || !o || r !== t.tokenUuid || o.uuid !== t.actorUuid) {
    Y();
    return;
  }
  const [i, c] = e, s = i == null ? void 0 : i[0], u = Number((s == null ? void 0 : s.total) ?? NaN);
  if (!Number.isFinite(u)) return;
  const l = fa(s), m = l === 20, N = l === 1, y = M(o).find(($) => $.id === t.partId);
  if (!y) {
    Y();
    return;
  }
  const f = m || !N && u >= y.ac, v = pa(c == null ? void 0 : c.subject), g = (v == null ? void 0 : v.name) ?? ((z = game.user) == null ? void 0 : z.name) ?? "?";
  if (ye = {
    tokenUuid: r,
    actorUuid: o.uuid,
    partId: y.id,
    hit: f,
    crit: m,
    attacker: g,
    attackerUuid: v == null ? void 0 : v.uuid
  }, h("attackNotes")) {
    const $ = f ? "MONSTER_ANATOMY.Attack.Hit" : "MONSTER_ANATOMY.Attack.Miss", A = m && f ? ` ${p("MONSTER_ANATOMY.Attack.CritSuffix")}` : "", x = he(o) ? "??" : String(y.ac), ve = `<div class="monster-anatomy-chat ma-attack"><p>${S($, {
      attacker: g,
      part: y.name,
      actor: o.name,
      total: String(u),
      ac: x
    })}${A}</p></div>`, j = v ? ChatMessage.getSpeaker({ actor: v }) : ChatMessage.getSpeaker({ alias: g });
    await ChatMessage.create({ speaker: j, content: ve });
  }
}
async function ma(e) {
  var c, s, u, l;
  const t = ye;
  if (ye = null, !(t != null && t.hit)) return;
  const [n] = e, a = (n ?? []).map((m) => ({ amount: Number(m == null ? void 0 : m.total) || 0, type: da(m) })).filter((m) => m.amount > 0);
  if (a.length === 0) return;
  const r = [...((c = game.user) == null ? void 0 : c.targets) ?? []].find((m) => se(m) === t.tokenUuid), o = r == null ? void 0 : r.actor;
  if (!o || o.uuid !== t.actorUuid) return;
  const i = ((s = M(o).find((m) => m.id === t.partId)) == null ? void 0 : s.name) ?? t.partId;
  if (aa(o)) {
    const m = await Se(o, t.partId, a, {
      attacker: t.attacker,
      attackerUuid: t.attackerUuid
    });
    m.globalApplied > 0 && Dt(o.uuid, be(a.map((N) => N.amount))), await vt(o, i, m.applied, m.globalApplied, m.bonus, m.bonusFlat), m.broke && ee(o.uuid, t.partId, "break"), m.severed && ee(o.uuid, t.partId, "sever"), m.phased !== "" && ee(o.uuid, t.partId, "phase");
  } else na() ? (ia(o.uuid, t.partId, a, t.attacker, t.attackerUuid), (u = ui.notifications) == null || u.info(S("MONSTER_ANATOMY.Target.SentToGM", { part: i }))) : (l = ui.notifications) == null || l.warn(p("MONSTER_ANATOMY.Target.NoGM"));
}
function da(e) {
  var a, r;
  const t = e;
  if (typeof ((a = t.options) == null ? void 0 : a.type) == "string" && t.options.type) return t.options.type;
  const n = (r = t.options) == null ? void 0 : r.types;
  if (Array.isArray(n) && typeof n[0] == "string" && n[0]) return n[0];
}
function fa(e) {
  var n;
  const t = e == null ? void 0 : e.dice;
  if (Array.isArray(t))
    for (const a of t) {
      if ((a == null ? void 0 : a.faces) !== 20) continue;
      const r = a == null ? void 0 : a.results;
      if (!Array.isArray(r)) continue;
      const o = (n = r[0]) == null ? void 0 : n.result;
      if (typeof o == "number") return o;
    }
}
function pa(e) {
  const t = e == null ? void 0 : e.actor;
  return t instanceof Actor ? t : void 0;
}
function ha() {
  Hooks.on("combatTurnChange", (e, t, n) => {
    var c;
    if (!((c = game.user) != null && c.isActiveGM)) return;
    const a = t, r = n;
    if (a && r) {
      const s = a.round ?? 0, u = r.round ?? 0;
      if (u < s || u === s && (r.turn ?? 0) < (a.turn ?? 0)) return;
    }
    const o = r != null && r.combatantId ? e.combatants.get(r.combatantId) : void 0, i = o == null ? void 0 : o.actor;
    i instanceof Actor && ga(i);
  });
}
async function ga(e) {
  const t = M(e).filter(
    (r) => (r.regen ?? 0) > 0 && r.hp.value < r.hp.max && r.state !== "destroyed"
  );
  if (t.length === 0) return;
  const n = [];
  for (const r of t)
    try {
      const o = Math.max(1, Math.floor(r.regen ?? 0)), i = r.hp.value, c = await ze(e, r.id, o), s = c.hp.value - i;
      s > 0 && n.push(`${c.name} +${s}`);
    } catch (o) {
      console.warn("monster-anatomy | falha na regeneração", o);
    }
  if (n.length === 0) return;
  let a = !1;
  try {
    a = h("chatMessage") === !0;
  } catch {
    return;
  }
  a && await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: e }),
    content: `<div class="monster-anatomy-chat ma-regen"><p>${S("MONSTER_ANATOMY.Regen.Text", {
      actor: e.name,
      bits: n.join(", ")
    })}</p></div>`
  });
}
function Aa() {
  Bn(), sa(), ha();
}
function ya() {
  game.settings.register(d, "showHeaderButton", {
    name: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowHeaderButton.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "defaultAc", {
    name: "MONSTER_ANATOMY.Settings.DefaultAc.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultAc.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 10
  }), game.settings.register(d, "defaultHp", {
    name: "MONSTER_ANATOMY.Settings.DefaultHp.Name",
    hint: "MONSTER_ANATOMY.Settings.DefaultHp.Hint",
    scope: "world",
    config: !0,
    type: Number,
    default: 20
  }), game.settings.register(d, "damageModel", {
    name: "MONSTER_ANATOMY.Settings.DamageModel.Name",
    hint: "MONSTER_ANATOMY.Settings.DamageModel.Hint",
    scope: "world",
    config: !0,
    type: String,
    choices: {
      independent: "MONSTER_ANATOMY.Settings.DamageModel.Independent",
      shared: "MONSTER_ANATOMY.Settings.DamageModel.Shared",
      percent: "MONSTER_ANATOMY.Settings.DamageModel.Percent"
    },
    default: "shared"
  }), game.settings.register(d, "damagePercent", {
    name: "MONSTER_ANATOMY.Settings.DamagePercent.Name",
    hint: "MONSTER_ANATOMY.Settings.DamagePercent.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 100, step: 5 },
    default: 50
  }), game.settings.register(d, "brokenBonus", {
    name: "MONSTER_ANATOMY.Settings.BrokenBonus.Name",
    hint: "MONSTER_ANATOMY.Settings.BrokenBonus.Hint",
    scope: "world",
    config: !0,
    type: Number,
    range: { min: 0, max: 200, step: 5 },
    default: 50
  }), game.settings.register(d, "showAnnouncement", {
    name: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Name",
    hint: "MONSTER_ANATOMY.Settings.ShowAnnouncement.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "announceDuration", {
    name: "MONSTER_ANATOMY.Settings.AnnounceDuration.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceDuration.Hint",
    scope: "client",
    config: !0,
    type: Number,
    range: { min: 0.5, max: 10, step: 0.5 },
    default: 2.5
  }), game.settings.register(d, "chatMessage", {
    name: "MONSTER_ANATOMY.Settings.ChatMessage.Name",
    hint: "MONSTER_ANATOMY.Settings.ChatMessage.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "tokenEffect", {
    name: "MONSTER_ANATOMY.Settings.TokenEffect.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenEffect.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "breakSound", {
    name: "MONSTER_ANATOMY.Settings.BreakSound.Name",
    hint: "MONSTER_ANATOMY.Settings.BreakSound.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(d, "promptOnTarget", {
    name: "MONSTER_ANATOMY.Settings.PromptOnTarget.Name",
    hint: "MONSTER_ANATOMY.Settings.PromptOnTarget.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "attackNotes", {
    name: "MONSTER_ANATOMY.Settings.AttackNotes.Name",
    hint: "MONSTER_ANATOMY.Settings.AttackNotes.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "blockDuplicateDamage", {
    name: "MONSTER_ANATOMY.Settings.BlockDuplicate.Name",
    hint: "MONSTER_ANATOMY.Settings.BlockDuplicate.Hint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "announceTheme", {
    name: "MONSTER_ANATOMY.Settings.AnnounceTheme.Name",
    hint: "MONSTER_ANATOMY.Settings.AnnounceTheme.Hint",
    scope: "client",
    config: !0,
    type: String,
    choices: {
      celestial: "MONSTER_ANATOMY.Settings.AnnounceTheme.Celestial",
      persona: "MONSTER_ANATOMY.Settings.AnnounceTheme.Persona",
      monsterhunter: "MONSTER_ANATOMY.Settings.AnnounceTheme.MonsterHunter",
      jrpg: "MONSTER_ANATOMY.Settings.AnnounceTheme.Jrpg",
      minimal: "MONSTER_ANATOMY.Settings.AnnounceTheme.Minimal",
      impact: "MONSTER_ANATOMY.Settings.AnnounceTheme.Impact",
      arcade: "MONSTER_ANATOMY.Settings.AnnounceTheme.Arcade",
      carved: "MONSTER_ANATOMY.Settings.AnnounceTheme.Carved"
    },
    default: "celestial"
  }), game.settings.register(d, "customKickerBreak", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerBreak.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(d, "customKickerSever", {
    name: "MONSTER_ANATOMY.Settings.CustomKickerSever.Name",
    hint: "MONSTER_ANATOMY.Settings.CustomKickerSever.Hint",
    scope: "world",
    config: !0,
    type: String,
    default: ""
  }), game.settings.register(d, "tokenShake", {
    name: "MONSTER_ANATOMY.Settings.TokenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.TokenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "screenFlash", {
    name: "MONSTER_ANATOMY.Settings.ScreenFlash.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenFlash.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "reducedMotion", {
    name: "MONSTER_ANATOMY.Settings.ReducedMotion.Name",
    hint: "MONSTER_ANATOMY.Settings.ReducedMotion.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !1
  }), game.settings.register(d, "particles", {
    name: "MONSTER_ANATOMY.Settings.Particles.Name",
    hint: "MONSTER_ANATOMY.Settings.Particles.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "screenShake", {
    name: "MONSTER_ANATOMY.Settings.ScreenShake.Name",
    hint: "MONSTER_ANATOMY.Settings.ScreenShake.Hint",
    scope: "client",
    config: !0,
    type: Boolean,
    default: !0
  }), game.settings.register(d, "templatesJson", {
    name: "MONSTER_ANATOMY.Settings.TemplatesJson.Name",
    hint: "MONSTER_ANATOMY.Settings.TemplatesJson.Hint",
    scope: "world",
    config: !1,
    type: String,
    default: "[]"
  });
}
function Ht(e) {
  const t = e == null ? void 0 : e.document;
  return t instanceof Actor ? t : void 0;
}
function Ct() {
  try {
    return h("showHeaderButton");
  } catch {
    return !0;
  }
}
function it(e, t) {
  const n = Ht(e);
  !n || !Array.isArray(t) || !Ct() || t.some((a) => (a == null ? void 0 : a.action) === "monster-anatomy") || t.unshift({
    action: "monster-anatomy",
    label: "MONSTER_ANATOMY.Panel.OpenButton",
    icon: "fa-solid fa-dragon",
    onClick: () => {
      var a;
      (a = mt()) == null || a.openAnatomy(n);
    }
  });
}
function Ma() {
  Hooks.on("getHeaderControlsActorSheetV2", (...e) => {
    it(e[0], e[1]);
  }), Hooks.on("getHeaderControlsApplicationV2", (...e) => {
    it(e[0], e[1]);
  }), Hooks.on("getActorSheetHeaderButtons", (...e) => {
    const [t, n] = e, a = Ht(t) ?? (t == null ? void 0 : t.actor);
    if (!(a instanceof Actor) || !Array.isArray(n) || !Ct()) return;
    const r = a;
    n.unshift({
      class: "monster-anatomy-open",
      icon: "fas fa-dragon",
      label: "MONSTER_ANATOMY.Panel.OpenButton",
      onclick: () => {
        var o;
        (o = mt()) == null || o.openAnatomy(r);
      }
    });
  });
}
async function Ta() {
  await foundry.applications.handlebars.loadTemplates([
    "modules/monster-anatomy/templates/anatomy-panel.hbs",
    "modules/monster-anatomy/templates/anatomy-tracker.hbs",
    "modules/monster-anatomy/templates/loot-summary.hbs",
    "modules/monster-anatomy/templates/part-editor.hbs",
    "modules/monster-anatomy/templates/target-map.hbs"
  ]);
}
function Ee(e, t) {
  try {
    t();
  } catch (n) {
    console.error(`${d} | falha no init (${e})`, n);
  }
}
Hooks.once("init", () => {
  var n;
  console.log(`${d} | init`), Ee("settings", ya), Ee("header", Ma), Ee("combat", Aa);
  const e = Jn(), t = (n = game.modules) == null ? void 0 : n.get(d);
  t && (t.api = e), Wn(e), Ta();
});
Hooks.once("setup", () => {
  console.log(`${d} | setup`);
});
Hooks.once("ready", () => {
  var e, t;
  console.log(`${d} | ready (v${((t = (e = game.modules) == null ? void 0 : e.get(d)) == null ? void 0 : t.version) ?? "?"})`), ra();
});
//# sourceMappingURL=main.js.map
